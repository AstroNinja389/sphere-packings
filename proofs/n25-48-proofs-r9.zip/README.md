# Lattice packing density upper bounds in dimensions 25–48

Run `python -B verify.py` to check all 24 dimensions offline or name individual dimensions. Python, NumPy and python-flint suffice. The p subdirectory contains the Fourier, parity, contact and reciprocal-section inputs. The outer verifier replays those inputs and then proves the extra payment when the table uses one. The two additional payments can use the same slack, so the table uses the stronger separate proof for each dimension. BOUNDS.json contains the exact rational upper bounds and decimals rounded upward.

"""Prevent standalone proof workers from consulting the research workspace or the network."""
import os, sys
from pathlib import Path
if 'LATTICE_REPLAY_BUNDLE' in os.environ:
    bundle=Path(os.environ['LATTICE_REPLAY_BUNDLE']).resolve()
    workspace=Path(os.environ['LATTICE_REPLAY_WORKSPACE']).resolve()
    if not bundle.is_relative_to(workspace):
        raise RuntimeError('Unexpected standalone replay path.')
    def check(event,args):
        if event in ('socket.connect','socket.getaddrinfo','socket.gethostbyname'):
            raise PermissionError('Network access disabled during proof replay.')
        if event!='open' or not args or not isinstance(args[0],(str,bytes)):
            return
        path=Path(os.fsdecode(args[0])).resolve()
        if path.is_relative_to(workspace) and not path.is_relative_to(bundle):
            raise PermissionError('External workspace proof dependency: '+str(path))
    sys.addaudithook(check)

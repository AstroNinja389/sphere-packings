# A compact inequality on the reciprocal lattice

Let an \(n\)-dimensional lattice \(L\) have squared minimum one, density \(\Delta\), and primal Fourier parameter \(\tau\). Suppose the optimum in dimension \(n-1\) is at most \(U\), and fix a target \(T\) below the existing upper bound. For any primitive reciprocal vector \(y\), the section perpendicular to \(y\) has covolume \({\rm covol}(L)|y|\) and squared minimum at least one. Consequently \(\Delta>T\) implies
\[
 x=\frac{4\pi^2 |y|^2}{\tau}>
 \frac{4\pi^2}{\tau}\left(\frac{2V_{n-1}T}{V_nU}\right)^2.
\]
The same lower estimate holds for every nonzero reciprocal vector, since it is an integer multiple of a primitive one. Take a positive rational \(g\) below this threshold using directed rounding. The reciprocal lattice after rescaling has squared minimum at least one in coordinates \(b=x/g\).

Suppose \(s_*+\sum_{y\ne0} H_*(b_y)\ge0\) follows from the certified compact plane geometry on this rescaled lattice, including its Schur origin. If \(Q(x)e^{-x/2}\ge H_*(x/g)\) on \(g\le x\le Rg\) and \(Q\ge0\) after \(Rg\), then
\[
 \sum_{y\in L^*}Q(x_y)e^{-x_y/2}\ge Q(0)-s_* .
\]
This allows negative Fourier values on part of the conditional reciprocal shell. The block variables on the reciprocal lattice are independent of the block variables on the primal lattice. Their spatial sums use the same lattice covolume through Poisson summation. A primal upper \(P(0)+s+B\), together with \(Q(0)-s_*>0\), yields the ratio \((P(0)+s+B)/(Q(0)-s_*)\) in the Fourier density formula. Take the larger of this density and \(T\) to cover both determinant branches. A zero reciprocal kernel recovers the usual conditional spectral gap.

The numerical method can optimize both sets of matrix coefficients, or hold independently audited reciprocal matrices fixed and optimize the nonnegative prices and their origin vectors. Proving the conditional shell lower, the upper half-line sign, the exact section input, and the unconditional union are separate obligations. Changing the Fourier sign domain without these checks would invalidate the bound.

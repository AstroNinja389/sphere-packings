# Assigning the negative Fourier tail to short vectors by eutaxy

An upper bound for a density maximizer bounds every lattice in the same dimension. Scale that maximizer to squared minimum one. It admits symmetric weights \(p_u\ge0\) on its **actual signed minimum vectors** with \(\sum_u p_u=1\) and \(\sum_u p_u uu^t=I/n\). The weaker nonnegative eutaxy needed here follows by separating the identity from the cone of minimum projectors if necessary, then using a small symmetric metric change that preserves the minimum and lowers the determinant. Local finiteness gives a gap to the next length. Classical perfection also implies that at least \(n(n+1)/2\) distinct opposite pairs attain the minimum.

Let \(1\le b=|v|^2<2\), \(u\) a signed minimum vector, and \(a=|u+v|^2\). For \(v\ne\pm u\) the two possible squared lengths are
\[
 a_\pm=1+b\pm2t,\qquad t=|\langle v,u\rangle|\le b/2 .
\]
Whenever \(a\ge R>2\), \(a+1-b>0\). Give the output \(w=v+u\) weight \(p_u\,n(a+1-b)^2/(2a)\). The sum of these weights over **all short sources with this same output** is at most one. In fact \(a+1-b=2\langle w,u\rangle\) and for a fixed \(w,u\) there is only one possible \(v\). All contributing \(u\) are in the positive half-space of \(w\). Evenness and the eutaxy identity give
\[
 \sum_{\langle w,u\rangle>0}p_u\,2n\,\langle w,u\rangle^2/a=1 .
\]
Each counted output is primitive: its squared length is at most \(1+2b<5\); a nonprimitive output would be twice a lattice vector. In that case \(u,v\) have the same nonzero label modulo \(2L\). Uniqueness of a short opposite pair of squared length below two forces \(v=\pm u\), which was removed. Thus the payment is disjoint from all previous payments at doubles or higher multiples of primitive lines. Combining with other schemes on *primitive* tail outputs requires a separate allocation.

Let \(f(a)\le0\) on \(a\ge R\). Put \(J_b(a)=n(a+1-b)^2 f(a)/(2a)\) on the tail and zero elsewhere. Then a budget on the signed spatial sum can include for each signed short vector the nonpositive amount \(\frac12\mathbb E_u[J_b(a_+)+J_b(a_-)]\), excluding the two parallel orientations. Any affine upper bound in \(t^2\) on the actual two-length expression can be integrated using \(\mathbb E_u t^2=b/n\). For exact minimum vectors, the omitted parallel mass must be charged explicitly. An upper cost \(A+B(t^2-b/n)\) valid for nonparallel inputs and an additional constant \(c\ge\max(0,-A-B(1-1/n))\) at the parallel input suffice. Summing the latter error over signed \(v\) costs \(2c\), since the total weight of parallel incidences is two. One may instead use a safe upper bound zero for all exact minima and make a separate minimum bin. All quantities here refer to actual lengths and one lattice. A numerical angular envelope alone cannot certify a density.

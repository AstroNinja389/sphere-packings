# Four lattice lines in a plane and compact kernels with squared support up to three

Let the ambient lattice have squared minimum at least one, and fix \(2<R\le3\). In each saturated rank-two plane choose a shortest vector \(u\) and a shortest vector \(v\) completing it to a basis. Reduce the second vector along the first and change its sign so that \(a=\|u\|^2\), \(b=\|v\|^2\), \(t=\langle u,v\rangle\) satisfy \(1\le a\le b\) and \(0\le2t\le a\). If there are two independent vectors below the cutoff, both basis vectors lie below the cutoff. Indeed \(\|iu+jv\|^2=a(i+jt/a)^2+j^2(b-t^2/a)\ge3b\) for \(|j|\ge2\), and for \(|j|=1\) the reduced choice minimizes the length.

Only \(u,v,v-u,v+u\), up to sign, can have squared length below \(R\). Multiples of \(u\) have squared length at least four. For \(|j|=1\) and \(|i|\ge2\) the squared length is at least \(b+(i^2-|i|)a\ge3\). All four possible vectors are primitive. Their ordered squared lengths are
\[
 a,\quad b,\quad c=a+b-2t,\quad d=a+b+2t.
\]
These are actual vectors in a common lattice plane. Thus three off-diagonal tests suffice. When only two lines occur, their squared cosine is bounded by \((a+b-R)^2/(4ab)\). When three occur, the third is \(v-u\), giving the usual three-line triangle test. With four, the six inner products in this order are \(t,t-a,t+a,b-t,b+t,b-a\) for the pairs \(uv,u(v-u),u(v+u),v(v-u),v(v+u),(v-u)(v+u)\).

The full four-line domain has the following polynomial parametrization by a unit cube. Put \(D=R-2\),
\[
 a=1+\tfrac12 D x,\quad b=a+D(1-x)y,\quad
 2t=D(1-x)(1-y)z,\qquad 0\le x,y,z\le1.
\]
It is equivalent to the simplex \(2(a-1)+(b-a)+2t+(R-d)=D\) with nonnegative coordinates. The remaining reduction condition follows from \(2t\le D\le 1\le a\). Use each line's own \(h(e)=(R-e)/(R-1)\) in its radial features. A polynomial sign proof on the cube therefore handles every four-line configuration simultaneously. Gluing these tests to the two- and three-line tests is legitimate because every off-diagonal line pair spans exactly one plane. At a cutoff endpoint the corresponding radial feature is zero.

For a Gaussian multiplied by a degree-bounded matrix kernel the same Schur and Fourier argument then applies. A density claim requires proofs on all three domains and a separate full-line spatial and Fourier verification. The geometry alone gives no new packing density.

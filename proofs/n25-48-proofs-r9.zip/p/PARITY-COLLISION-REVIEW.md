# Checking the parity-collision count and its factor of two

Let \(L\) have squared minimum one and \(2\le t<5/2\). Count opposite pairs of squared length at most \(t\) by their nonzero classes \(c\) modulo \(2L\), with populations \(m_c\). Two distinct lines in one class have independent primitive representatives \(v,w\). Form \(p=(v+w)/2\), \(q=(v-w)/2\). Both lie in \(L\), and their lines are distinct. Changing the signs or order of the original representatives leaves the unordered pair of output lines unchanged. The inverse is the unordered pair of lines represented by \(p+q,p-q\). Thus distinct unordered collisions yield distinct edges of a simple graph on the output lines.

The minimum of \(p,q\) gives \(|v|^2+|w|^2\ge4\). Since both input lengths are at most \(t\), each is at least \(4-t\). Consequently
\[
 |p|^2+|q|^2\le t,\qquad |\langle p,q\rangle|\le(t-2)/2.
\]
Every output line therefore has squared length between one and \(t-1\). If \(|p|^2\in[l,r]\), its neighbors have squared length at most \(t-l\) and their absolute normalized inner product with \(p\) is at most \((t-2)/(2\sqrt l)\). For two different neighbors the ordinary minimum-length inequality bounds their absolute cosine by \(1-1/[2(t-l)]\). Projecting off \(p\) gives an alternative projective code bound in dimension \(n-1\). The certificate chooses a valid one of the two degree bounds.

The sum of all degrees counts each graph edge twice. Hence it bounds exactly \(\sum_c m_c(m_c-1)\). The verifier bounds that sum by summation by parts against the cumulative counts of output lines. If the total population is \(S=kN+b\) in \(N=2^n-1\) classes, its smallest possible collision count is \((N-b)k(k-1)+bk(k+1)\), by moving one line between any two populations differing by at least two. This minimum is nondecreasing in \(S\). Testing one count above the claimed cap is sufficient. When the first bin is just the point \(t=2\), the same argument includes orthogonal pairs of exact minima. Strict-cutoff applications only weaken the closed bound.

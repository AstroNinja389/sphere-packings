# A length inequality for a parity class with more vectors than the dimension

Scale the lattice to minimum squared length one. Take \(m>n\) representatives of distinct opposite pairs in one class modulo \(2L\). Put \(a_i=\|x_i\|^2\) and \(d_i=a_i-2\). Both \(x_i+x_j\) and \(x_i-x_j\) are nonzero in \(2L\) for \(i\ne j\), so \(2|\langle x_i,x_j\rangle|\le d_i+d_j\). Let \(k=m-n\). For any real \(\lambda\),
\[
 (2-\lambda)k\ \le\ \sum_{i=1}^m \Phi_{m,\lambda}(d_i),\qquad
 \Phi_{m,\lambda}(d)=\frac{\sqrt{(d+\lambda)^2+(m-1)(\max(d,0))^2}-(d+\lambda)}2 .
\]

To prove this, take an orthogonal projector \(P\) onto any \(k\)-dimensional subspace in the nullspace of the actual Gram matrix. Its diagonal entries \(p_i\) sum to \(k\), lie in \([0,1]\), and satisfy \(\sum_{j\ne i}P_{ij}^2=p_i(1-p_i)\). Expand the zero trace of the Gram matrix times \(P\). Bounding its off-diagonal terms using the same-class inequality, then summing each row using Cauchy–Schwarz, gives
\[
  2k\le\sum_i\{d_i^+\sqrt{(m-1)p_i(1-p_i)}-d_i p_i\}.
\]
Subtract \(\lambda\sum_i p_i\). Independently maximizing each summand over \(p_i\in[0,1]\) gives the displayed formula, using the parametrization of the upper unit semicircle by \(2p_i-1\). In particular a short vector with \(d_i<0\) contributes precisely \((-d_i-\lambda)_+\) to this upper envelope. Actual nullity greater than \(m-n\) permits choosing a subspace of the stated dimension.

Every prefix of \(m>n\) shortest vectors has this constraint. For \(m\le M\), \(\Phi_{M,\lambda}\) dominates \(\Phi_{m,\lambda}\) pointwise. Hence a single nonnegative cumulative length score can enforce all the prefix thresholds \((2-\lambda)(m-n)\) through \(M\). In a bin, maximize over both endpoints and zero if present. Convexity on each side of zero justifies this step. Round increments upward and necessities upward in the same integer units. Every actual profile remains admissible under this rounding.

There is also a direct scalar test on any dependent subset. For \(u_i=a_i-1>0\) and \(0<\alpha<1\),
\[
 \sum_i \frac{(u_i-\alpha)_+^2}{u_i}\ge 8(1-\alpha).
\]
Indeed a nonzero null relation with unsigned coefficients \(b_i\) obeys \(2\sum u_i b_i^2\le(\sum b_i)\sum(u_i-1)b_i\). Add and subtract \(\alpha\sum b_i\) in the second factor, complete the square in \(\sum b_i\), and apply weighted Cauchy–Schwarz. For a class supported below squared length three with at least two vectors, \(u_i>0\) follows from \(a_i+a_j\ge4\).

Neither statement requires a choice of independent moment vectors. The projector used in the proof is an actual projector onto relations among the given lattice vectors. To improve a density bound the new costs still have to alter a maximizing integer profile and survive its other cases.

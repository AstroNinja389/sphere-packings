# Verified lattice density upper bounds in dimensions 25–48

Run `python -B verify.py`, or supply dimensions such as `python -B verify.py 25 26 28 48`. Python, NumPy and python-flint are sufficient. The verifier recomputes the continuous sign and population conditions from exact coefficients. It first verifies the original standalone package for any rank that uses those inputs, including predecessor bounds in the reciprocal argument. BOUNDS.json gives the rational upper bounds, their outward-rounded decimals and the method used for each rank.

The compact-plane argument uses the actual two or three vector lengths in each saturated rank-two lattice. The Fourier normalization, parity-class count, short-vector sign and rank-one repair arguments are given in the adjacent proof notes. Each file is bound in MANIFEST.json. For the additional algebra cross-check on a local matrix file, run `python -B audit_plane_algebra.py FILENAME.json` in a disposable copy.

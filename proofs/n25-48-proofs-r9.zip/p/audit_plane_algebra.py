"""Second construction of each exact compact plane numerator from individual vector lengths."""
from profiles import *
from math import comb,lcm,gcd
from functools import reduce,lru_cache
from flint import fmpz_mpoly_ctx
import numpy as np
from portable_local import zonals
from plane_tensor_audit import make_controls,bisect
from free_plane_geometry import polynomial

def independent(src,kind):
    C=fmpz_mpoly_ctx.get(('x','y','z'));x,y,z=C.gens();zero=C.constant(0);one=C.constant(1)
    deg=len(src['B'])-1;pw=src['powers'];k0=pw[0];step=pw[1]-k0;m=len(pw)
    assert pw==[k0+i*step for i in range(m)] and step>0 and k0>0
    R=F(src['radius']);rad=R.numerator;q=R.denominator;assert q<rad<=2*q
    # Here the FULL two individual weights appear, before cancellation of any powers.
    h=[x,x*y,x*y*z];l=[rad-(rad-q)*t for t in h]
    G=zonals(src['n'],deg);assert len(G)==len(src['B'])
    angles=[]
    for v in G:
        assert all(not v[i] for i in range(1,v.degree()+1,2))
        angles.append([F(str(v[2*i])) for i in range(v.degree()//2+1)])
    mat=[[[F(c0)*F(a) for a in r] for r in b] for c0,b in zip(src['co'],src['B'])]
    table=[[[(sum((mat[t][i][j]*(angles[t][v] if v<len(angles[t]) else 0) for t in range(deg+1)),F(0))) for v in range(deg+1)] for j in range(m)] for i in range(m)]
    scale=lcm(*(v.denominator for m in table for row in m for v in row));nums=[[[int(v*scale) for v in row] for row in m] for m in table]
    pairs=[(0,1,2)] if kind=='cap' else [(0,1,2),(1,2,0),(2,0,1)]
    numer=zero
    for i,j,k in pairs:
        den=4*l[i]*l[j];num=z*(l[i]+l[j]-rad)**2 if kind=='cap' else (l[i]+l[j]-l[k])**2
        # Every edge has its own dot product and denominator. The remaining length
        # converts the triangle product to the common denominator 4*l0*l1*l2.
        mul=one if kind=='cap' else l[k]**deg
        powers=[den**(deg-t)*num**t for t in range(deg+1)]
        for u,e in enumerate(src['powers']):
            for v,f in enumerate(src['powers']):
                row=nums[u][v];pol=sum((a*b for a,b in zip(row,powers)),zero)
                numer-=mul*h[i]**e*h[j]**f*pol
    dd={}
    for es,a in numer.to_dict().items():
        ee=tuple(map(int,es));assert ee[0]>=2*k0 and ee[1]>=k0
        dd[(ee[0]-2*k0,ee[1]-k0,ee[2])]=int(a)
    return C.from_dict(dd)

@lru_cache(maxsize=None)
def subdivision(deg):
    # Verify both exact dyadic operators on their full linear basis, thus on any tensor fiber.
    for j in range(deg+1):
        b=np.zeros(deg+1,dtype=object);b[j]=1
        left,right=bisect(b,0)
        assert list(left)==[(comb(k,j)<<(deg-k)) if j<=k else 0 for k in range(deg+1)]
        assert list(right)==[(comb(deg-k,j-k)<<k) if j>=k else 0 for k in range(deg+1)]
    return deg

def controls(p):
    deg=list(map(int,p.degrees()));a=np.zeros(tuple(d+1 for d in deg),dtype=object)
    for coords,v in p.to_dict().items():a[tuple(map(int,coords))]=int(v)
    for i,d in enumerate(deg):
        subdivision(d);u=lcm(*(comb(d,j) for j in range(d+1)))
        T=np.array([[comb(k,j)*(u//comb(d,j)) if j<=k else 0 for j in range(d+1)] for k in range(d+1)],dtype=object)
        x=np.moveaxis(a,i,-1);a=np.moveaxis(x@T.T,-1,i)
    return a

def check(name):
    p=D/name;src=read(p);out=[]
    for kind in ['cap','triangle']:
        a=polynomial(src,kind);b=independent(src,kind)
        u=int(a.content());v=int(b.content());assert u>0 and v>0 and a*v==b*u,'physical polynomial mismatch'
        A=make_controls(a);B=controls(b)
        assert np.array_equal(v*A,u*B),'Bernstein basis mismatch'
        out.append(dict(kind=kind,degree=list(map(int,b.degrees())),coefficients=len(b.to_dict()),verified_basis_axes=[int(i) for i in b.degrees()]))
    result=dict(n=src['n'],status='PASS',source=p.name,sha=sha(p),physical_numerators=out)
    dump(D/(p.stem+'-second-algebra.json'),result);print(p.name,'independent physical identities, coefficients and dyadic operators pass',flush=True)
if __name__=='__main__':
    for name in sys.argv[1:]:check(name)

# Verifying the lattice bounds in dimensions 25–48

Run `python -B verify.py` in this directory using Python 3, NumPy and python-flint. To check individual dimensions use `python -B verify.py 25 36 48`. The verifier reads the frozen input files and prints one line for each verified dimension. The full replay checks every file against MANIFEST.json, then recomputes the mathematical inequalities. It uses CPU arithmetic and needs no network connection or optimization solver.

BOUNDS.json records the exact outward rational bound and its display decimal. The quantities are ordinary sphere-packing densities for lattices of the indicated rank. Each Fourier transform has been checked on the whole nonnegative axis. The results use the origin term alone on the reciprocal side. They apply to arbitrary real lattices.

- [Fourier normalization, parity classes, angular counts and integer budgets](PROOF-parity-Fourier.md)
- [Compact plane bounds, spherical restriction and the origin cost](PROOF-compact.md)
- [Full rational verification of the compact source](PLANE-POLYNOMIAL-PROOF.md)

The upstream directory contains numerical certificate data from [SpherePackings at the pinned revision](https://github.com/alexlegeartis/SpherePackings/tree/9a9851887da20ca75825342bfb09e8ab031f4153/verifications/lattice). Source provenance is recorded in pinned-input-hashes.json. Each inherited angular row and each compact geometric input used by these bounds is reverified. The Fourier coefficients, combined budgets and final density certificates are the ones used in this run.

A primitive vector and its integer multiples may be grouped on one line. The base bins end below squared length four, so each included line is primitive. All additional multiples are past the nonpositive spatial cutoff and distinct across base lines. Their separate signed bin maxima therefore give valid upper bounds. In the higher-dimensional certificates, a plane correction can enter the continuous radial height before the interval maximum is taken. The second verifier checks that combined height over each entire bin.

The package targets the software already used by the project. Python optimization mode disables assertions and is rejected.

## Additional extremizer verification

The checker also reproduces the translated-tail inequality using one eutaxy measure on exact minimum vectors. It reserves the exact minimum count forced by perfection and verifies every rational angular rectangle, including the exceptional parallel vector. The extremizer exists in every dimension covered here. See [the proof](EUTAXY-TRANSLATED-TAIL.md).

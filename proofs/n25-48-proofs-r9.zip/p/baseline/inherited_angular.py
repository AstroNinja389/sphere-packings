"""Check a pinned short-window angular inequality using its rational coefficients alone."""
from fractions import Fraction as F
from audit_angular import poly, nonnegative
from audit_geometry import sphere
from flint import fmpq as Q

def verify(n,edges,cut):
    edges=list(map(F,edges));J=edges.index(2);L,U=map(F,cut['source_interval'])
    assert cut['n']==n and L==edges[0]==1 and U in edges[1:J] and U<F(5,4)
    b=list(map(F,cut['gegenbauer_even']));assert b[0]==1 and min(b)>=0
    g=poly(n,b);h=F(str(g(1)));K=F(cut['constant']);assert K>0 and h==F(cut['f1'])
    assert nonnegative(-g,0,(U-1)**2)
    assert len(cut['caps'])==len(cut['weights'])==J
    weights=[]
    for j,(l,r) in enumerate(zip(edges[:J],edges[1:J+1])):
        data=cut['caps'][j];m=F(data['M']);assert m>=0
        lo=max(F(0),(2-r)/(2*U));hi=min(1-1/(2*U),(2*U-l)/2)
        assert 0<=lo<=hi<1 and nonnegative(Q(str(m))-g,lo**2,hi**2)
        R=U-l/4; eta=(U-1)**2/(l*(4-l))
        assert F(1,2)<=R<1 and eta<1
        z=(1-1/(2*R)+eta)/(1-eta);dim=n-1
        assert 0<=z<1
        candidates=[]
        for i in range(3):
            # Rodrigues coefficients for t^(2i)*(t²-z²). A monomial's
            # derivative has positive factor (2d)!/(2d-2k)!.
            from math import factorial
            cs=[]
            for k in range(i+2):
                s=F(0)
                for d,coef in [(i,-z*z),(i+1,F(1))]:
                    if k<=d:s+=coef*F(factorial(2*d),factorial(2*d-2*k))*sphere(dim+4*k,d-k)
                cs.append(s)
            if cs[0]>0 and min(cs)>=0:candidates.append((1-z*z)//cs[0])
        C=data['C'];assert candidates and C>=2*min(candidates)
        weights.append((2-h/K if r<=U else F(0))-C*m/K)
    assert weights==list(map(F,cut['weights']))
    return weights,K/(2**n-1)

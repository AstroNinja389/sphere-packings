"""Verify the extremizer's payment using the actual Fourier polynomial and a common eutaxy measure."""
from fractions import Fraction as F
from bisect import bisect_left,bisect_right
from profiles import up,read,sha
from independent_fourier import gaussian_bins,nonnegative_ray
from audit_price import check_density

def check(proof_file,source_file,data):
    n=data['report']['n'];T=data['tau'];p=data['p'];q=data['q'];E=data['E']
    A=E[:len(data['values'])];N=(1<<n)-1
    w=read(proof_file);W=w['signed_upper'];B=list(map(F,w['edges']));m=w['sub'];u=w['unit']
    assert data['report']['unconditional_fourier_sign'] and q(0)>0
    assert 0<n and w['n']==n and w['dependencies']==[source_file.name]
    assert E[0]==A[0]==1 and A[-1]==2 and 2<E[-1]==B[0]<5 and B[-1]==5
    assert A==list(map(F,w['short_edges'])) and len(w['rows'])==len(A)-1
    assert all(x<y for x,y in zip(B,B[1:])) and len(W)+1==len(B)
    assert type(u)==int and u>0 and type(m)==int and m>0 and all(type(k)==int and k<=0 for k in W)
    assert nonnegative_ray(-p,T*B[0])
    heights=gaussian_bins(N*p,T,B,W,u)
    def payment(lo,hi,v):
        assert 0<=v and 1<=lo<=hi<=5
        if lo<B[0]:return F(0)
        i=min(len(W)-1,bisect_right(B,lo)-1);j=max(i,bisect_left(B,hi)-1)
        assert B[i]<=lo<=hi<=B[j+1]
        return F(n*v*v,2*hi*u)*max(W[i:j+1])
    corrected=data['values'][:];boxes=0
    for i,(l,h) in enumerate(zip(A,A[1:]),1):
        slope,upper=map(F,w['rows'][i-1]);assert upper<=0
        if upper==0:continue
        intercept=upper-slope*4/(n*(l if slope>=0 else h))
        if i==1:assert intercept+4*slope>=0
        for k in range(m):
            a,b=F(k,m),F(k+1,m)
            plus=payment(1+l*(1+a),1+h*(1+b),2+l*a)
            minus=payment(1+l*(1-b),1+h*(1-a),2-h*b)
            cap=min(intercept+slope*a*a,intercept+slope*b*b)
            assert plus+minus<=cap,(n,i,k)
            boxes+=1
        corrected[i]+=upper
    g=n*(n+1)//2
    # Put g compulsory minima in the first occupied bin. For all others integrate
    # a nonincreasing upper envelope against successive certified prefix capacities.
    def budget(forced):
        tail=corrected[0];env=[]
        for x in reversed(corrected[1:]):
            tail=max(tail,x);env.append(tail)
        total=forced*corrected[1];prev=0
        for end,score in zip(A[1:],reversed(env)):
            lim=min([N]+[v for t,v in data['prefix'].items() if t>=end])-forced
            assert prev<=lim<=N-forced
            total+=(lim-prev)*score;prev=lim
        total+=(N-forced-prev)*corrected[0]
        return (F(str(p(0)))+data['bonus']+total/N)/F(str(q(0)))
    rho=budget(g);raw=budget(0)
    assert raw==F(w['rho']) and rho<=raw
    bound=up(n,T,rho,23);check_density(n,T,rho,bound)
    return dict(n=n,status='PASS',upper=str(bound),exact_minimum_pairs=g,sign_rectangles=boxes,tail_nodes=heights,source_sha256=sha(source_file),payment_sha256=sha(proof_file))

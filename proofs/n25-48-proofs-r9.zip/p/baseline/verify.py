"""Verify every bound in this package without a solver, a network connection, or a saved proof log."""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json,sys,time

def main():
    if not __debug__:raise RuntimeError('Run without -O. The proof verification uses assertions.')
    folder=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('dimension',nargs='*',type=int)
    a=p.parse_args();manifest=json.loads((folder/'MANIFEST.json').read_bytes())
    for name,h in manifest.items():
        f=(folder/name).resolve()
        assert f.is_relative_to(folder) and hashlib.sha256(f.read_bytes()).hexdigest()==h,name
    from independent_master import verify
    from portable_eutaxy import check
    rows=json.loads((folder/'BOUNDS.json').read_bytes())
    for n in a.dimension or list(map(int,rows)):
        start=time.monotonic();row=rows[str(n)];f=folder/row['certificate']
        result=verify(f,True,portable=True);base=result['report']
        assert base['n']==n and base['status']=='PASS' and base['unconditional_fourier_sign']
        assert Fraction(base['upper'])==Fraction(row['base_upper'])
        out=check(folder/row['eutaxy_payment'],f,result)
        assert out['n']==n and out['status']=='PASS' and Fraction(out['upper'])==Fraction(row['upper'])
        print(f"Verified dimension {n}: {row['display']}; {out['exact_minimum_pairs']} compulsory minimum pairs; {time.monotonic()-start:.1f} seconds",flush=True)
if __name__=='__main__':main()

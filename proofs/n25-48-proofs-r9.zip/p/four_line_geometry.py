"""A rational local four-line verifier on reduced Gram matrices, using individual radii at every pair."""
from profiles import *
from flint import fmpq as Q,fmpq_poly as P
from itertools import product
from math import comb
from functools import lru_cache
from audit_angular import poly
def image(R,pt):
    x,y,z=pt;D=R-2;a=1+D*x/2;b=a+D*(1-x)*y;u=D*(1-x)*(1-y)*z
    L=[a,b,a+b-u,a+b+u]
    return L,[u,u-2*a,u+2*a,2*b-u,2*b+u,2*(b-a)]
edges=((0,1),(0,2),(0,3),(1,2),(1,3),(2,3))
def tensor(src):
    n=src['n'];w=list(map(F,src['co']));return {(i,j):poly(n,[a*F(b[i][j]) for a,b in zip(w,src['B'])]) for i in range(3) for j in range(i,3)}
def direct(src,pt):
    A=tensor(src);R=Q(src['radius']);L,S=image(R,list(map(lambda u:Q(str(u)),pt)));h=[(R-a)/(R-1) for a in L];pw=src['powers'];res=Q(0)
    for (i,j),z in zip(edges,S):
        u=z*z/(4*L[i]*L[j])
        for l in range(3):
            for k in range(3):res+=h[i]**pw[l]*h[j]**pw[k]*A[min(l,k),max(l,k)](u)
    return res

def check(src,limit=6000):
    R=Q(src['radius']);assert 2<R<=3
    P0=tensor(src);K=len(src['co'])-1;b,s0,s1=src['powers'];s=s0-b;assert s1==b+2*s and min(b,s)>0
    pairs=list(P0);factors=[[(j,Q(comb(i,j),comb(K,j))) for j in range(i+1)] for i in range(K+1)]
    @lru_cache(maxsize=5000)
    def angular(l,r):
        shift=P([l,r-l]);a=[p(shift) for p in P0.values()]
        return [[sum((c*z[j] for j,c in weights),Q(0)) for z in a] for weights in factors]
    @lru_cache(maxsize=2000)
    def shape(lo,hi):
        l=lo**s;r=hi**s
        return [(1,l,l*l),(1,(l+r)/2,l*r),(1,r,r*r)]
    def upper(box):
        vals=[image(R,[box[i][j] for i,j in enumerate(bits)]) for bits in product((0,1),repeat=3)]
        lengths=[(min(x[0][i] for x in vals),max(x[0][i] for x in vals)) for i in range(4)]
        h=[((R-r)/(R-1),(R-l)/(R-1)) for l,r in lengths];assert all(0<=l<=r<=1 for l,r in h) and min(h[0][0],h[1][0])>0
        def rat(i,j):return h[i][0]/h[j][1],h[i][1]/h[j][0]
        weights=[(1,1),rat(2,1),rat(3,1),rat(2,0),rat(3,0),tuple(l*r for l,r in zip(rat(2,0),rat(3,1)))]
        accum=Q(0)
        for k,((i,j),weight) in enumerate(zip(edges,weights)):
            if weight[1]==0:continue
            v=[row[1][k] for row in vals];l,r=min(v),max(v)
            usq=(Q(0) if l<=0<=r else min(l*l,r*r))/(4*lengths[i][1]*lengths[j][1]);vsq=min(Q(1),max(l*l,r*r)/(4*lengths[i][0]*lengths[j][0]))
            A=angular(usq,vsq);hi=None
            for X,Y in product(shape(*h[i]),shape(*h[j])):
                uv=[X[m]*Y[n]+(X[n]*Y[m] if m!=n else 0) for m,n in pairs]
                value=max(sum((r*c for r,c in zip(row,uv)),Q(0)) for row in A)
                hi=value if hi is None else max(hi,value)
            accum+=hi*(weight[1] if hi>=0 else weight[0])**b
        return accum
    root=tuple((Q(0),Q(1)) for _ in range(3));stack=[(root,0)];count=0;depth=0
    while stack and count<limit:
        box,k=stack.pop();count+=1;depth=max(depth,k)
        if upper(box)<=0:continue
        for bits in product((0,1),repeat=3):
            pt=[box[i][j] for i,j in enumerate(bits)]
            if direct(src,pt)>0:return dict(status='VIOLATED',kind='four',nodes=count,point=list(map(str,pt)))
        if k>72:return dict(status='UNRESOLVED',kind='four',nodes=count,depth=k)
        ax=k%3;l,r=box[ax];m=(l+r)/2
        for interval in [(l,m),(m,r)]:stack.append((box[:ax]+(interval,)+box[ax+1:],k+1))
    return dict(status='PASS' if not stack else 'INCOMPLETE',kind='four',nodes=count,pending=len(stack),depth=depth)
if __name__=='__main__':
    for arg in sys.argv[1:]:
        p=D/arg;o=check(read(p));dump(D/(p.stem+'-four-line-sign.json'),dict(sha=sha(p),result=o));print(arg,o,flush=True)

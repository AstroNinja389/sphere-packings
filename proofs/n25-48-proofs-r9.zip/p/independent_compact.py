"""Alternative compact-plane certificate checker with exact restriction and a differential remainder."""
from profiles import *
from independent_fourier import transform,nonnegative_ray
from audit_angular import poly
from audit_geometry import sphere
from audit_price import check_density
from flint import fmpq as Q, fmpq_poly as P, fmpq_mat as M
from math import comb,factorial

def compact_data(c):
    from external_profiles import L
    pinned=read(D/'pinned-input-hashes.json')['files']; root=L.parents[1]
    terms=[];s=Q(0);refs={};n=c['n']
    for atom in c['kernels']:
        if 'local_kernel' in atom:
            from portable_local import terms as local_terms
            from free_plane_geometry import check
            cost,one,files=local_terms(dict(n=n,kernels=[atom]))
            for name,digest in files.items():check(name,digest,atom['source'])
            s+=cost;terms.extend(one)
            continue
        d=atom['source'];assert n<=d
        # Require an actual instance of the source theorem, bound to the exact snapshot hash.
        paths=[p for shape in ('compact*/dim'+str(d)+'/input/frozen.json',
                                'compact*/source'+str(d)+'/input/frozen.json',
                                'compact*/transfers/dim'+str(d)+'/frozen.json')
               for p in L.glob(shape) if sha(p)==atom['source_sha']]
        assert paths,(d,atom['source_sha'])
        file=paths[0];src=read(file);pinned_key=file.relative_to(root).as_posix()
        assert sha(file)==pinned[pinned_key];pack=file.relative_to(L).parts[0]
        refs[pack]=dict(frozen=pinned_key,hash=sha(file))
        b=list(map(Q,src['co']));q=Q(src['q']);assert b[0]==1 and sum(b)==q and min(b)>=0
        assert src['n']==d and src['powers']==[6,9,12] and len(src['B'])==len(b)
        m0=M(3,3);diag=M(3,3)
        for j,(beta,mat) in enumerate(zip(b,src['B'])):
            mat=M([[Q(t) for t in row] for row in mat]);assert mat==mat.transpose()
            for k in (1,2,3):assert M([[mat[i,l] for l in range(k)] for i in range(k)]).det()>0
            # The constant harmonic after restriction is its actual spherical average in R^n.
            g=poly(d,[F(0)]*j+[F(1)])
            coef=sum((g[i]*Q(str(sphere(n,i))) for i in range(j+1)),Q(0))
            assert coef>=0
            m0+=beta*coef*mat;diag+=beta*mat
        alpha=Q(atom['alpha']);sc=Q(atom['dilation']);z=M(3,1,list(map(Q,atom['z'])))
        assert alpha>0 and sc>=1
        v=m0.solve(z);assert m0*v==z
        s+=(z.transpose()*v)[0,0]/alpha
        h=P([Q(19,6),-Q(13,6)*sc]);hs=[h**i for i in (6,9,12)]
        # Work directly with one vector feature H/q per signed lattice vector.
        corr=sum((2*z[i,0]*hs[i]/q for i in range(3)),P([0]))
        for i in range(3):
            for j in range(3):corr+=2*alpha*diag[i,j]*hs[i]*hs[j]/q**2
        cut=Q(atom.get('cutoff',str(Q(19,13)/sc)));assert 1<=cut<=Q(19,13)/sc
        if cut>1:terms.append((cut,corr))
    return s,terms,refs

def differential_check(p,tau,terms):
    """Degree-four Bernstein majorant with an independent rigorous fifth-derivative error."""
    order=4
    pp=[p]
    for _ in range(order+1):pp.append(tau*(pp[-1].derivative()-pp[-1]/2))
    edges=sorted({Q(1)}|{v for v,_ in terms})
    count=0;depth=0
    for l0,r0 in zip(edges,edges[1:]):
        G=[sum((pol for end,pol in terms if end>=r0),P([0]))]
        for _ in range(order+1):G.append(G[-1].derivative())
        for j in range(32):
            todo=[(l0+(r0-l0)*j/32,l0+(r0-l0)*(j+1)/32,0)]
            while todo:
                l,r,k=todo.pop();count+=1;depth=max(depth,k);assert k<=55
                e=(-arb(tau*l)/2).exp();h=r-l;m=(l+r)/2
                coef=[(arb(pp[i](tau*l))*e+arb(G[i](l)))*arb(h**i/factorial(i)) for i in range(order+1)]
                # Bound the fifth derivative on the whole interval, independently in the two summands.
                shift=P([m,h/2]);dp=pp[-1](tau*shift);dg=G[-1](shift)
                upper=(e*arb(sum(map(abs,dp.coeffs()),Q(0)))+arb(sum(map(abs,dg.coeffs()),Q(0))))*arb(h**(order+1)/factorial(order+1))
                if all(sum((coef[i]*arb(Q(comb(x,i),comb(order,i))) for i in range(x+1)),arb(0))+upper<=0 for x in range(order+1)):continue
                assert arb(p(tau*m))*(-arb(tau*m)/2).exp()+arb(G[0](m))<=0,('positive spatial midpoint',l,r)
                todo.extend([(l,m,k+1),(m,r,k+1)])
    return count,depth

def verify(tag,require_sources=True):
    assert __debug__
    ctx.prec=512;cf=D/(tag+'.json');c=read(cf);n=c['n'];tau=Q(c['tau']);p,q=transform(n,c['d'])
    s,terms,refs=compact_data(c);R=max([x for x,_ in terms]+[Q(1)])
    assert nonnegative_ray(q,0) and q(0)>0 and nonnegative_ray(-p,tau*R)
    nodes,depth=differential_check(p,tau,terms)
    rho=F(str((p(0)+s)/q(0)));upper=up(n,F(str(tau)),rho,24);check_density(n,F(str(tau)),rho,upper)
    packages_ok=True
    for pack,ref in refs.items():
        record=D/f'replay-{pack}.json';log=D/f'replay-{pack}.log'
        if not record.exists():packages_ok=False;continue
        r=read(record);assert r['returncode']==0 and r['package']==pack and '--quick' not in r['arguments'] and r['log_sha256']==sha(log)
        if '--dimension' in r['arguments']:raise ValueError('Expected complete package replay')
        ref['replay_sha256']=sha(record)
    if require_sources:assert packages_ok,'Source geometry replay is pending'
    result=dict(status='PASS' if packages_ok else 'WAITING_FOR_SOURCE_GEOMETRY',n=n,upper=str(upper),density=float(upper),origin=str(s),denom=str(q(0)),rho=str(rho),nodes=nodes,depth=depth,sources=refs,source_sha=sha(cf),dual_nonnegative_from_zero=True)
    dump(D/(tag+'-standalone.json'),result);print(n,result['status'],result['density'],nodes,flush=True)
    return result
if __name__=='__main__':
    for name in sys.argv[1:]:
        if name!='--provisional':verify(name,'--provisional' not in sys.argv)

"""Two independent sign enclosures on every interval for a positive mixture of Fourier scales."""
from profiles import *
from portable_local import terms
from independent_compact import compact_data
from independent_fourier import transform,nonnegative_ray
from polynomial_tools import laguerre,sign_half
from free_plane_geometry import check
from audit_price import check_density
from flint import fmpq as Q,fmpq_poly as P,arb_poly
from math import factorial
from functools import lru_cache
def signs(src,spatial,parts,kind,tmax):
    count=0;depth=0;cuts=sorted({Q(1),tmax}|{r for r,_ in parts if 1<r<tmax}|{Q(1)+(tmax-1)*Q(j,90) for j in range(91)})
    K=8 if kind=='center' else 3
    for a,b in zip(cuts,cuts[1:]):
        G=sum((g for r,g in parts if r>=b),P([0]))
        todo=[(a,b,0)]
        while todo:
            l,r,dep=todo.pop();count+=1;depth=max(depth,dep)
            if kind=='center':
                m=(l+r)/2;h=(r-l)/2;x=P([m,h]);add=arb_poly([arb(t) for t in G(x).coeffs()]);err=arb(0)
                for (T,coef,p) in spatial:
                    ps=(coef*p)(T*x);c=arb_poly([arb(y)*(-arb(T*m)/2).exp() for y in ps.coeffs()])
                    w=T*h/2;ef=arb_poly([arb((-w)**j/factorial(j)) for j in range(K+1)])
                    add+=c*ef;err+=sum((abs(v) for v in c.coeffs()),arb(0))*arb(w**(K+1)/factorial(K+1))*arb(w).exp()
                upper=add[0]+sum((abs(v) for v in add.coeffs()[1:]),arb(0))+err
                if upper<=0:continue
                value=add[0]
            else:
                h=r-l;X=P([l,h]);qg=[G]
                for _ in range(3):qg.append(qg[-1].derivative())
                c=[arb(qg[i](l))*arb(h**i/factorial(i)) for i in range(3)]
                rem=arb(sum(map(abs,qg[3](X).coeffs()),Q(0)))*arb(h**3/6)
                for t,v,p in spatial:
                    poly=p;e=arb(v)*(-arb(t*l)/2).exp();assert e>0
                    for i in range(3):
                        c[i]+=e*arb(poly(t*l)*h**i/factorial(i));poly=t*(poly.derivative()-poly/2)
                    rem+=e*arb(sum(map(abs,poly(t*X).coeffs()),Q(0))*h**3/6)
                if all(v+rem<=0 for v in (c[0],c[0]+c[1]/2,sum(c))):continue
                value=c[0];m=(l+r)/2
            if value>0 or dep>=50:raise ArithmeticError(('physical sign unresolved or violated',str(l),str(r),kind,str(value),dep))
            todo.extend([(l,m,dep+1),(m,r,dep+1)])
    return count,depth
def verify(tag,save=True):
    f=D/(tag+'.json');o=read(f);n=o['n'];T=F(o['tau']);R=Q(o['finite_end']);assert n>=3 and T>0 and R>=1
    ctx.prec=640;P0=Q(0);den=Q(0);spatial=[];deps={}
    for a in o['sources']:
        cf=D/a['file'];assert cf.parent==D and sha(cf)==a['hash'];c=read(cf);assert c['n']==n
        s=F(a['s']);w=Q(a['weight']);assert w>0 and s>0
        wt=Q(str(T*s*s));p,q=transform(n,c['d']);pp,qq=laguerre(n,c['d']);assert p==pp and q==qq and q(0)>0
        assert nonnegative_ray(q,0) and sign_half(qq,0)['pass_sign'] and nonnegative_ray(-p,wt*R) and sign_half(-pp,wt*R)['pass_sign']
        P0+=w*p(0);den+=w*q(0)/Q(str(s**n));spatial.append((wt,w,p));deps[cf.name]=sha(cf)
    source=dict(n=n,kernels=o['kernels']);paid,g,refs=terms(source);s1,g1,_=compact_data(source);assert paid==s1 and g==g1
    assert all(r<=R for r,_ in g)
    geometric={}
    for k in source['kernels']:geometric[k['local_kernel']]=check(k['local_kernel'],k['source_sha'],k['source'])
    assert den>0;aa=signs(o,spatial,g,'center',R);bb=signs(o,spatial,g1,'left',R)
    rho=F(str((P0+paid)/den));upper=up(n,T,rho,24);check_density(n,T,rho,upper)
    out=dict(n=n,status='PASS',density=float(upper),upper=str(upper),rho=str(rho),source_sha=sha(f),physical_center=aa,physical_left=bb,source_hashes=deps,kernel_hashes=refs,geometry=geometric,scales=len(spatial))
    if save:dump(D/(tag+'-final-packing-proof.json'),out)
    print(tag,'exact positive mixture',len(spatial),float(upper),aa,bb,flush=True);return out
if __name__=='__main__':verify(sys.argv[1])

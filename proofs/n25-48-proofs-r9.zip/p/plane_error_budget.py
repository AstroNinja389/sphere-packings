"""Upper bounds on the weighted population used to pay exceptional plane interactions."""
from profiles import *
from functools import lru_cache
from math import isqrt
from audit_geometry import check_prefix

def count_cap(n,R):
    N=2**n-1
    if R<=2:return N
    z=1-2/R
    if n*z*z<1:return N*int(n*(1-z*z)/(1-n*z*z))
    # Compare disjoint open balls of radius 1/2 inside a ball of radius sqrt(R)+1/2.
    s=10**6;u=isqrt(R.numerator*s*s//R.denominator)+1
    return int((1+2*F(u,s))**n)
def bound(n,R,b,prefix_rows):
    assert 1<R<=3 and b>0 and type(b)==int and n>=3
    entries={}
    for row in prefix_rows:
        x=F(row['end']);assert 1<=x<2
        if x<=1 or x>=R:continue
        k=check_prefix(n,row);assert k==row['cap']
        entries[x]=min(k,entries.get(x,k))
    if R>2:entries[F(2)]=2**n-1
    grid=[F(1),*sorted(entries),R];caps=[entries[x] for x in grid[1:-1]]+[count_cap(n,R)]
    # Strict prefixes suffice even if a shell has vectors exactly at a grid endpoint.
    for i in reversed(range(len(caps)-1)):caps[i]=min(caps[i],caps[i+1])
    last=0;total=F(0)
    for x,k in zip(grid,caps):
        total+=(k-last)*((R-x)/(R-1))**b;last=k
    return total

@lru_cache(maxsize=100)
def verify(name,digest,d,R,b):
    p=D/name;assert p.parent==D and sha(p)==digest
    data=read(p);assert data['n']==d and F(data['radius'])==R and data['power']==b
    C=bound(d,R,b,data['prefix_rows']);assert C==F(data['bound']);return C

def debit(src):
    delta=F(src.get('angular_debit',0))
    if not delta:return F(0),F(0)
    assert delta>0
    C=verify(src['weight_cap_file'],src['weight_cap_sha'],src['n'],F(src['radius']),src['powers'][0])
    return delta,C

def for_sign(src):
    delta=F(src.get('angular_debit',0))
    if not delta:return src
    assert delta>0 and F(src['co'][0])==1
    # B0 minus this term is used only for the geometric sign. PSD and the
    # Schur cost always use the original, unsubtracted matrix.
    first=[row[:] for row in src['B'][0]];first[0][0]=str(F(first[0][0])-delta)
    return dict(src,B=[first,*src['B'][1:]],angular_debit='0')

def create(n,r,b,tag):
    R=F(r);raw=read(D/f'prefix-{n}-degree7.json')
    rows=[v for v in raw.values() if 1<F(v['end'])<min(2,R)]
    # Keep at most 30 high-quality prefix certificates. Every subset of the
    # original rows gives a valid independent weighted bound.
    rows.sort(key=lambda v:F(v['end']))
    if len(rows)>30:rows=[rows[(len(rows)-1)*j//29] for j in range(30)]
    C=bound(n,R,b,rows);p=D/(tag+'-weight-count.json');dump(p,dict(n=n,radius=str(R),power=b,prefix_rows=rows,bound=str(C)));return p,C

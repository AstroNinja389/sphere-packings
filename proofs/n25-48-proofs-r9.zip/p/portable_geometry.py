"""Independently prove every distinct source geometry during a standalone replay."""
from profiles import *
from external_profiles import L
from functools import lru_cache
from plane_tensor_audit import verify

@lru_cache(maxsize=None)
def check(d,source_sha):
    candidates=[p for s in (f'compact*/dim{d}/input/frozen.json',f'compact*/source{d}/input/frozen.json',f'compact*/transfers/dim{d}/frozen.json') for p in L.glob(s)]
    p=next(p for p in candidates if sha(p)==source_sha)
    assert read(p)['n']==d
    r=verify(p,save=False)
    assert r['status']=='PASS' and r['pending']==0 and r['frozen_sha']==source_sha and r['n']==d
    return p
def all_sources(c):
    out={p.relative_to(L.parents[1]).as_posix():sha(p) for atom in c['kernels'] if 'local_kernel' not in atom for p in [check(atom['source'],atom['source_sha'])]}
    for k in c['kernels']:
        if 'local_kernel' in k:
            from free_plane_geometry import check as local
            local(k['local_kernel'],k['source_sha'],k['source']);out[k['local_kernel']]=k['source_sha']
    return out

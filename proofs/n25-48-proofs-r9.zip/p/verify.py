"""Offline replay of the best 25--48 bounds and any lower-rank prerequisite used by a reciprocal certificate."""
from pathlib import Path
import argparse,hashlib,json,sys,subprocess,time
from fractions import Fraction as F

def main():
    if not __debug__:raise RuntimeError('Run without -O.')
    D=Path(__file__).resolve().parent
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('dimensions',nargs='*',type=int);aa=ap.parse_args()
    read=lambda f:json.loads(f.read_bytes());manifest=read(D/'MANIFEST.json')
    for name,h in manifest.items():
        f=(D/name).resolve();assert f.is_relative_to(D) and hashlib.sha256(f.read_bytes()).hexdigest()==h,name
    rows=read(D/'BOUNDS.json');ns=aa.dimensions or list(range(25,49));assert all(25<=n<=48 for n in ns)
    base=read(D/'baseline/BOUNDS.json')
    ranks=set(ns)
    for n in reversed(range(25,49)):
        if n in ranks and rows[str(n)]['mode']=='flag':ranks.update(m for m in (n-2,n-1) if m>=25)
    ns=sorted(ranks)
    needed={n for n in ns if rows[str(n)].get('parent',rows[str(n)])['mode']=='baseline'}
    needed.update(n-1 for n in ns if rows[str(n)].get('parent',rows[str(n)])['mode']=='reciprocal-plane' and n>=26)
    if needed:subprocess.run([sys.executable,'-B',str(D/'baseline/verify.py'),*map(str,sorted(needed))],check=True)
    from independent_master import verify
    from portable_eutaxy import check as check_eutaxy
    from independent_fourier import transform,nonnegative_ray
    from independent_compact import compact_data,differential_check
    from portable_geometry import all_sources
    from audit_price import check_density
    from flint import arb,ctx,fmpq as Q
    ctx.prec=512
    def ordinary(n,row):
        mode=row['mode'];upper=F(row['upper'])
        if mode=='baseline':assert upper==F(base[str(n)]['upper'])
        elif mode in ('population','population-eutaxy','population-rank'):
            source=D/row['certificate'];data=verify(source,True,portable=True)
            assert data['report']['n']==n and data['report']['unconditional_fourier_sign']
            if mode=='population-eutaxy':
                assert F(check_eutaxy(D/row['payment'],source,data)['upper'])==upper
            elif mode=='population-rank':
                from rank_ledger import verify as rank
                assert F(rank(read(D/row['rank_prices']),data)['upper'])==upper
            else:assert F(data['report']['upper'])==upper
        elif mode=='mixed-scale':
            from mixed_scale_audit import verify as mixed
            assert F(mixed(Path(row['certificate']).stem,False)['upper'])==upper
        else:
            assert mode in ('plane','reciprocal-plane')
            c=read(D/row['certificate']);assert c['n']==n
            T=Q(c['tau']);p,q=transform(n,c['d']);assert q(0)>0
            def radial(poly,t,atoms):
                cert=dict(n=n,kernels=atoms);s,parts,_=compact_data(cert);all_sources(cert)
                R=max([Q(1)]+[r for r,_ in parts]);assert nonnegative_ray(-poly,t*R)
                differential_check(poly,t,parts)
                return s
            num=p(0)+radial(p,T,c['kernels']);den=q(0)
            if mode=='plane':assert nonnegative_ray(q,0)
            else:
                target,prev=map(F,[c['dual_target'],c['dual_previous']]);g=Q(c['dual_gap']);assert Q(0)<g and 0<target<=upper and prev>0
                if n==25:assert arb.pi()**12/479001600<=arb(Q(str(prev)))
                else:assert (n-1) in needed and F(base[str(n-1)]['upper'])<=prev
                a=arb(Q(n,2));ratio=(a+1).gamma()/((a+arb(1)/2).gamma()*arb.pi().sqrt())
                assert arb(g)<(4*arb.pi()*ratio*arb(Q(str(target/prev))))**2/arb(T)
                den-=radial(-q,g,c['reciprocal_kernels'])
            assert den>0
            check_density(n,F(str(T)),F(str(num/den)),upper)
    for n in ns:
        st=time.monotonic();row=rows[str(n)];mode=row['mode']
        if mode!='flag':ordinary(n,row)
        else:
            parent=row['parent'];ordinary(n,parent);pm=parent['mode']
            assert pm in ('baseline','population','population-eutaxy','population-rank','plane')
            root=D/'baseline' if pm=='baseline' else D
            par=base[str(n)] if pm=='baseline' else parent;name=par['certificate'];cf=root/(name.split('-rigorous')[0]+'.json') if '-rigorous' in name else root/name
            doc=read(D/row['certificate']);g=doc['geometry'];c=read(cf);assert c['n']==doc['n']==n and not c.get('dual_gap')
            assert cf.name==doc['prior_fourier'] and hashlib.sha256(cf.read_bytes()).hexdigest()==doc['prior_sha'] and F(parent['upper'])==F(g['upper'])
            from portable_flag import audit_domain,tree
            def predecessor(m,claim):
                if m==24:
                    assert arb.pi()**12/479001600<=arb(Q(str(claim)));return claim
                assert m in ns and m>=25
                return F(rows[str(m)]['upper'])
            U=F(parent['upper']);T=F(c['tau']);p1,p2=F(g['pre1']),F(g['pre2'])
            audit_domain(n,T,g,U,predecessor(n-1,p1),predecessor(n-2,p2))
            _,q=transform(n,c['d']);assert q(0)>0 and F(str(q(0)))==F(doc['den'])
            amt,_=tree(n,q,g,doc,D/doc['mesh']);den=F(doc['den'])
            assert max(F(g['target']),U*den/(den+amt))==F(row['upper'])
        print(f"Verified final rank {n}, upper {row['display']}, {mode}, {time.monotonic()-st:.1f} seconds",flush=True)
if __name__=='__main__':main()

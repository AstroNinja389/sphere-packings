"""Replay every selected mathematical certificate in a clean offline process."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
def main():
    if not __debug__:raise RuntimeError('Verification must run without -O.')
    folder=Path(__file__).resolve().parent;base=folder/'p'
    read=lambda f:json.loads(f.read_bytes());digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
    aa=argparse.ArgumentParser();aa.add_argument('dimensions',nargs='*',type=int);ns=aa.parse_args().dimensions or list(range(25,49))
    assert all(25<=n<=48 for n in ns)
    manifest=read(folder/'MANIFEST.json')
    for name,h in manifest.items():
        f=(folder/name).resolve();assert f.is_relative_to(folder) and digest(f)==h,name
    subprocess.run([sys.executable,'-B','-u',str(base/'verify.py'),*map(str,ns)],cwd=base,check=True)
    sys.path.insert(0,str(base))
    from verify_contact_payment import audit
    from verify_origin_saving import verify
    rows=read(folder/'BOUNDS.json');orig=read(base/'BOUNDS.json')
    extra=[n for n in ns if rows[str(n)].get('alternative_base')]
    if extra:
        for k in {rows[str(n)]['alternative_base'] for n in extra}:
            assert k in ('p2','p3')
            alt=folder/k;ns1=[n for n in extra if rows[str(n)]['alternative_base']==k]
            subprocess.run([sys.executable,'-B','-u',str(alt/'verify.py'),*map(str,ns1)],cwd=alt,check=True)
    for n in ns:
        r=rows[str(n)];old=F(orig[str(n)]['upper']);assert r['n']==n and old==F(r['ordinary'])
        if r['method']=='ordinary':bound=old
        elif r['method']=='new-parent':
            assert n in extra and r['alternative_base']=='p3';bound=F(read(folder/'p3/BOUNDS.json')[str(n)]['upper'])
        else:
            record=read(folder/r['evidence']);assert record['n']==n
            if r['method']=='minimum-plane':
                res=audit(base,record)
            else:
                assert r['method']=='origin-reallocation'
                res=verify(folder/'p2' if n in extra else base,record,folder/'kernels'/record['kernel'])
            assert res['n']==n and res['status']=='PASS';bound=F(res['upper'])
        assert 0<bound<=old and str(bound)==r['upper'] and F(r['display'])>=bound
        print('Final exact bound',n,r['display'],r['method'],flush=True)
if __name__=='__main__':main()

"""Solver-free independent composition of compulsory minimum-plane slack with a replayed parent proof."""
from fractions import Fraction as F
from flint import fmpq as Q,fmpq_poly as P,arb,ctx
from math import factorial,comb
from pathlib import Path
from functools import lru_cache
import json,hashlib
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

@lru_cache
def angles(d,k):
    # Even Gegenbauer polynomials in the squared cosine. Use the three-term recurrence.
    X=P([0,1]);a=P([1]);b=X;gp=[a]
    for j in range(1,2*k):
        a,b=b,((2*j+d-2)*X*b-j*a)/Q(j+d-2)
        if j%2:gp.append(P([b[2*h] for h in range((j+1)//2+1)]))
    assert len(gp)==k+1 and all(g(1)==1 for g in gp)
    return gp

def interpolation(a,b,k,func):
    # Forward differences on k+1 rational points reconstruct the full polynomial.
    x=P([0,1]);step=(b-a)/k
    ys=[func(a+step*j) for j in range(k+1)];out=P([0]);mult=P([1])
    for j in range(k+1):
        out+=ys[0]*mult;ys=[y-z for y,z in zip(ys[1:],ys)]
        mult*=((x-a)/step-j)/Q(j+1)
    return out

def certify(p,l,r):
    """Möbius form on a half-line gives an independent local positive-coefficient test."""
    if not p:return 1
    k=p.degree();q=p(P([l,r-l]))
    weights=[sum((q[j]*comb(k-j,i-j) for j in range(i+1)),Q(0)) for i in range(k+1)]
    if min(weights)>=0:return 1
    assert p(l)>=0 and p(r)>=0 and r-l>Q(1,2**80)
    m=(l+r)/2
    return 1+certify(p,l,m)+certify(p,m,r)

def audit(pack,record):
    ctx.prec=512;n=record['n'];B=pack/'BOUNDS.json';assert sha(B)==record['parent_bounds_sha']
    row=read(B)[str(n)];old=F(row['upper']);assert old==F(record['old_upper'])
    node=row;root=pack;extra=F(0);threshold=F(0)
    if row['mode']=='flag':
        d=read(pack/row['certificate']);threshold=F(d['geometry']['target']);extra=F(2*d['lower'],d['unit']);node=row['parent']
    if node['mode']=='baseline':
        root=pack/'baseline';node=read(root/'BOUNDS.json')[str(n)]
    assert node.get('mode')!='reciprocal-plane'
    nm=node['certificate'].split('-rigorous')[0]+'.json' if '-rigorous' in node['certificate'] else node['certificate']
    fp=root/nm;c=read(fp);assert c['n']==n and fp.name==record['source'] and sha(fp)==record['source_sha']
    def zero(d):return sum(F(x)*((-1)**j) for j,x in enumerate(d))
    if node.get('mode')=='mixed-scale':
        den=sum(F(s['weight'])*zero(read(root/s['file'])['d'])/F(s['s'])**n for s in c['sources'])+extra
    else:den=zero(c['d'])+extra
    assert den>0;atoms=[];ends={Q(0),Q(1,2)};deg=0;hashes={}
    for atom in c['kernels']:
        p=root/atom['local_kernel'] if 'local_kernel' in atom else next(f for f in (root/'upstream').rglob('frozen.json') if sha(f)==atom['source_sha'])
        src=read(p);assert sha(p)==atom['source_sha'];R=Q(src.get('radius','19/13'));t=Q(atom['dilation']);cut=Q(atom.get('cutoff',str(R/t)))
        if R>2 or Q(str(src.get('angular_debit',0)))!=0 or cut<=1:continue
        assert 1<cut<=R/t and t>=1 and src['n']>=n and Q(atom['alpha'])>0
        hashes[p.name+':'+sha(p)]=sha(p)
        powers=src['powers'];q=Q(src['q']);bs=[[[Q(str(v))*Q(w)*Q(atom['alpha'])/q**2 for v in rr] for rr in m] for w,m in zip(src['co'],src['B'])]
        gp=angles(src['n'],len(bs)-1);deg=max(deg,max(2*len(gp)-2,max(powers)+len(gp)-1))
        at=[((R-t)/(R-1))**k for k in powers];pp=[]
        for v,m in zip(gp,bs):
            one=[sum((a*w for a,w in zip(at,col)),Q(0)) for col in zip(*m)]
            pp.append((v,sum((a*w for a,w in zip(at,one)),Q(0)),one))
        br=1-cut/2;ends.add(br);atoms.append((br,pp,R,t,powers))
    assert hashes==record['source_kernels'] and atoms
    co=list(map(Q,record['angular_coefficients']));assert co and all(x>=0 for x in co[1:])
    X=P([0,1]);Fpol=sum((v*g(X**2) for v,g in zip(co,angles(n,len(co)-1))),P([0]))
    def value(u,mid):
        b=Q(0)
        for br,ps,R,t,pw in atoms:
            third=mid>=br;tt=(R-2*t*(1-u))/(R-1)
            H=[tt**j for j in pw] if third else []
            for g,self_len,one in ps:
                b-=8*self_len*g(u*u)
                if third:b-=16*sum((z*w for z,w in zip(one,H)),Q(0))*g((1-u)/2)
        return b
    anglesplit=sorted(ends);nodes=0
    for a,b in zip(anglesplit,anglesplit[1:]):
        mid=(a+b)/2;slack=interpolation(a,b,max(1,deg),lambda u:value(u,mid))
        assert slack((2*a+b)/3)==value((2*a+b)/3,mid)
        nodes+=certify(slack-Fpol,a,b)
    assert Fpol(Q(1,2))<=value(Q(1,2),Q(1,2))/3
    M=n*(n+1)//2;assert record['M']==M
    J=(Q(M*M)*co[0]-Q(M)*sum(co))/2
    assert J==Q(record['gap_charge']) and J>0
    T=Q(c['tau']);r=arb(T/8);m=n//2
    if n%2:pref=r**m*r.sqrt()*2**(m+1)/(arb.pi().sqrt()*factorial(2*m+2)/(2**(m+1)*factorial(m+1)))
    else:pref=r**m/factorial(m)
    # Gamma(m+3/2) = (2m+2)! sqrt(pi)/(4^(m+1)(m+1)!).
    if n%2:assert pref.contains(r**(arb(Q(n,2)))/(arb(Q(n+2,2))).gamma()) or pref.overlaps(r**(arb(Q(n,2)))/(arb(Q(n+2,2))).gamma())
    delta=F(record['density_reduction']);new=F(record['proposed_upper'])
    assert delta>=0 and arb(Q(str(delta)))<=pref*arb(J/Q(str(den))) and new==max(threshold,old-delta) and new<old
    return dict(n=n,status='PASS',upper=str(new),angle_nodes=nodes,exact_pairs=M*(M-1)//2,parent_sha=sha(B))
if __name__=='__main__':
    import sys
    pack=Path(sys.argv[1]).resolve()
    for name in sys.argv[2:]:
        p=Path(name);print(audit(pack,read(p)),flush=True)

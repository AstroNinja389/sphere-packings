"""Exact Schur-origin saving at fixed diagonal, with target-dimensional harmonics and actual plane signs."""
from pathlib import Path
from fractions import Fraction as F
from flint import fmpq as Q, fmpq_mat as M, arb,ctx
from verify_contact_payment import read,sha,angles

def blocks(p):
    return [M([[Q(t)*Q(w)/Q(p['q'])**2 for t in r] for r in b]) for w,b in zip(p['co'],p['B'])]

def angular_average(n,k):
    from math import prod
    return Q(prod(range(1,2*k,2)),prod(range(n,n+2*k,2)))

def verify(base,record,newfile,deep=True):
    ctx.prec=512;n=record['n'];row=read(base/'BOUNDS.json')[str(n)];parent=row;root=base;extra=F(0);floor=F(0)
    if row['mode']=='flag':
        t=read(base/row['certificate']);extra=F(2*t['lower'],t['unit']);floor=F(t['geometry']['target']);parent=row['parent']
    if parent['mode']=='baseline':
        root=base/'baseline';parent=read(root/'BOUNDS.json')[str(n)]
    assert parent.get('mode')!='reciprocal-plane'
    fn=parent['certificate'];cf=root/(fn.split('-rigorous')[0]+'.json' if '-rigorous' in fn else fn);c=read(cf)
    zero=lambda d:sum(F(v)*(-1)**j for j,v in enumerate(d))
    den=extra+(sum(F(s['weight'])*zero(read(root/s['file'])['d'])/F(s['s'])**n for s in c['sources']) if parent.get('mode')=='mixed-scale' else zero(c['d']))
    atom=c['kernels'][record['atom_index']];digest=atom['source_sha'];assert sha(cf)==record['parent_sha'] and cf.name==record['parent_file'] and c['n']==n and den>0
    oldpath=root/atom['local_kernel'] if 'local_kernel' in atom else next(p for p in (root/'upstream').rglob('frozen.json') if sha(p)==digest)
    old=read(oldpath);new=read(newfile);m=len(old['powers']);R=Q(old.get('radius','19/13'));t=Q(atom['dilation'])
    assert R==Q(new['radius']) and 1<R<=2 and R/t>1 and Q(atom.get('cutoff',str(R/t)))==R/t and not Q(str(old.get('angular_debit',0))) and not Q(str(new.get('angular_debit',0)))
    assert old['powers']==new['powers'] and n==new['n']<=old['n'] and sha(newfile)==record['kernel_sha'] and sha(oldpath)==record['source_sha']==digest
    A=blocks(old);B=blocks(new);O=M(m,m);tot=sum(A,O);assert sum(B,M(m,m))==tot
    gg=angles(old['n'],len(A)-1);avg=[sum((g[j]*angular_average(n,j) for j in range(g.degree()+1)),Q(0)) for g in gg]
    assert all(x>=0 for x in avg);pre=sum((a*x for a,x in zip(A,avg)),M(m,m))
    from itertools import combinations
    for b in B:
        assert b==b.transpose()
        for k in range(1,m+1):
            for v in combinations(range(m),k):assert M([[b[i,j] for j in v] for i in v]).det()>=0
    assert pre.det()>0 and B[0].det()>0
    if deep:
        from free_plane_geometry import signs
        for s in ('cap','triangle'):
            result=signs(new,s,10000);assert result['status']=='PASS' and result['pending']==0
    z=M(m,1,[Q(v)/Q(old['q']) for v in atom['z']]);a=Q(atom['alpha']);assert a>0
    x=pre.solve(z);y=B[0].solve(z);assert pre*x==z and B[0]*y==z
    gain=(z.transpose()*(x-y))[0,0]/a
    assert gain==Q(record['saving']) and gain>0
    U=F(row['upper']);result=F(record['upper']);diff=F(record['delta'])
    assert U==F(record['old']) and 0<=diff and result==max(floor,U-diff) and result<U
    tau=Q(c['tau']);quantity=(arb(tau)/8)**arb(Q(n,2))/(arb(Q(n+2,2))).gamma()*arb(gain)/arb(Q(str(den)))
    assert arb(Q(str(diff)))<=quantity
    return dict(status='PASS',n=n,upper=str(result),saving=str(gain),old=str(U),source=sha(cf),new=sha(newfile))

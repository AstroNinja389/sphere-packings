"""Verify each labelled-difference bound with the explicit ultraspherical formula and exact polynomial subdivision."""
from audit_geometry import *
from polynomial_tools import *
from math import factorial,comb,lcm
def rising(x,j):return prod((x+i for i in range(j)),start=F(1))
def poly(n,b):
 z=F(n-2,2);v=[F(0)]*len(b)
 for k,coef in enumerate(b):
  m=2*k;base=rising(2*z,m)/factorial(m)
  for j in range(k+1):
   v[k-j]+=coef*F((-1)**j*2**(m-2*j),factorial(j)*factorial(m-2*j))*rising(z,m-j)/base
 return P(list(map(lambda x:Q(str(x)),v)))
def nonnegative(p,l,r):
 l=Q(str(l));r=Q(str(r));assert l<=r
 if l==r:return p(l)>=0
 if not p:return True
 f=p(P([l,r-l]));d=p.degree()
 b=[sum((f[j]*comb(i,j)/comb(d,j) for j in range(i+1)),Q(0)) for i in range(d+1)]
 den=lcm(*(int(a.q) for a in b));stack=[([int(x*den) for x in b],0)]
 while stack:
  v,k=stack.pop()
  if min(v)>=0:continue
  if v[0]<0 or v[-1]<0 or k==85:return False
  a,b=split_int(v);stack.extend([(a,k+1),(b,k+1)])
 return True
def check(n,win):
 A,B=map(F,[win['A'],win['B']]);bs=list(map(F,win['coeffs']));e=list(map(F,win['grid']));assert 1<=A<B<=2 and B-A<1 and A in e and B in e and e[0]==1 and e[-1]==2
 assert bs[0]==1 and min(bs)>=0
 f=poly(n,bs);eps=F(win['eps']);assert 0<=eps<1
 assert nonnegative(Q(str(eps))-f,0,(1-1/B)**2)
 K=win['tangent'];N=2**n-1;f1=sum(bs)
 b0=1-eps;F1=f1-eps
 c=b0-F1/(2*K+1) if K else b0
 rhs=b0*F(K*(K+1),(2*K+1)*N) if K else F1/N
 assert rhs==F(win['cost'])
 row=[]
 for j,(l,r) in enumerate(zip(e,e[1:])):
  low=max(F(0),1-r/(2*A));high=min(1-1/(2*B),1-l/(2*B));p=F(win['p'][j]);assert p>=0
  if low<=high:assert nonnegative(Q(str(eps+p))-f,low*low,high*high)
  term=p
  if K and p and low<=high:
   from window_geometry import multiplicity
   degree,w=multiplicity(n,A,B,l,r);assert degree==win['multiplicities'][j]
   R=B-l/4;z=1-1/(2*R);eta=(B-A)**2/(l*(4*A-l))
   if w:
    dn=w['n'];assert dn in [n,n-1] and (dn==n or eta<1)
    assert degree==verify_w(w,dn,z if dn==n else (z+eta)/(1-eta))
   else:assert (degree>=4**n or (degree>=1 and z<0) or (degree==0 and R<F(1,4)))
   term=p*2*degree/(2*K+1)
  elif K:term=F(0)
  row.append(c*int(A<=l<r<=B)-term)
 assert row==list(map(F,win['short_weights']))
 return row,rhs
if __name__=='__main__':
 for name in sys.argv[1:]:
  v=read(D/name)
  for w in v:check(w['dimension'],w)
  print('PASS',name,len(v))

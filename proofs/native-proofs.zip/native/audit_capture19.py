"""Replay the native construction in its original order and bind all captured integer fields."""
from profiles import *
from pathlib import Path
import sys
def audit():
    f=D/'class-fields19-v1.json';o=read(f);source=S/'n19'
    assert all(sha(source/name)==v for name,v in o['sources'].items())
    import os
    home=Path(os.environ['CENSUS_WORK'])
    dst=home/'new-fields-front-v1';dst.mkdir(exist_ok=False)
    sys.path.insert(0,str(home));sys.path.insert(1,str(D.parent/'gap-crosscheck-20261118'))
    import cert_combo as public
    from pop_dp import Exact
    from proof import verify
    b=read(source/'combo-bundle.json');E=list(map(F,b['E']));J=E.index(2);needs=verify()
    assert E==list(map(F,o['grid'])) and needs=={int(k):F(v) for k,v in o['needs'].items()}
    v=Exact(E,needs,96,'front');v.ix=E.index(F(read(source/'population-proof.json')['T']))-J-1;v.lam=int(F(b['population'])*10**16)
    assert v.ix==o['ix'] and v.lam==o['threshold_price'];count=0
    def callback(w,pen,cap,off,j):
        nonlocal count
        assert j==J;row=o['rows'][count];field=o['fields'][row['field']]
        assert (count,off,cap,w[count-1] if off else 0)==(row['anchor'],row['offset'],row['cap'],row['short'])
        assert list(w[j:])==field['long'] and list(pen)==field['pen']
        x=v.callback(w,pen,cap,off,j);assert x+row['short']==row['old'];count+=1
        return x
    public.st.backward=callback
    def signs(c,p,q):
        vb=public.st.vb
        vb.prove_bernstein(vb.integer_halfline_bernstein(q,F(0)),strict=True,label='dual')
        vb.prove_bernstein(vb.integer_halfline_bernstein(vb.poly_scale(p,-1),c.tau0*E[-1]),strict=True,label='physical tail')
    public.st.vb.prove_polynomial_obligations=signs
    out=public.st.audit(home/'combo-bundle.json',dst/'front.json')
    old=read(source/'combo-front-96.json')
    for k in ['integer_branch_maxima','rho','class_budget_scaled','rounding_denominator']:assert out[k]==old[k]
    assert count==len(o['rows'])==J+1
    report=dict(status='PASS',n=19,source_sha=sha(f),replay_sha=sha(dst/'front.json'),field_count=len(o['fields']),rows_checked=count,rounding_unit=o['unit'])
    dump(dst/'capture-replay.json',report);print('independent forward capture and every source coefficient passed',count,flush=True)
if __name__=='__main__':audit()

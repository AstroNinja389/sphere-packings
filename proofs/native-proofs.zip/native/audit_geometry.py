"""Independent projective LP and half-sum geometry check using the Rodrigues formula (no Gegenbauer elimination)."""
from fractions import Fraction as F
from math import factorial,prod,isqrt
from functools import cache
@cache
def sphere(n,k):
 return F(prod(range(1,2*k,2)),prod(n+2*j for j in range(k)))
@cache
def line_proof(n,z,shift,pp,claim):
 assert n>=3 and 0<=z<1 and shift>=0
 p=list(map(F,pp));a=[F(0)]*(2*len(p)+shift)
 for i,ai in enumerate(p):
  for j,aj in enumerate(p):
   a[i+j+shift]-=z*z*ai*aj;a[i+j+shift+1]+=ai*aj
 # After 2k integrations by parts, the sign is the sign of the following derivative integral.
 coeff=[sum((v*F(factorial(2*j),factorial(2*j-2*k))*sphere(n+4*k,j-k) for j,v in enumerate(a) if j>=k),F(0)) for k in range(len(a))]
 assert coeff[0]>0 and min(coeff)>=0 and sum(a)//coeff[0]==claim
 return claim
def verify_w(row,n,z):
 assert row['n']==n and z<=F(row['z'])
 return line_proof(n,F(row['z']),row['shift'],tuple(row['p']),row['cap'])
def check_half(h):
 n,t=int(h['n']),F(h['t']);assert 2<=t<F(5,2);N=2**n-1;assert N==h['parity_classes']
 eta=(t-2)/2;end=F(1);rows=[]
 for a in h['rows']:
  l,r=map(F,[a['l'],a['r']]);assert l==end and l<=r<=t-1
  end=r;K=verify_w(a['prefix_witness'],n,1-1/(2*r))
  s=t-l;d1=1-1/(2*s);e2=eta**2/l;d2=(d1+e2)/(1-e2)
  w=a['degree_witness'];d=w['n'];assert d in (n,n-1)
  degree=verify_w(w,d,d1 if d==n else d2)
  assert (K,degree)==(a['prefix'],a['degree'])
  rows.append((K,degree))
 assert rows and end==t-1 and all(a<=b and v>=w for (a,v),(b,w) in zip(rows,rows[1:]))
 # Independent dual summation by parts.
 budget=sum((K*(deg-(rows[i+1][1] if i+1<len(rows) else 0)) for i,(K,deg) in enumerate(rows)))
 assert budget==h['collision_budget']
 limit=int(h['prefix_count']);count=limit+1
 k,b=divmod(count,N)
 # Convexity on integers: this is the minimum sum m*(m-1) at fixed total count.
 assert (N-b)*k*(k-1)+b*k*(k+1)>budget
 return limit
def check_prefix(n,row):
 e=F(row['end'])
 return line_proof(n,1-1/(2*e),row['shift'],tuple(row['p']),row['cap'])
if __name__=='__main__':
 from profiles import *
 for p in sorted(D.glob('half-sum-counts-*.json')):
  hh=read(p);print(p.name,len([check_half(h) for h in hh]))

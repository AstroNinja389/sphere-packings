"""Second implementation of the integer per-class and global counting certificate. No numerical LP."""
from profiles import *
from external_profiles import cert
from audit_geometry import check_prefix,check_half
from bisect import bisect_right
from functools import lru_cache
from math import comb,factorial
import base64,zlib
def class_caps(n,a,s):
    # Direct checks for the full frame, its anchor projection, and a weighted anchor.
    z=1-2/s;assert z>=0 and n*z*z<1
    lines=n*(1-z*z)//(1-n*z*z)
    if a is None:return lines
    if a+s<=4:return 0
    u=(a+s-4)**2/(4*a*s);bits=[lines-1];v=(z+u)/(1-u)
    if (n-1)*v*v<1:bits.append((n-1)*(1-v*v)//(1-(n-1)*v*v))
    h=F(1,n);w=max(F(0),h-u)/(1-h);d=h-z*z+2*w*(h-u)-w*w*(1-h)
    if d>0:bits.append((1-z*z)//d)
    return min(bits)
def ceil(x):return -((-x.numerator)//x.denominator)
def floor(x):return x.numerator//x.denominator
def check_density(n,tau,rho,claimed):
    assert rho>0 and claimed>0 and tau>0
    if n%2:
        def a(q,m):return sum((F((-1)**i,(2*i+1)*q**(2*i+1)) for i in range(m)),F(0))
        lo=16*a(5,36)-4*a(239,37)
        assert lo>3 and claimed**2*lo>=tau**n*rho**2/(2**(2*n-1)*prod(range(1,n+1,2))**2)
    else:assert claimed>=(tau/8)**(n//2)*rho/factorial(n//2)
def audit(path):
 a=read(path);n=a['n'];c,source=cert(n);hf=D/a['height_file'];h=read(hf)
 assert a['source']==h['src']==sha(source) and a['height_sha']==sha(hf)
 hr=read(hf.with_name(hf.stem+'-independent.json'));assert hr['status']=='PASS' and hr['height_sha']==sha(hf) and hr['source']==sha(source)
 N=2**n-1;E=list(map(F,h['grid']));J=E.index(2);U=h['unit'];assert U>0
 assert E[-1]*E[-1]<8 and E[0]==1 and len(h['heights'])==len(E)-1
 prefix=read(D/f'prefix-{n}-degree7.json');half={v['t']:v for v in read(D/f'half-sum-counts-{n}-16.json')};ce=list(map(F,c['E']))
 add=[F(0)]*len(h['heights']);constant=F(0)
 for feature,alpha in a['active']:
  alpha=F(alpha);assert alpha>=0
  if feature['kind']=='upstream-angular':
   cut=c['angular_cuts'][feature['index']];w=list(map(F,cut['weights']));rhs=F(cut['constant'])/N
   vector=[w[bisect_right(ce,x)-1] if x<2 else F(0) for x in E[:-1]]
  else:
   e=F(feature['end'])
   if feature['kind']=='prefix':cap=check_prefix(n,prefix[str(e)])
   else:assert feature['kind']=='half-sum';cap=check_half(half[str(e)])
   assert feature['cap']==cap and e in E
   rhs=F(cap,N);vector=[F(int(r<=e)) for r in E[1:]]
  add=[x+alpha*y for x,y in zip(add,vector)];constant+=rhs*alpha
 W=[v-floor(U*x) for x,v in zip(add,h['heights'])]
 bins=E[J+1:];K=len(bins);choices=zlib.decompress(base64.b64decode(a['choices']));mu=a['prices']
 count,cols=a['choice_shape'];assert count==J+1 and len(choices)==count*cols and min(mu)>=0
 priceweights={}
 for ix in set(choices):
  lam=mu[ix];cur=[w+ceil(lam*(1-2/e)**2) for w,e in zip(W[J:],bins)]
  for j in range(K-2,-1,-1):cur[j]=max(cur[j],cur[j+1])
  priceweights[ix]=cur
 budgets=[]
 # For each sorted slot take the largest remaining charged height. Re-evaluate all integer
 # occupancies and their individual dual certificates; only the supplied prices influence speed.
 cache={}
 for j,anchor in enumerate([None]+E[1:J+1]):
  cap=[class_caps(n,anchor,x) for x in bins]
  for hidx in range(K-2,-1,-1):cap[hidx]=min(cap[hidx],cap[hidx+1])
  cap=tuple(cap);offset=int(anchor is not None);score=0
  for k in range(1,cap[-1]+1):
   ix=choices[j*cols+k];lam=mu[ix];total=k+offset;key=(cap,ix)
   if key not in cache:
    spent=0;greedy=[0]
    for limit,weight in zip(cap,priceweights[ix]):
     while len(greedy)<=limit:
      spent+=weight;greedy.append(spent)
    cache[key]=greedy
   need=F(total*(total-n),n*(total-1)) if total>n else F(0)
   score=max(score,cache[key][k]-floor(lam*need))
  budgets.append(F(score+(W[j-1] if j else 0),U))
 prefix_rows={F(v):check_prefix(n,prefix[v]) for v in a['pooled_prefix_ends']}
 # Layer-cake integral: for a score threshold, the rightmost qualifying bin
 # determines which prefix caps apply to its entire superlevel set.
 base=budgets[0];mean=base
 for v in sorted(set(budgets)-{base}):
  if v<=base:continue
  end=max(E[j] for j in range(1,J+1) if budgets[j]>=v)
  cap=min([N]+[c0 for e,c0 in prefix_rows.items() if e>=end]);mean+=(v-base)*F(cap,N);base=v
 rho=(F(c['p'][0])+constant+mean)/F(c['q'][0]);assert rho==F(a['rho'])
 check_density(n,F(c['tau']),rho,F(a['density_upper']))
 # The preregistered upstream replay covers full Fourier, tail, and its angular cuts.
 rec=read(D/f'replay-{n}.json');log=D/f'replay-{n}.log'
 assert rec['returncode']==0 and rec['log_sha256']==sha(log)
 out=dict(status='PASS',dimension=n,count_classes=count,upper=a['density_upper'],density=float(F(a['density_upper'])),heights_assertions=hr['nodes'],hashes={p.name:sha(p) for p in [path,hf,hf.with_name(hf.stem+'-independent.json'),D/f'replay-{n}.json',source]})
 dump(path.with_name(path.stem+'-independent.json'),out);print(n,out['density'],'checks',count,hr['nodes'],flush=True)
if __name__=='__main__':
 for name in sys.argv[1:]:
  audit(D/name)

"""Certify each coefficient, capacity and integer optimum in a native length-profile oracle."""
from profiles import *
from native_review import both,STEM,certificate
from pathlib import Path
def capture(n):
    assert n in (15,17,18);original=S/f'n{n}';tag=STEM[n];origin=certificate(n)
    import os
    home=Path(os.environ['CENSUS_WORK'])
    dest=home/'capture-coeff-v1';dest.mkdir(exist_ok=False)
    sys.path.insert(0,str(home));sys.path.insert(1,str(D.parent/'gap-crosscheck-20261118'))
    import integer_dp as dp
    engine=dp.Verifier;st=dp.st;deps=[home/'integer_dp.py'];factor={15:384,17:192,18:96}[n]
    if n==15:
        cert=read(home/'character-audit.json');needs={15:2*F(cert['mass']),16:F(3,2)};deps.append(home/'character-audit.json')
    elif n==17:
        z=read(home/'new-frame.json');needs={17:F(z['floor']),18:F(3,2)};deps.append(home/'new-frame.json')
    else:
        import certify_twice as ct,critical_envelope as ce,multiple_envelopes as mu
        mu.prove=ce.prove;st=ct.certify.st
        z=read(home/'rank-proof.json');needs={int(k):F(x) for k,x in z['compulsory'].items()}
        deps += [home/name for name in ['critical_envelope.py','rank-proof.json','twice_audit.py','source_family.py']]
    inputs=both(n,tag);bundle=home/(tag+'-bundle.json');E=list(map(F,read(bundle)['E']));J=E.index(2)
    fields=[];rows=[];maps={};unit=0
    for way,ref in zip(('front','back'),inputs):
        cached=engine(E,needs,factor,way);jnow=0;old=read(original/ref);unit=old['rounding_denominator'];assert F(unit)==10**16
        def callback(w,pen,cap,off,j0,*rem):
            nonlocal jnow
            assert not rem and (off,j0)==(int(jnow>0),J)
            score=cached.callback(w,pen,cap,off,j0)+(w[jnow-1] if off else 0);assert score==int(old['integer_branch_maxima'][jnow])
            k=(tuple(w[J:]),tuple(pen))
            if way=='front':
                if k not in maps:maps[k]=len(fields);fields.append(dict(long=list(w[J:]),pen=list(pen)))
                rows.append(dict(anchor=jnow,offset=off,field=maps[k],cap=list(cap),short=w[jnow-1] if off else 0,old=score))
            else:
                r=rows[jnow];assert r['cap']==list(cap) and r['field']==maps[k] and r['short']==(w[jnow-1] if off else 0) and r['old']==score
            jnow+=1;return score-(w[jnow-2] if off else 0)
        st.backward=callback
        out=st.audit(bundle,dest/(way+'.json'));assert jnow==len(rows)==J+1
        for a in ['integer_branch_maxima','rho','class_budget_scaled','rounding_denominator']:assert out[a]==old[a]
    deps+= [bundle];h={q.name:sha(q) for q in deps};assert all(sha(original/k)==v for k,v in h.items())
    h.update({k:sha(original/k) for k in inputs});cf=D/f'class-fields{n}-v1.json'
    obj=dict(n=n,grid=list(map(str,E)),needs={str(k):str(v) for k,v in needs.items()},scale=factor,unit=int(unit),ix=-1,threshold_price=0,fields=fields,rows=rows,sources=h)
    assert obj==read(cf);assert origin['E']==E
    dump(dest/'capture-replay.json',dict(n=n,status='PASS',source_sha=sha(cf),rows_checked=len(rows),field_count=len(fields),forward=sha(dest/'front.json'),backward=sha(dest/'back.json')))
    print(n,'all per-anchor coefficients and both integer maxima rechecked',len(rows),len(fields),flush=True)
if __name__=='__main__':capture(int(sys.argv[1]))

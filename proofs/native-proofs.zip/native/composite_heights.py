"""Directed maxima for a Gaussian times a polynomial plus a compact polynomial correction."""
from polynomial_tools import *
from functools import lru_cache
from math import factorial

def upper_bins(p,tau,parts,E,unit):
    tau=Q(str(tau));E=list(map(lambda t:Q(str(t)),E));tol=arb(Q(1,10**9))
    assert all(cut in E or cut<=E[0] or cut>=E[-1] for cut,_ in parts)
    ds=[p]
    for _ in range(5):ds.append(tau*(ds[-1].derivative()-ds[-1]/2))
    def mag(poly):
        return sum((abs(a) for a in poly.coeffs()),Q(0))
    @lru_cache(maxsize=1024)
    def expat(x):return (-arb(tau*x)/2).exp()
    def size(v):return int((v*unit).upper().ceil().unique_fmpz())
    heights=[];nodes=0
    for a,b in zip(E,E[1:]):
        G=[sum((g for end,g in parts if end>=b),P([0]))]
        for _ in range(5):G.append(G[-1].derivative())
        def val(x):return expat(x)*arb(p(tau*x))+arb(G[0](x))
        best=max(val(a).lower(),val(b).lower());upper=max(size(val(a)),size(val(b)))
        st=[(a,b,0)]
        while st:
            l,r,depth=st.pop();m=(l+r)/2;h=(r-l)/2;nodes+=1
            vm=val(m);best=max(best,vm.lower());exact_shift=P([m,h])
            # Analytic Taylor series at the middle with a fifth-derivative Lagrange remainder.
            cs=[(expat(m)*arb(ds[i](tau*m))+arb(G[i](m)))*arb(h**i/factorial(i)) for i in range(5)]
            fifth=expat(l)*arb(mag(ds[5](tau*exact_shift)))+arb(mag(G[5](exact_shift)))
            rem=fifth*arb(h**5/factorial(5))
            derivative_error=sum((j*abs(cs[j]) for j in range(2,5)),arb(0))+5*rem
            if abs(cs[1]).lower()>derivative_error.upper():
                top=max(size(val(l)),size(val(r)));upper=max(upper,top);continue
            cap=(cs[0]+sum((abs(v) for v in cs[1:]),arb(0))+rem).upper()
            if cap<best+tol:
                upper=max(upper,size(cap));continue
            assert depth<50
            st.extend([(l,m,depth+1),(m,r,depth+1)])
        heights.append(upper+max(1,unit//10**10))
    return heights,nodes

def confirm_bins(p,tau,parts,E,unit,heights):
    """A separate degree-two Bernstein proof at the left endpoint with a third-derivative remainder."""
    tau=Q(str(tau));E=[Q(str(e)) for e in E];assert len(E)==len(heights)+1 and all(l<r for l,r in zip(E,E[1:]))
    assert all(end in E or end<=E[0] or end>=E[-1] for end,_ in parts)
    pp=[p]
    for _ in range(3):pp.append(tau*(pp[-1].derivative()-pp[-1]/2))
    nodes=0
    for l0,r0,H in zip(E,E[1:],heights):
        g=[sum((poly for stop,poly in parts if stop>=r0),P([0]))-Q(H,unit)]
        for _ in range(3):g.append(g[-1].derivative())
        queue=[(l0,r0,0)]
        while queue:
            l,r,k=queue.pop();h=r-l;x=P([l,h]);ee=(-arb(tau*l)/2).exp();nodes+=1
            z=[(ee*arb(pp[i](tau*l))+arb(g[i](l)))*arb(h**i/factorial(i)) for i in range(3)]
            # Absolute sum of Taylor coefficients on [0,1] bounds each third derivative.
            q=pp[3](tau*x);v=g[3](x)
            err=(ee*arb(sum(map(abs,q.coeffs()),Q(0)))+arb(sum(map(abs,v.coeffs()),Q(0))))*arb(h**3/6)
            if all(t+err<=0 for t in [z[0],z[0]+z[1]/2,z[0]+z[1]+z[2]]):continue
            assert k<55 and z[0]<=0,(str(l),str(r),H)
            m=(r+l)/2;queue.extend([(l,m,k+1),(m,r,k+1)])
    return nodes

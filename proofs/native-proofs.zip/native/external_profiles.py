from profiles import *
import gzip
def cert(n):
 L=D/'upstream/verifications/lattice'
 p=next(L.glob(f'dim{n}*'))/'certificate.json.gz'
 return json.loads(gzip.decompress(p.read_bytes())),p
if __name__=='__main__':
 for n in range(25,36):
  c,p=cert(n)
  print(n,c.keys() if n in [25,32,35] else '',{k:(str(c[k])[:80] if not isinstance(c[k],list) else (len(c[k]),str(c[k][:1])[:80])) for k in ['J','angular','kappa','budgets','safe_density','density','ratio','p','q','extra_objective','component_bounds'] if k in c})

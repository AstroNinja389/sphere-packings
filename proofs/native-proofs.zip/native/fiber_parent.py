"""Select a verified primal sum bound, retaining any density hypothesis."""
from profiles import *
from independent_fourier import transform,nonnegative_ray
from flint import fmpq as Q

def select(n):
    if n in (15,17,18,19,20,21,22,23):
        candidates=[*D.glob(f'oracle{n}*-final-packing-proof.json'),*D.glob(f'lift{n}*-final-packing-proof.json'),*D.glob(f'mix{n}*-final-packing-proof.json')]
        return min(candidates,key=lambda p:F(read(p)['upper'])).name
    if n<=32:
        matches=[p for p in D.glob('*-r0-rigorous3-independent.json') if read(p).get('n')==n and read(p).get('unconditional_fourier_sign')]
        return min(matches,key=lambda p:F(read(p)['upper'])).name
    return f'eutactic-{n}-final-packing-proof.json'

def spatial(file,deep=False):
    assert Path(file).name==file;pf=D/file;pr=read(pf);n=pr['n'];assert pr['status']=='PASS';floor=F(0)
    refs={pf.name:sha(pf)}
    if file.endswith('-rigorous3-independent.json'):
        rf=D/file.replace('-independent.json','.json');r=read(rf);cf=D/file.replace('-rigorous3-independent.json','.json')
        assert r['source']==sha(cf) and pr['unconditional_fourier_sign'] and pr['dependencies'][rf.name]==sha(rf)
        rho=F(r['rho']);refs[rf.name]=sha(rf)
        if deep:
            from independent_master import verify
            x=verify(rf,True);assert x['report']['upper']==pr['upper'] and x['report']['unconditional_fourier_sign']
    elif file.startswith('eutactic-'):
        a,b=sorted(pr['inputs']);ef=D/a;rf=D/b;assert 'eu-pay' in a and '-rigorous' in b and all(sha(D/x)==h for x,h in pr['inputs'].items())
        cf=D/(rf.stem.split('-rigorous')[0]+'.json');assert read(rf)['source']==sha(cf)
        refs.update(pr['inputs']);rho=F(pr['rho'])
        if deep:
            from independent_master import verify
            from portable_eutaxy import check
            d=verify(rf,True);w=read(ef);res=check(ef,rf,d);assert res['upper']==pr['upper']
            vals=d['values'][:];E=d['E'];N=2**n-1;g=n*(n+1)//2
            for j,(_,v) in enumerate(w['rows'],1):vals[j]+=F(v)
            run=0;mass=g*vals[1];last=0
            for i in range(1,len(vals)):
                cap=min([N]+[k for z,k in d['prefix'].items() if z>=E[i]])-g
                assert last<=cap;mass+=(cap-last)*max(vals[0],max(vals[i:]));last=cap
            mass+=(N-g-last)*vals[0]
            assert (F(str(d['p'](0)))+d['bonus']+mass/N)/F(str(d['q'](0)))==rho
    else:
        assert n<=23 and 'profile_threshold' in pr;cf=D/file.replace('-final-packing-proof.json','.json')
        assert pr['inputs'][cf.name]==sha(cf);rho=F(pr['rho']);floor=F(pr['profile_threshold'])
        if deep:
            from native_lift_audit import verify
            x=verify(cf.stem,False);assert x['rho']==pr['rho'] and x['profile_threshold']==pr['profile_threshold']
    data=read(cf);p,q=transform(n,data['d']);assert data['n']==n and q(0)>0
    assert nonnegative_ray(q,0);refs[cf.name]=sha(cf)
    return n,cf,data,rho,floor,refs

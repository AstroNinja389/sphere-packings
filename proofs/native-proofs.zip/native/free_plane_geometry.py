"""Verify continuous signs of a native radial/angular plane kernel up to any rational support R<=2."""
from plane_tensor_audit import coefficients,make_controls,bisect
from profiles import *
from functools import lru_cache
from flint import fmpz_mpoly_ctx
from math import lcm
from itertools import product
import numpy as np

def polynomial(src,kind):
    pol,degree=coefficients(src);rad=F(src.get('radius','19/13'));assert 1<rad<=3
    p,q=rad.numerator,rad.denominator
    C=fmpz_mpoly_ctx.get(('x','y','z'));x,y,z=C.gens();o=C.constant(1);zero=C.constant(0)
    powers=src['powers'];assert 2<=len(powers)<=5 and all(type(k)==int and k>0 for k in powers)
    base,step=powers[0],powers[1]-powers[0];assert step>0 and powers==[base+i*step for i in range(len(powers))]
    assert len(powers)==3 or rad<=2
    a=p-(p-q)*x;b=p-(p-q)*x*y
    if kind=='cap':
        # The third line of length |v+-w| would have been present below R.
        # Parameterize all squared cosines below the resulting length-dependent bound.
        den=4*a*b;num=[z*(a+b-p)**2];pairs=[(1,x**step,(x*y)**step)]
    else:
        assert kind=='triangle';c=p-(p-q)*x*y*z;den=4*a*b*c
        num=[c*(a+b-c)**2,b*(a+c-b)**2,a*(b+c-a)**2]
        u=x**step;v=(x*y)**step;w=(x*y*z)**step;pairs=[(1,u,v),(z**base,u,w),((y*z)**base,v,w)]
    pw=[den**(degree-j) for j in range(degree+1)];scale=lcm(*(v.denominator for row in pol.values() for v in row))
    co={ij:[int(scale*u) for u in row] for ij,row in pol.items()};total=zero
    for h,(weight,l,r) in zip(num,pairs):
        lv=[o]+[l**i for i in range(1,len(powers))];rv=[o]+[r**i for i in range(1,len(powers))]
        prod={ij:lv[i]*rv[j]+(lv[j]*rv[i] if i!=j else zero) for ij in pol for i,j in [ij]}
        hn=o
        for k,v in enumerate(pw):
            term=sum((cs[k]*prod[ij] for ij,cs in co.items()),zero)
            total-=weight*v*hn*term
            hn*=h
    return total

def signs(src,kind,limit=4000):
    if F(src.get('angular_debit',0)):
        from plane_error_budget import for_sign
        src=for_sign(src)
    if kind=='four':
        from four_line_geometry import check
        return check(src,limit)
    pol=polynomial(src,kind);assert not pol.is_zero()
    controls=make_controls(pol);stack=[(controls,())];count=depth=0
    while stack and count<limit:
        b,path=stack.pop();count+=1;depth=max(depth,len(path))
        if b.min()>=0:continue
        for idx in product((0,-1),repeat=3):
            if b[idx]<0:return dict(status='VIOLATED',kind=kind,path=list(path),vertex=list(idx),nodes=count)
        if len(path)>=140:return dict(status='UNRESOLVED',kind=kind,path=list(path),nodes=count)
        curvature=[max(abs(np.diff(b,n=2,axis=i)).flat)*(b.shape[i]-1)**2 if b.shape[i]>=3 else 0 for i in range(3)]
        axis=max(range(3),key=curvature.__getitem__)
        for side,part in enumerate(bisect(b,axis)):stack.append((part,path+((axis,side),)))
    return dict(status='INCOMPLETE' if stack else 'PASS',kind=kind,nodes=count,pending=len(stack),depth=depth,degree=list(map(int,pol.degrees())))

@lru_cache(maxsize=48)
def check(name,digest,n):
    assert Path(name).name==name and name.endswith('.json')
    file=D/name;assert sha(file)==digest;src=read(file)
    assert src['n']==n
    out=[signs(src,k) for k in domains(src)]
    assert all(a['status']=='PASS' for a in out),(name,out)
    return out
def domains(src):
    return ('cap','triangle','four') if F(src.get('radius','19/13'))>2 else ('cap','triangle')
if __name__=='__main__':
    for name in sys.argv[1:]:
        file=D/name;src=read(file);out=[]
        for k in domains(src):
            row=signs(src,k);out.append(row);print(name,k,row,flush=True)
        dump(D/(file.stem+'-continuous-signs.json'),dict(sha=sha(file),checks=out))

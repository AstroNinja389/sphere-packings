"""Reciprocal shortest-vector gap from a primitive hyperplane section, for minimum squared one."""
from profiles import *
def registry():
 p=D.parent/'gap-crosscheck-20261118/competitor/LATTICE_RESULTS.json'
 return {int(r['dimension']):F(r['certified_density_upper_bound']) for r in read(p)}
OLD={13:F('.044276'),14:F('.033997010427326'),15:F('.025173277440579'),16:F('.0172314323416'),17:F('.013631287972433'),18:F('.010247566373856'),19:F('.007634799344360'),20:F('.005813810448531'),21:F('.004411822027365'),22:F('.003338544010566'),23:F('.002527264407180')}
def previous(n):
 if n==25:
  v=arb.pi()**12/479001600
  out=F(int((v*10**20).upper().ceil().unique_fmpz()),10**20)
  assert arb(fmpq(str(out)))>v
  return out
 return OLD[n-1] if n-1 in OLD else registry()[n-1]
def gap(n,tau,target,prev):
 # In min-one units, det(perpendicular section)=covol(L)*|y| for a primitive dual normal.
 aa=lambda x:arb(fmpq(str(x)))
 def V(k):return arb.pi()**aa(F(k,2))/(aa(F(k,2))+1).gamma()
 value=4*arb.pi()**2/aa(tau)*(2*V(n-1)*aa(target)/(V(n)*aa(prev)))**2
 out=F(int((value*10**8).lower().floor().unique_fmpz()),10**8)
 assert aa(out)<value
 return out
if __name__=='__main__':
 for n in [15,17,25,30,38,48]:
  old=OLD.get(n,registry().get(n));target=old*F(97,100)
  print(n,'for tau27',float(gap(n,F(27),target,previous(n))))

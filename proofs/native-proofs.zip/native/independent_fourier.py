"""Independent Gaussian and normalized Laguerre verifier. No LP or search code."""
from math import comb
from functools import lru_cache
from flint import fmpq as Q, fmpq_poly as P, arb, ctx

def transform(n, coeff):
    """Explicit binomial expansion of each normalized generalized Laguerre polynomial."""
    d=[Q(str(x)) for x in coeff]
    even=[];odd=[];rising=Q(1)
    for j in range(len(d)):
        if j:rising*=Q(n,2)+j-1
        scale=(-1)**j/rising
        even.append(scale*sum((comb(i,j)*d[i] for i in range(j+(j%2),len(d),2)),Q(0)))
        odd.append(scale*sum((comb(i,j)*d[i] for i in range(j+(1-j%2),len(d),2)),Q(0)))
    return P(even)+P(odd),P(even)-P(odd)

def nonnegative_ray(p,start):
    """Remove boundary roots exactly. An odd root is the only way to change strict sign."""
    x=Q(str(start))
    if not p:return True
    while p.degree() and not p(x):p,rem=divmod(p,P([-x,1]));assert not rem
    if p(x)<=0 or p.leading_coefficient()<=0:return False
    if not p.degree():return True
    roots=p.complex_roots()
    assert sum(m for _,m in roots)==p.degree()
    return all(m%2==0 or not z.imag.contains(0) or z.real<arb(x) for z,m in roots)

def gaussian_bins(p,tau,edges,heights,unit):
    """Validate simultaneous signed upper enclosures using derivatives on closed bins."""
    assert unit>0 and len(edges)==len(heights)+1
    E=[Q(str(v))*Q(str(tau)) for v in edges];assert all(x<y for x,y in zip(E,E[1:]))
    p=p*unit;dp=2*p.derivative()-p
    @lru_cache(maxsize=4096)
    def value(x):return arb(p(x))*(-arb(x)/2).exp()
    count=0
    for a,b,h in zip(E,E[1:],heights):
        stack=[(a,b,0)]
        while stack:
            l,r,depth=stack.pop();count+=1
            assert depth<60 and value(l)<=h and value(r)<=h
            m=(l+r)/2;s=(r-l)/2
            d=dp(P([m,s]))
            rad=sum(map(abs,d.coeffs()[1:]),Q(0))
            if abs(d[0])>=rad:continue
            if value(m)+arb((abs(d[0])+rad)*s/2)*(-arb(l)/2).exp()<=h:continue
            stack.extend([(l,m,depth+1),(m,r,depth+1)])
    return count

"""Second full verifier for the optimized simultaneous Fourier and angular certificates."""
from audit_price import class_caps, ceil, floor, check_density
from audit_geometry import check_prefix, check_half
from audit_angular import check as angular
from independent_fourier import transform,nonnegative_ray,gaussian_bins
from profiles import *
from external_profiles import cert
from bisect import bisect_left,bisect_right
import base64,zlib

def integer_census(n,E,W,unit,a):
    N=2**n-1;J=E.index(2);short=E[1:J+1];long=E[J+1:]
    # Betas are optional nonnegative multipliers indexed by anchor and occupancy.
    buf=zlib.decompress(base64.b64decode(a['choices']));rr,cc=a['choice_shape'];prices=a['prices']
    assert len(buf)==rr*cc and rr==J+1 and all(isinstance(x,int) and x>=0 for x in prices)
    assert max(buf)<len(prices)
    envelopes={}
    for i in set(buf):
        lam=prices[i]
        v=[w+ceil(lam*(1-2/r)**2) for w,r in zip(W[J:],long)]
        for j in reversed(range(len(v)-1)):v[j]=max(v[j],v[j+1])
        envelopes[i]=v
    budgets=[];cache={}
    for j,a0 in enumerate([None]+short):
        cap=[class_caps(n,a0,r) for r in long]
        for j0 in reversed(range(len(cap)-1)):cap[j0]=min(cap[j0],cap[j0+1])
        assert cc>cap[-1] and min(cap)>=0
        cap=tuple(cap);best=0
        for k in range(1,cap[-1]+1):
            idx=buf[j*cc+k];key=(cap,idx)
            if key not in cache:
                g=[0]
                for lim,w in zip(cap,envelopes[idx]):
                    while len(g)<=lim:g.append(g[-1]+w)
                cache[key]=g
            h=k+int(a0 is not None)
            v=F(h*(h-n),n*(h-1)) if h>n else F(0)
            best=max(best,cache[key][k]-floor(prices[idx]*v))
        budgets.append(F(best+(W[j-1] if j else 0),unit))
    return budgets

def pooled(n,E,scores,caps):
    base=scores[0];levels=sorted({v for v in scores if v>base});value=base;N=2**n-1
    for v in levels:
        end=max(E[i] for i in range(1,len(scores)) if scores[i]>=v)
        count=min([N]+[lim for x,lim in caps.items() if end<=x])
        value+=(v-base)*F(count,N);base=v
    return value

def verify(path,details=False,portable=False):
    ctx.prec=512;a=read(path);tag=path.stem.split('-rigorous')[0];cf=D/(tag+'.json');c=read(cf)
    n=c['n'];assert a['n']==n and a['source']==sha(cf)
    hf=D/a['height_file'];h=read(hf);assert sha(hf)==a['height_sha'] and h['src']==sha(cf) and h['n']==n
    N=2**n-1;E=list(map(F,h['grid']));T=F(c['tau']);U=h['unit'];hs=h['heights'];assert E[0]==1 and F(2)<E[-1] and E[-1]**2<8
    assert set(map(F,c['E']))<=set(E) and U>0 and all(type(x)==int for x in hs)
    p,q=transform(n,c['d']);assert str(p(0))==a['p0'] and str(q(0))==a['q0'] and q(0)>0
    dual=nonnegative_ray(q,0)
    if portable:assert dual,"Standalone replay requires the full dual half-line"
    if not dual:
        # Keep the primitive dual-section hypothesis explicitly; the unconditional tests below
        # avoid using it in any published row that passes from zero.
        from gap import gap,previous,registry
        prev=previous(n);tg=F(c['target']);assert F(c['previous'])==prev and F(c['gap'])<=gap(n,T,tg,prev)
        assert nonnegative_ray(q,F(c['gap']))
    assert nonnegative_ray(-p,T*E[-1])
    mult=c.get('primitive_multiples',1);assert type(mult)==int and 1<=mult<=16 and E[-1]<4
    rows=h.get('multiple_heights',[hs]);assert len(rows)==mult and list(map(sum,zip(*rows)))==hs
    origin=F(0);geometry={}
    if c.get('kernels'):
        from independent_compact import compact_data
        from composite_heights import confirm_bins
        orig,gg,refs=compact_data(c);origin=F(str(orig))
        assert h['composite'] and F(h['origin'])==origin
        checks=confirm_bins(2*N*p,T,[(end,2*N*g) for end,g in gg],E,U,rows[0])
        checks+=sum(gaussian_bins(2*N*p,T*j*j,E,row,U) for j,row in enumerate(rows[1:],2))
        if portable:
            from portable_geometry import all_sources
            geometry.update(all_sources(c))
        else:
            for pack in refs:
                file=D/f'replay-{pack}.json';rec=read(file);assert rec['package']==pack and rec['returncode']==0 and rec['arguments']==[] and rec['log_sha256']==sha(D/f'replay-{pack}.log')
                geometry[file.name]=sha(file)
    else:
        assert not h.get('composite')
        checks=sum(gaussian_bins(2*N*p,T*j*j,E,row,U) for j,row in enumerate(rows,1))
    prefix=read(D/f'prefix-{n}-degree7.json')
    add=[F(0)]*len(hs);bonus=origin;dependencies=dict(geometry)
    for f,v in c['prices']:
        v=F(v);assert v>=0
        kind=f['kind']
        if kind in ('prefix','half-sum'):
            end=F(f['end']);assert end in E
            if kind=='prefix':lim=check_prefix(n,prefix[str(end)]);assert F(prefix[str(end)]['end'])==end
            else:
                file=D/f'half-sum-counts-{n}-16.json';row=next(h for h in read(file) if F(h['t'])==end);assert row['n']==n
                lim=check_half(row);dependencies[file.name]=sha(file)
            assert f['cap']==lim
            prices=[int(r<=end) for r in E[1:]];cost=F(lim,N)
        else:
            if kind=='compact-window':
                from audit_compact_window import check as compact_check
                file=D/f['file'];b=read(file)[f['index']]
                row,cost,refs=compact_check(b,n,True);grid=list(map(F,b['grid']))
                for pack in refs:dependencies['replay-'+pack+'.json']=sha(D/('replay-'+pack+'.json'))
            elif kind=='angular-bank':
                file=D/(tag.rsplit('-r',1)[0]+'-windows.json');b=read(file)[f['index']]
                assert b['dimension']==n
                row,cost=angular(n,b);grid=list(map(F,b['grid']))
            else:
                assert kind=='upstream-angular';o,file=cert(n);b=o['angular_cuts'][f['index']]
                from inherited_angular import verify as verify_inherited
                grid=list(map(F,o['E']));row,cost=verify_inherited(n,grid,b)
                if not portable:
                    replay=read(D/f'replay-{n}.json');assert replay['returncode']==0 and replay['log_sha256']==sha(D/f'replay-{n}.log')
                assert sha(file)==read(D/'pinned-input-hashes.json')['files'][file.relative_to(file.parents[3]).as_posix()]
            dependencies[file.name]=sha(file)
            prices=[]
            for l,r in zip(E,E[1:]):
                if l>=2:prices.append(F(0));continue
                assert r<=2 and l>=grid[0] and r<=grid[-1]
                prices.append(min(row[bisect_right(grid,l)-1:bisect_left(grid,r)]))
        bonus+=cost*v;add=[h+v*w for h,w in zip(add,prices)]
    assert bonus==F(a['bonus'])
    W=[h-floor(U*s) for h,s in zip(hs,add)]
    ceilings={F(x):check_prefix(n,prefix[x]) for x in a['prefix_ends']}
    assert all(F(prefix[x]['end'])==F(x) for x in a['prefix_ends'])
    vals=integer_census(n,E,W,U,a);rho=(F(str(p(0)))+bonus+pooled(n,E,vals,ceilings))/F(str(q(0)))
    assert rho==F(a['rho'])
    upper=F(a['conditional']);check_density(n,T,rho,upper)
    if not dual:upper=max(upper,F(c['target']))
    dependencies.update({file.name:sha(file) for file in (cf,hf,path,D/f'prefix-{n}-degree7.json')})
    out=dict(status='PASS',n=n,upper=str(upper),density=float(upper),unconditional_fourier_sign=dual,gaussian_nodes=checks,anchor_types=len(vals),dependencies=dependencies)
    if details:return dict(report=out,values=vals,prefix=ceilings,E=E,p=p,q=q,bonus=bonus,tau=T,c=c,residual_bins=W,rounding_unit=U)
    dump(path.with_name(path.stem+'-independent.json'),out);print(n,out['density'],'dual from zero',dual,flush=True)
if __name__=='__main__':
    for name in sys.argv[1:]:verify(D/name)

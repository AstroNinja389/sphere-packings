"""Reconstruct an inherited profile row, then verify a wholly new density bound."""
from native_review import *
from polynomial_tools import laguerre,signed_uppers,sign_half
from independent_fourier import gaussian_bins
from audit_angular import check as angular_check
from math import prod
from bisect import bisect_right

def source(n):
    d=certificate(n);f=D/f'native-{n}-lift-input.json';o=read(f);E=d['E'];J=E.index(2);N=2**n-1
    assert d['hashes']==o['source_hash'] and E==list(map(F,o['E'])) and o['threshold']==str(d['complement'])
    # A fresh complete original run verified the two integer maximizations, including all kernel rows.
    replay=next(p for p in sorted(D.glob(f'native-full-{n}-*.json')) if read(p).get('every_integer_matches'))
    c=read(replay);assert c['status']=='PASS' and all(sha(S/f'n{n}'/p)==h for p,h in c['inputs'].items())
    assert c['anchor_types']==len(d['values'])==J+1
    P,q=laguerre(n,d['dt']);assert P==d['p'] and q==d['q']
    assert len(E)-1==len(o['points'])==len(o['heights'])==len(o['row'])
    mm=1 if n in (15,17) else 2;assert o['multiples']==mm
    for i,(at,k,field) in enumerate(zip(o['points'],o['heights'],o['row'])):
        x=F(at);assert E[i]<=x<=E[i+1];a=fmpq(str(d['tau']*x));s=arb(0)
        for j in range(1,mm+1):
            v=a*j*j;s+=arb(P(v))*(-arb(v)/2).exp()
        h=F(k,o['unit']);assert arb(fmpq(str(h)))<=2*N*s
        if i<J:assert F(field)+d['values'][i+1]-d['values'][0]==h
        else:assert F(field)==h
    assert F(o['cost'])==d['values'][0]
    return E,list(map(F,o['row'])),d['values'][0],d['complement'],d['prefix'],{f.name:sha(f),replay.name:sha(replay)}
def exact_fields(n,c,E):
    old,vec,beta,comp,caps,refs=source(n);N=2**n-1
    aa=D/f'native-{n}-anchor-prices.json';ag=read(aa)
    from audit_geometry import check_prefix
    cp=dict(caps)
    for s in ag['caps']:
        z=F(s['end']);k=check_prefix(n,s);assert k==s['cap'];cp[z]=min(cp.get(z,N),k)
    add=[F(0)]*(len(E)-1);cost=F(0);threshold=F(0)
    for feature,a in c['prices']:
        lam=F(a);assert lam>0;kind=feature['kind']
        if kind=='profile-lift':
            assert feature['file'] in refs and set(old)<=set(E);G=old;V=vec;rhs=beta;threshold=max(threshold,comp)
        elif kind=='repriced-native':
            from native_reprice import verify_file
            G,V,rhs,proof=verify_file(feature['file']);assert n==proof['n'] and G==old and proof['status']=='PASS' and proof['source_sha']==feature['hash']
            refs[feature['file']]=proof['source_sha'];refs[f'CAPTURE{n}-FIELD-REVIEW-v1.json']=proof['field_audit_sha'];threshold=max(threshold,comp)
        elif kind=='native-angular':
            assert feature['file']==aa.name;w=ag['bank'][feature['i']]
            V,rhs=angular_check(n,w);G=list(map(F,w['grid']));refs[aa.name]=sha(aa)
        elif kind=='native-prefix':
            z=F(feature['end']);assert z in E and 1<z<=2
            G=[F(1),z];V=[F(1)];rhs=F(cp[z],N);refs[aa.name]=sha(aa)
            # A translated prefix may have its own inherited determinant split.
            threshold=max(threshold,comp)
        else:
            assert kind=='parity-anchor';G=[F(1),F(2)];V=[F(1)];rhs=F(1)
        assert set(G)<=set(E) and len(G)==len(V)+1
        for j,l in enumerate(E[:-1]):
            if G[0]<=l<G[-1]:add[j]+=lam*V[bisect_right(G,l)-1]
        cost+=lam*rhs
    return add,cost,threshold,refs
def producer(tag,fine=6):
    c=read(D/(tag+'.json'));n=c['n'];E0=list(map(F,c['E']));T=F(c['tau'])
    E=[l+(r-l)*i/fine for l,r in zip(E0,E0[1:]) for i in range(fine)]+[E0[-1]]
    p,q=laguerre(n,c['d']);N=2**n-1;U=10**17;ctx.prec=460
    rows=[signed_uppers(2*N*p,E,T*j*j,U) for j in range(1,c['multiples']+1)]
    dump(D/(tag+'-enclosures.json'),dict(n=n,source=sha(D/(tag+'.json')),E=list(map(str,E)),unit=U,rows=rows))
def verify(tag,save=True):
    c=read(D/(tag+'.json'));n=c['n'];h=read(D/(tag+'-enclosures.json'));E=list(map(F,h['E']));N=2**n-1
    cf=D/(tag+'.json');assert h['source']==sha(cf) and n==h['n'] and E[0]==1 and 2 in E and E[-1]<4 and all(l<r for l,r in zip(E,E[1:]))
    assert set(map(F,c['E']))<=set(E)
    T=F(c['tau']);p,q=transform(n,c['d']);ctx.prec=512
    assert q(0)>0 and nonnegative_ray(q,0) and nonnegative_ray(-p,T*E[-1])
    assert sign_half(q,0)['pass_sign'] and sign_half(-p,T*E[-1])['pass_sign']
    mm=c['multiples'];U=h['unit'];assert type(mm)==int and 1<=mm<=6 and len(h['rows'])==mm and U>0
    nodes=sum(gaussian_bins(2*N*p,T*j*j,E,row,U) for j,row in enumerate(h['rows'],1))
    f,cost,dep,refs=exact_fields(n,c,E);R=E[-1];z=1-2/R
    # For a single class use t²(t²-z²), with constant spherical mean h0.
    h0=F(3,n*(n+2))-z*z/n;assert h0>0 and z*z<=F(6,n+4)
    K=(1-z*z)//h0
    diff=[F(sum(s),U)-v for s,v in zip(zip(*h['rows']),f)]
    J=E.index(2);w=max([F(0)]+diff[J:])
    error=K*w+max(F(0),max(diff[:J])-w)
    rho=(F(str(p(0)))+cost+error)/F(str(q(0)));b=up(n,T,rho,23);check_density(n,T,rho,b)
    upper=max(dep,b)
    refs.update({cf.name:sha(cf),tag+'-enclosures.json':sha(D/(tag+'-enclosures.json'))})
    r=dict(n=n,status='PASS',upper=str(upper),density=float(upper),rho=str(rho),ledger_correction=str(error),class_size=K,profile_threshold=str(dep),conditional=str(b),heights_verified=nodes,inputs=refs)
    if save:dump(D/(tag+'-final-packing-proof.json'),r)
    print(tag,'verified',float(upper),'raw',c['density'],'correction',float(error),flush=True);return r
if __name__=='__main__':
    producer(sys.argv[1],*map(int,sys.argv[2:]));verify(sys.argv[1])

"""Deduct the witnessed endpoint slack for a fixed number of actual shortest lines."""
from native_lift_audit import exact_fields, producer, verify as parent_verify
from profiles import D, F, read, sha, dump, up, arb, ctx
from independent_fourier import transform
from audit_price import check_density
from flint import fmpq as Q
from fiber_parent import select
import sys

def audit(file,save=True):
    pr=read(file);n=pr['n'];assert n in (15,17,18,19,20,21,22,23) and pr['status']=='PASS'
    cf=D/file.name.replace('-final-packing-proof.json','.json');c=read(cf);tag=cf.stem
    ef=D/(tag+'-enclosures.json');h=read(ef)
    assert c['n']==n==h['n'] and sha(cf)==h['source']==pr['inputs'][cf.name] and pr['inputs'][ef.name]==sha(ef)
    T=F(c['tau']);N=2**n-1;M=n*(n+1)//2;ctx.prec=512
    E=list(map(F,h['E']));P,Qh=transform(n,c['d']);f,cost,floor,refs=exact_fields(n,c,E)
    for s,v in refs.items():assert pr['inputs'][s]==v
    mm=c['multiples'];assert mm==len(h['rows']) and M<=N and E[0]==1 and 2 in E and 2<E[-1]<4
    assert all(len(r)==len(f) for r in h['rows']) and f and Qh(0)>0 and floor==F(pr['profile_threshold'])
    if 'kernels' in c:
        from native_plane_mix_audit import primary
        orig,parts=primary(c);assert Q(pr['origin'])==orig
    else:orig,parts=Q(0),[]
    z=1-2/E[-1];mean=F(3,n*(n+2))-z*z/n;assert mean>0 and z*z<=F(6,n+4)
    K=(1-z*z)//mean;assert K==pr['class_size']
    diff=[F(sum(v),h['unit'])-b for v,b in zip(zip(*h['rows']),f)]
    J=E.index(2);w=max([F(0)]+diff[J:]);e=K*w+max(F(0),max(diff[:J])-w)
    numerator=F(str(P(0)+orig))+cost+e
    assert numerator/F(str(Qh(0)))==F(pr['rho'])
    value=arb(0)
    for j in range(1,mm+1):
        x=Q(str(T))*j*j;value+=arb(P(x))*(-arb(x)/2).exp()
    value+=sum((arb(g(1)) for stop,g in parts if stop>=1),arb(0))
    residual=2*N*value-arb(Q(str(f[0])))
    den=10**27;endpoint=F(int((residual*den).upper().ceil().unique_fmpz()),den)
    assert residual<=arb(Q(str(endpoint)))
    reduced=min(e,endpoint+(K-1)*w)
    saving=F(M,N)*(e-reduced)
    rho=(numerator-saving)/F(str(Qh(0)));upper=max(floor,up(n,T,rho,24));check_density(n,T,rho,upper)
    out=dict(n=n,status='PASS',upper=str(upper),rho=str(rho),parent_upper=pr['upper'],
             selected_exact_minimum_pairs=M,nonzero_classes=N,single_class_limit=K,
             ordinary_error=str(e),minimum_class_error=str(reduced),endpoint=str(endpoint),
             per_class_saving=str(saving),profile_threshold=str(floor),
             parent=file.name,parent_sha=sha(file),source_sha=sha(cf),enclosures_sha=sha(ef))
    if save:dump(D/('minfix-'+tag+'-final-packing-proof.json'),out)
    print('Exact minimum classes',n,tag,float(saving),float(upper),flush=True)
    return out
if __name__=='__main__':
    if sys.argv[1]=='search':
        from native_lift_search import search
        n,T=map(int,sys.argv[2:4]);tag='forcedopt'+str(n)+'t'+str(T)
        search(n,111,T,tag,18,3,1,False,None,True)
        if (D/(tag+'.json')).exists():
            producer(tag,5);parent_verify(tag);audit(D/(tag+'-final-packing-proof.json'))
    elif sys.argv[1]=='selected':
        for n in map(int,sys.argv[2:]):audit(D/select(n))
    else:audit(D/sys.argv[1])

"""Two independent constructions of the mixed plane/profile radials and of all spatial bin heights."""
from native_lift_audit import *
from composite_heights import upper_bins,confirm_bins
from portable_local import terms
from free_plane_geometry import check as check_domain
from audit_angular import poly
from audit_geometry import sphere
from flint import fmpq_poly as Poly, fmpq_mat as Mat, fmpq as Q

def primary(c):
    gg=[];origin=Q(0)
    for k in c['kernels']:
        f=D/k['local_kernel'];p=read(f);assert sha(f)==k['source_sha'];d=p['n'];n=c['n'];assert d>=n>=3
        m=len(p['powers']);R=Q(p['radius']);scale=Q(k['dilation']);q=Q(p['q']);alpha=Q(k['alpha']);z=Mat(m,1,list(map(Q,k['z'])))
        D0=Mat(m,m);W=Mat(m,m)
        for j,(w,b) in enumerate(zip(p['co'],p['B'])):
            h=poly(d,[F(0)]*j+[F(1)]);mean=sum((h[i]*Q(str(sphere(n,i))) for i in range(j+1)),Q(0))
            assert mean>=0
            a=Q(w)*Mat([[Q(t) for t in row] for row in b]);D0+=mean*a;W+=a
        origin+=(z.transpose()*D0.inv()*z)[0,0]/alpha
        hs=[Poly([R/(R-1),-scale/(R-1)])**j/q for j in p['powers']]
        u=sum((h*z[i,0] for i,h in enumerate(hs)),Poly([0]))
        v=sum((h*y*W[i,j] for i,h in enumerate(hs) for j,y in enumerate(hs)),Poly([0]))
        gg.append((R/scale,2*(u+alpha*v)))
    return origin,gg
def audit(tag,fine=4):
    cf=D/(tag+'.json');c=read(cf);n=c['n'];N=2**n-1;T=F(c['tau']);E0=list(map(F,c['E']))
    assert E0[0]==1 and 2 in E0 and 2<E0[-1]<4 and all(i<j for i,j in zip(E0,E0[1:]));ctx.prec=512
    E=[x+(y-x)*i/fine for x,y in zip(E0,E0[1:]) for i in range(fine)]+[E0[-1]]
    P,Qhat=laguerre(n,c['d']);p,q=transform(n,c['d']);assert p==P and q==Qhat and q(0)>0 and nonnegative_ray(q,0) and nonnegative_ray(-p,T*E[-1])
    assert sign_half(Qhat,0)['pass_sign'] and sign_half(-P,T*E[-1])['pass_sign']
    o,parts=primary(c);orig,S,refs=terms(c);assert o==orig and parts==S
    for atom in c['kernels']:check_domain(atom['local_kernel'],atom['source_sha'],atom['source'])
    U=10**17;scaled=[(stop,2*N*g) for stop,g in parts];mm=c['multiples'];assert type(mm)==int and 1<=mm<=6
    row,cnt=upper_bins(2*N*P,T,scaled,E,U);rows=[row]+[signed_uppers(2*N*P,E,T*j*j,U) for j in range(2,mm+1)]
    tested=confirm_bins(2*N*p,T,[(stop,2*N*g) for stop,g in S],E,U,row)
    tested+=sum(gaussian_bins(2*N*p,T*j*j,E,Urow,U) for j,Urow in enumerate(rows[1:],2))
    fields,cost,condition,files=exact_fields(n,c,E);files.update(refs)
    z=1-2/E[-1];mean=F(3,n*(n+2))-z*z/n;assert mean>0 and z*z<=F(6,n+4)
    K=(1-z*z)//mean;ix=E.index(2)
    dx=[F(sum(s),U)-v for s,v in zip(zip(*rows),fields)]
    e=max([F(0)]+dx[ix:]);err=K*e+max(F(0),max(dx[:ix])-e)
    rho=(F(str(p(0)+orig))+cost+err)/F(str(q(0)));b=up(n,T,rho,23);check_density(n,T,rho,b);upper=max(b,condition)
    files[cf.name]=sha(cf);hp=D/(tag+'-enclosures.json');dump(hp,dict(n=n,E=list(map(str,E)),rows=rows,source=sha(cf),unit=U));files[hp.name]=sha(hp)
    out=dict(n=n,status='PASS',upper=str(upper),density=float(upper),source_sha=sha(cf),profile_threshold=str(condition),conditional=str(b),rho=str(rho),origin=str(orig),exact_bin_correction=str(err),class_size=K,primary_nodes=cnt,secondary_nodes=tested,inputs=files)
    dump(D/(tag+'-final-packing-proof.json'),out);print(tag,n,float(upper),'active plane kernels',len(parts),'correction',float(err),flush=True)
if __name__=='__main__':audit(sys.argv[1],*map(int,sys.argv[2:]))

"""A family of exact supporting planes of the full dimension-19 profile polytope."""
from native_lift_audit import *
from fractions import Fraction
from functools import lru_cache
from rank_resource19 import independent_dp,ceilq
from independent_master import pooled
from pathlib import Path

def generate(tag,cert,scale=1):
    c=read(D/(cert+'.json'));n=c['n'];assert n in (15,17,18,19) and not c.get('kernels')
    native=read(D/f'native-{n}-lift-input.json');o=read(D/f'class-fields{n}-v1.json')
    support_kinds={'profile-lift','repriced-native'}
    a0=sum((F(x) for f,x in c['prices'] if f['kind'] in support_kinds),F(0)) or F(1)
    alpha=a0*F(scale)
    assert alpha>0;rest=dict(c,prices=[(f,x) for f,x in c['prices'] if f['kind'] not in support_kinds])
    h=read(D/(cert+'-enclosures.json'));assert h['source']==sha(D/(cert+'.json'))
    Fgrid=list(map(F,h['E']));base=list(map(F,native['E']));assert set(base)<=set(Fgrid)
    added,_,_,_=exact_fields(n,rest,Fgrid);res=dict()
    for i,(l,vs) in enumerate(zip(Fgrid[:-1],zip(*h['rows']))):
        j=bisect_right(base,l)-1;v=(F(sum(vs),h['unit'])-added[i])/alpha
        res[j]=max(res.get(j,v),v)
    dif=[ceilq((res[i]-F(k,native['unit']))*o['unit']) for i,k in enumerate(native['heights'])]
    return build(n,tag,dif,cert)

def build(n,tag,diff,origin):
    from poppath19 import integer_engine
    o=read(D/f'class-fields{n}-v1.json');E=list(map(F,o['grid']));J=E.index(2)
    assert len(diff)==len(E)-1 and all(type(x)==int for x in diff)
    v=integer_engine(o,'back');fields=o['fields'];vals=[]
    for row in o['rows']:
        j=row['anchor'];f=fields[row['field']];w=tuple(x+y for x,y in zip(f['long'],diff[J:]))
        a=v.run(w,tuple(f['pen']),tuple(row['cap']),row['offset']);vals.append(a+(row['short']+diff[j-1] if j else 0))
    v.run.cache_clear()
    report=dict(n=n,tag=tag,motivation=origin,old_sha=sha(D/f'class-fields{n}-v1.json'),perturbation=diff,values=vals)
    file=D/(tag+'-row.json');dump(file,report);return file

@lru_cache(maxsize=30)
def verify_file(name):
    file=D/name;assert file.parent==D and file.name.endswith('-row.json');p=read(file)
    n=p['n'];assert n in (15,17,18,19);o=read(D/f'class-fields{n}-v1.json');cf=D/f'CAPTURE{n}-FIELD-REVIEW-v1.json';cc=read(cf)
    assert cc['status']=='PASS' and cc['rows_checked']==len(o['rows']) and cc['source_sha']==p['old_sha']==sha(D/f'class-fields{n}-v1.json')
    assert all(sha(S/f'n{n}'/k)==v for k,v in o['sources'].items())
    d=certificate(n);lift=read(D/f'native-{n}-lift-input.json');E=d['E'];J=d['J'];U=o['unit'];ds=p['perturbation']
    assert E==list(map(F,o['grid']))==list(map(F,lift['E'])) and U==lift['unit']==10**16 and len(ds)==len(E)-1 and all(type(x)==int for x in ds)
    scale=o.get('scale',96);inc=tuple(ceilq(scale*(x-2)) for x in E[J+1:]);req=tuple((int(k),ceilq(scale*F(a))) for k,a in o['needs'].items())
    memo={};vals=[]
    for j,row in enumerate(o['rows']):
        f=o['fields'][row['field']];key=(row['field'],row['offset'],tuple(row['cap']))
        if key not in memo:memo[key]=independent_dp([x+y for x,y in zip(f['long'],ds[J:])],f['pen'],row['cap'],row['offset'],inc,req,o['ix'],o['threshold_price'])
        x=memo[key]+(row['short']+ds[j-1] if j else 0);assert x==p['values'][j],(j,x,p['values'][j])
        vals.append(d['values'][j]+F(x-row['old'],U))
    vec=[F(x+y,U)-(vals[i+1]-vals[0] if i<J else 0) for i,(x,y) in enumerate(zip(lift['heights'],ds))]
    report=dict(n=n,status='PASS',source=file.name,source_sha=sha(file),field_audit_sha=sha(cf),values_checked=len(vals),unit=U,threshold=str(d['complement']))
    return E,vec,vals[0],report
if __name__=='__main__':
    if sys.argv[1]=='audit':
        f=sys.argv[2];_,_,_,r=verify_file(f);dump(D/(Path(f).stem+'-audit.json'),r);print(r,flush=True)
    else:print(generate(*sys.argv[2:]),flush=True)

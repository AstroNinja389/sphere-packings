"""Review of Fourier signs, both stored integer recurrences and the complete density split."""
from profiles import *
from independent_fourier import transform,nonnegative_ray
from audit_geometry import check_prefix
from audit_price import check_density
from gap import OLD
from math import comb
from bisect import bisect_left
import traceback

STEM={15:'partial-ref',17:'correct-ref',18:'critical',19:'combo',20:'tight',21:'tight21',22:'tightSplit',23:'tight23'}
def both(n,stem):
    if n==15:return [stem+'-character-audit-384-'+x+'.json' for x in ('front','back')]
    if n==17:return [stem+'-cyclic-'+x+'-192.json' for x in ('front','back')]
    return [stem+'-'+x+'-96.json' for x in ('front','back')]

def certificate(n):
    ctx.prec=512;folder=S/f'n{n}';stem=STEM[n]
    files=[folder/t for t in both(n,stem)];f,b=map(read,files);refs={p.name:sha(p) for p in files}
    orig=folder/(stem+'-bundle.json');bundle=read(orig);base=folder/bundle['baseline'];c=read(base);E=list(map(F,c['E']));J=E.index(2)
    assert sha(orig)==f['bundle_sha256']==b['bundle_sha256'] and sha(base)==bundle['baseline_sha256'] and c['n']==n and E==list(map(F,bundle['E']))
    def bind(name,h):
        path=folder/name
        if not path.is_file():
            path=next(folder/ob['candidate'] for ob in bundle['cuts'] if Path(ob['candidate']).name==name)
        assert sha(path)==h,(n,path)
        refs[path.relative_to(folder).as_posix()]=h
    for obj in (f,b):
        assert obj['n']==n and obj['status'].startswith('PASS')
        for name,h in obj['dependencies'].items():bind(name,h)
    for key in ('rho','class_budget_scaled','integer_branch_maxima','rounding_denominator','density'):assert f[key]==b[key]
    heights=list(map(int,f['integer_branch_maxima']));assert len(heights)==J+1
    refs[orig.name]=sha(orig);refs[base.name]=sha(base)
    dt=[];k=F(1)
    for i,v in enumerate(c['c']):
        if i:k*=F(n+2*i-2,2*i)
        dt.append(k*F(v))
    p,q=transform(n,dt);P0=F(str(p(0)));Q0=F(str(q(0)));tau=F(c['tau0']);rho=F(f['rho'])
    assert P0==sum(dt) and Q0==sum((-1)**j*v for j,v in enumerate(dt)) and Q0>0
    assert (P0+F(f['class_budget_scaled']))/Q0==rho
    no_gap=nonnegative_ray(q,0);assert nonnegative_ray(-p,tau*E[-1])
    if n==15:un=folder/(stem+'-character-audit-384-union.json')
    elif n==17:un=folder/'population-audit.json'
    else:un=folder/(stem+'-96-union.json')
    u=read(un);refs[un.name]=sha(un);assert u['status']=='PASS'
    for name,h in u.get('audits',u.get('dependencies',{})).items():bind(name,h)
    if n==15:bind(u['geometry'],u['geometry_sha'])
    if n==17:
        un0=folder/(stem+'-cyclic-192-union.json');u0=read(un0);assert u0['status']=='PASS'
        bind('geometric-input.json',u0['geometry']);refs[un0.name]=sha(un0)
        bind('new-frame.json',read(folder/'PROOF-HASHES-v1.json')['new-frame.json'])
        nf=read(folder/'new-frame.json');assert nf['status']=='PASS' and nf['complement']==u0['complement'] and F(nf['edge'])==E[-1]
        for name,h in u0['audits'].items():bind(name,h)
    complement=F(0);aa=lambda x:arb(fmpq(str(x)))
    if n in (15,17):complement=F(u['complement'] if n==15 else u0['complement'])
    if n==19:
        # The full-class census in combo_audit has its own determinant branch;
        # it remains a premise even when the Fourier sign holds from zero.
        proof_file=folder/'population-proof.json';pop=read(proof_file)
        assert sha(proof_file)==u['dependencies'][proof_file.name] and pop['status']=='PASS' and pop['det_branch']==40
        complement=F(pop['complement']);assert (arb.pi()**aa(F(19,2))/(aa(F(21,2))).gamma())/arb(40).sqrt()<aa(complement)
    if 'dual_arg' in u:
        g=F(u['dual_arg']);D0=F(u['det_split']);V=arb.pi()**aa(F(n,2))/(aa(F(n,2))+1).gamma()
        Vprev=arb.pi()**aa(F(n-1,2))/(aa(F(n-1,2))+1).gamma()
        prev=S/f'n{n-1}'/(STEM[n-1]+'-96-union.json')
        pv=read(prev);assert pv['status']=='PASS' and F(pv['upper'])==OLD[n-1]
        assert 16*arb.pi()**2*(Vprev/aa(OLD[n-1]))**2/aa(D0*tau)>aa(g)
        assert nonnegative_ray(q,g)
        complement=F(int((V/aa(D0).sqrt()*10**20).upper().ceil().unique_fmpz()),10**20)
        refs['../'+prev.parent.name+'/'+prev.name]=sha(prev)
    else:assert no_gap
    N=2**n-1;caps={}
    if n==17:caps={F(u['limit']['end']):check_prefix(n,u['limit'])}
    if n>=18:
        capfile=folder/'prefix-polynomials.json';refs[capfile.name]=sha(capfile)
        for v in read(capfile):
            e=F(v['end']);k=check_prefix(n,v)
            if e in E:caps[e]=min(k,caps.get(e,N))
    if u.get('translated'):
        tf=folder/'translation-audit.json';t=read(tf);assert t['status']=='PASS'
        source=folder/'translation-prefix-proofs.json';manifest=read(folder/'PROOF-HASHES-v1.json')
        bind(tf.name,manifest[tf.name]);bind(source.name,manifest[source.name])
        if 'source_sha' in t:assert t['source_sha']==sha(source)
        refs[tf.name]=sha(tf)
        for v in t['rows']:
            e=F(v['end']);caps[e]=min(caps.get(e,N),v['cap'])
    U=f['rounding_denominator'];allow=F(f['class_budget_scaled'])-F(max(heights),U)
    vals=[allow+F(h,U) for h in heights]
    # Assign ordered capacity slots to their highest admissible score, with the empty class always available.
    limits=[min([N]+[k for x,k in caps.items() if x>=e]) for e in E[1:J+1]]
    sorted_scores=[vals[0]]*(J+1);ids=[0]*(J+1);arg=0
    for j in reversed(range(1,J+1)):
        if vals[j]>vals[arg]:arg=j
        sorted_scores[j]=vals[arg];ids[j]=arg
    contributions=[0]*(J+1);last=0
    for j,lim in enumerate(limits,1):
        assert lim>=last;contributions[ids[j]]+=lim-last;last=lim
    contributions[0]+=N-last;assert sum(contributions)==N
    revised=(P0+sum(k*v for k,v in zip(contributions,vals))/N)/Q0
    if n>17:assert revised==F(u['rho'])
    if n==17:assert revised<=F(u['spatial_ratio'])
    bound=F(u.get('upper',u.get('final_bound','0')));assert bound==OLD[n] and bound>=complement
    check_density(n,tau,revised,bound)
    return dict(n=n,c=c,dt=dt,p=p,q=q,tau=tau,E=E,J=J,values=vals,weights=contributions,prefix=caps,origin=P0,denominator=Q0,complement=complement,old=bound,revised=revised,hashes=refs,dual_from_zero=no_gap)

def audit(n):
    d=certificate(n)
    out=dict(n=n,status='PASS',upper=str(d['old']),hashes=d['hashes'],rho=str(d['revised']),complement=str(d['complement']),dual_from_zero=d['dual_from_zero'],anchor_types=len(d['values']),prefix_caps=len(d['prefix']),scope='Both stored integer-budget arrays and dependency hashes, independent entire Fourier and spatial tail signs, exact population and determinant union. Stored kernel and DP proofs are inputs.')
    dump(D/f'native-review-{n}.json',out)
    print(n,'pass',float(d['old']),len(d['hashes']),d['dual_from_zero'],flush=True)
if __name__=='__main__':
    for n in (list(map(int,sys.argv[1:])) or list(STEM)):
        try:audit(n)
        except Exception:traceback.print_exc()

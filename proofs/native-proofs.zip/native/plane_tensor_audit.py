"""A full rational Bernstein test of compact two- and three-line inequalities, without trace leaves."""
from profiles import *
from audit_angular import poly,nonnegative
from flint import fmpq as Q,fmpz_mpoly_ctx,fmpz_poly as ZP
from math import comb,lcm,gcd
from time import monotonic
from functools import reduce
import numpy as np
def coefficients(src):
    co=list(map(F,src['co']));n=src['n'];assert sum(co)==F(src['q']) and co[0]==1 and min(co)>=0
    dd=len(co)-1;pol={}
    r=len(src["powers"])
    for i in range(r):
        for j in range(i,r):
            ff=poly(n,[w*F(b[i][j]) for w,b in zip(co,src['B'])])
            pol[i,j]=[F(str(ff[k])) for k in range(dd+1)]
    return pol,dd
def cap(pol,degree):
    from flint import fmpq_poly as P
    v=set()
    for k in range(8):
        a,b=F(k,8),F(k+1,8)
        v.update([(1,a,a*a),(1,(a+b)/2,a*b),(1,b,b*b)])
    vs=sorted(v)
    for ii,va in enumerate(vs):
        for vb in vs[ii:]:
            q=[sum((ps[k]*(va[i]*vb[j]+(va[j]*vb[i] if i!=j else 0)) for (i,j),ps in pol.items()),F(0)) for k in range(degree+1)]
            assert nonnegative(-P([Q(str(w)) for w in q]),0,F(1,4))
    return len(vs)*(len(vs)+1)//2
def simultaneous(pol,degree):
    # x,y,z are the three nested radius-complement ratios. a,b,c here are 13 times squared lengths.
    C=fmpz_mpoly_ctx.get(('x','y','z'));x,y,z=C.gens()
    a=19-6*x;b=19-6*x*y;c=19-6*x*y*z
    den=4*a*b*c;nums=[(a+b-c)**2*c,(a+c-b)**2*b,(b+c-a)**2*a]
    den_pows=[den**(degree-i) for i in range(degree+1)]
    unit=lcm(*(v.denominator for ps in pol.values() for v in ps))
    coeff={k:[int(unit*a) for a in ps] for k,ps in pol.items()}
    hs=[x**3,(x*y)**3,(x*y*z)**3]
    total=C.constant(0)
    for num,(i,j),weight in zip(nums,((0,1),(0,2),(1,2)),(C.constant(1),z**6,(y*z)**6)):
        h=[[C.constant(1),r,r*r] for r in (hs[i],hs[j])]
        # Multiply each angular coefficient only once before collecting the angular powers.
        numerator=C.constant(0);v=C.constant(1)
        for k,dp in enumerate(den_pows):
            cc=sum((w[k]*(h[0][l]*h[1][m]+(h[0][m]*h[1][l] if l!=m else 0)) for (l,m),w in coeff.items()),C.constant(0))
            numerator+=v*dp*cc
            if k!=degree:v*=num
        total-=weight*numerator
    return total
def make_controls(poly):
    deg=tuple(map(int,poly.degrees()));shape=tuple(n+1 for n in deg);arr=np.zeros(shape,dtype=object)
    for key,a in poly.to_dict().items():arr[tuple(map(int,key))]=int(a)
    for axis,n in enumerate(deg):
        offset=ZP([1,1]);binoms=[comb(n,j) for j in range(n+1)];ell=lcm(*binoms);sc=[ell//v for v in binoms]
        moved=np.moveaxis(arr,axis,-1)
        for ind in np.ndindex(moved.shape[:-1]):
            q=ZP(moved[ind].tolist()[::-1])(offset)
            moved[ind]=[int(q[n-k])*sc[k] for k in range(n+1)]
    return arr
def bisect(arr,axis):
    t=np.moveaxis(arr,axis,0);n=t.shape[0]-1;a=[];b=[]
    for j in range(n+1):
        a.append(t[0]*(1<<(n-j)));b.append(t[-1]*(1<<(n-j)))
        if j<n:t=t[:-1]+t[1:]
    return (np.moveaxis(np.stack(a),0,axis),np.moveaxis(np.stack(b[::-1]),0,axis))
def verify(path,maxnodes=3000,save=True):
    from itertools import product
    st=monotonic();src=read(path);pol,k=coefficients(src);cc=cap(pol,k)
    P=simultaneous(pol,k);B=make_controls(P);print('controls',src['n'],B.shape,P.degrees(),'seconds',round(monotonic()-st,1),flush=True)
    stack=[(B,(0,0,0))];nodes=0;deep=0;maxa=maxb=None
    while stack and nodes<maxnodes:
        a,ds=stack.pop();nodes+=1;deep=max(deep,sum(ds));lo=a.min()
        if lo>=0:continue
        assert min(a[ix] for ix in product(*[(0,-1)]*3))>=0,('positive plane interaction',ds)
        # Use the Bernstein maximum second difference to favor directions of curvature.
        score=[max(abs(np.diff(a,n=2,axis=i)).flat)*(a.shape[i]-1)**2 if a.shape[i]>=3 else 0 for i in range(3)]
        axis=max(range(3),key=score.__getitem__);ds=tuple(v+(i==axis) for i,v in enumerate(ds))
        assert max(ds)<65
        stack.extend((v,ds) for v in bisect(a,axis))
    out=dict(status='INCOMPLETE' if stack else 'PASS',n=src['n'],frozen_sha=sha(path),cube_degrees=list(map(int,P.degrees())),cap_tests=cc,nodes=nodes,pending=len(stack),max_depth=deep,seconds=round(monotonic()-st,2))
    if save:dump(D/f'geometry-tensor-{src["n"]}.json',out)
    print(out,flush=True);return out
if __name__=='__main__':
    from templates import templates
    for n in sys.argv[1:]:verify(templates()[int(n)])

"""Exact sign checks on half lines and interval bounds for radial Gaussians."""
from profiles import *
from flint import fmpq as Q, fmpq_poly as P, arb, arb_poly, ctx
from math import comb,lcm
def ar(x):return arb(Q(str(x)))
def laguerre(n,d):
    alpha=Q(n,2)-1;x=P([0,1]);a=P([1]);b=1-x/(alpha+1)
    even=P([Q(str(d[0]))]);odd=b*Q(str(d[1]))
    for j in range(1,len(d)-1):
        a,b=b,((2*j+alpha+1-x)*b-j*a)/(j+alpha+1)
        if j%2:even+=b*Q(str(d[j+1]))
        else:odd+=b*Q(str(d[j+1]))
    return even+odd,even-odd
def split_int(v):
    n=len(v)-1;l=[];r=[]
    for i in range(n+1):
        l.append(v[0]<<(n-i));r.append(v[-1]<<(n-i))
        v=[a+b for a,b in zip(v,v[1:])]
    return l,r[::-1]
def sign_half(p,t0,scale=60,limit=90):
    """Homogeneous Bernstein subdivision on [0,1] with x=t0+scale*u/(1-u)."""
    t0=Q(str(t0));s=Q(scale);n=p.degree()
    if n<0:return dict(pass_sign=True,nodes=0)
    v=p(P([t0,s]));b=[v[j]/comb(n,j) for j in range(n+1)]
    den=lcm(*[int(h.q) for h in b]);b=[int(z*den) for z in b]
    stack=[(b,0,0)];nodes=0
    while stack:
        v,i,k=stack.pop();nodes+=1
        if min(v)>=0:continue
        for z,j in [(v[0],i),(v[-1],i+1)]:
            if z<0:
                if j==2**k:return dict(pass_sign=False,at='infinity',nodes=nodes)
                t=t0+s*j/(2**k-j);assert p(t)<0
                return dict(pass_sign=False,at=str(t),nodes=nodes)
        if k>=limit:return dict(pass_sign=False,at='unresolved',nodes=nodes)
        l,r=split_int(v);stack.append((r,i*2+1,k+1));stack.append((l,i*2,k+1))
    return dict(pass_sign=True,nodes=nodes)
def extrema_points(p):
    from flint import fmpq_poly
    root=2*p.derivative()-p;values=root.complex_roots()
    assert sum(int(m) for _,m in values)==root.degree()
    return [z.real for z,m in values if z.imag.contains(0)]
def arb_poly_of(p):return arb_poly([arb(x) for x in p.coeffs()])
def signed_uppers(p,E,tau,unit=10**32):
    """Closed bins; include every possibly-real stationary point and both endpoints."""
    tau=Q(str(tau));e=[arb(Q(str(t))*tau) for t in E];pp=arb_poly_of(p)
    f=lambda t:pp(t)*(-t/2).exp()
    roots=extrema_points(p);ext=[(t,f(t)) for t in roots if not(t<e[0] or t>e[-1])]
    end=list(map(f,e));out=[]
    for k,(l,r) in enumerate(zip(e,e[1:])):
        c=[end[k],end[k+1]]+[y for t,y in ext if not(t<l or t>r)]
        out.append(max(int((a*unit).upper().ceil().unique_fmpz()) for a in c))
    return out
if __name__=='__main__':
 p,q=laguerre(15,['2','1','3']);assert p(0)==6 and q(0)==4
 assert sign_half(P([1,-2,1]),2)['pass_sign'] and not sign_half(P([1,-3,1]),0)['pass_sign']
 print('Polynomial controls passed.')

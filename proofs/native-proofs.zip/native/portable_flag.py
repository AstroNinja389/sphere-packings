"""Independent Poisson denominator verification on a complete dyadic reduced-plane domain."""
from fractions import Fraction as F
from flint import arb,ctx,fmpq as Q
from independent_fourier import gaussian_bins,nonnegative_ray
from profiles import read,sha
def audit_domain(n,T,g,upper,pre1,pre2):
    ctx.prec=512;av=lambda q:arb(Q(str(q)))
    def volume(m):return arb.pi()**av(F(m,2))/(av(F(m,2)+1)).gamma()
    U=F(g['upper']);target=F(g['target']);d1,d2=map(F,(g['pre1'],g['pre2']));G,L=g['R'],g['L']
    assert g['n']==n and F(g['tau'])==T and 0<target<U and upper<=U and 0<pre1<=d1 and 0<pre2<=d2
    assert type(G)==type(L)==int and G>0 and L>0 and L%2==0
    x,X,y,Y,h,H=g['box'];assert all(type(v)==int for v in (x,X,y,Y,h,H)) and 0<x<X and 0<y<Y and h==0 and 2*H==L
    S=4*arb.pi()**2/av(T);covol=S**av(F(n,2))*2**n*av(U)/volume(n)
    gamma=lambda m,d:4*(av(d)/volume(m))**av(F(2,m))
    length=S*(2*av(target/d1)*volume(n-1)/volume(n))**2
    area=S**2*(4*av(target/d2)*volume(n-2)/volume(n))**2
    proj=gamma(n-1,d1)**(n-1)*covol**2
    assert 0<F(g['gap']) and av(F(g['gap']))<length and av(F(x,G))<length
    assert av(F(g['area'],G*G))<area and av(F(y*X,G*G))<area
    assert av(F(X,G))>gamma(n,U)*covol**av(F(2,n))
    assert av(F(int(g['projection_power_upper']),G**n))>proj and av(F(Y,G))**(n-1)*av(F(x,G))>proj
def tree(n,q,g,proof,mesh_path):
    G,L=g['R'],g['L'];o=read(mesh_path);assert sha(mesh_path)==proof['mesh_sha'] and o['sha']==proof['prior_sha'] and o['unit']==proof['unit']
    sub=o['sub'];U=o['unit'];v=o['signed_upper'];assert type(U)==type(sub)==int and min(U,sub)>0 and len(v)==sub*o['end'] and all(type(k)==int for k in v)
    assert nonnegative_ray(q,F(g['gap']))
    E=[F(i,sub) for i in range(len(v)+1)];analytic=gaussian_bins(-q,1,E,v,U);values=[max(0,-x) for x in v]
    pairs=list(map(tuple,proof['indices']));assert len(set(pairs))==len(pairs) and all(type(i)==type(j)==int and (j>0 or (j==0 and i>0)) for i,j in pairs)
    need=proof['lower'];assert type(need)==int and need>=0;stack=[tuple(g['box'])];code=iter(proof['tree']);full=empty=0
    while stack:
        b=stack.pop();c=next(code)
        if c!='.':
            assert c in ('0','1','2');i=2*int(c);mid=(b[i]+b[i+1])//2;assert b[i]<mid<b[i+1]
            l=list(b);r=list(b);l[i+1]=r[i]=mid;stack.extend([tuple(r),tuple(l)]);continue
        lo,hi,bl,bh,ul,uh=b
        if hi*bh<g['area'] or lo*bl**(n-1)>int(g['projection_power_upper']) or lo*(L**2-uh**2)>bh*L**2:
            empty+=1;continue
        total=0
        for i,j in pairs:
            # The lower bound zero used for a bin crossing the first admissible
            # dual length is valid on actual nonzero lattice vectors in this box.
            left=F(i)+F(j*ul,L);right=F(i)+F(j*uh,L)
            low=F(lo*max(F(0),left,-right)**2+bl*j*j,G);high=F(hi*max(left**2,right**2)+bh*j*j,G)
            first=int(low*sub);last=int(high*sub)
            if last<len(values):total+=min(values[first:last+1])
        assert total>=need;full+=1
    assert next(code,None) is None and full>0
    return F(2*need,U),dict(positive_boxes=full,empty_boxes=empty,analytic=analytic)

"""Offline exact verification of radial/angular matrix sources, including dimension restriction."""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from flint import fmpq as Q, fmpq_poly as P, fmpq_mat as M
from profiles import D, read, sha

@lru_cache(maxsize=80)
def zonals(n,k):
    assert n>=3 and k>=0
    g=[P([1])]
    if k:g.append(P([0,1]))
    t=P([0,1])
    for j in range(1,2*k):
        g.append(((2*j+n-2)*t*g[-1]-j*g[-2])/Q(j+n-2))
    assert all(v(1)==1 and v.degree()==j for j,v in enumerate(g))
    return tuple(g[::2])

@lru_cache(maxsize=120)
def restriction(n,d,k):
    """Expand every even source harmonic in the even target harmonics by exact division."""
    assert 3<=n<=d
    small=zonals(n,k)
    result=[]
    for j,source in enumerate(zonals(d,k)):
        rest=source;row=[Q(0)]*(j+1)
        for h in range(j,-1,-1):
            row[h]=rest[2*h]/small[h][2*h]
            rest-=row[h]*small[h]
        assert not rest and min(row)>=0 and sum(row)==1
        result.append(tuple(row))
    return result

def matrices(file,digest,n):
    assert file.parent==D and sha(file)==digest
    src=read(file);d=src['n'];weights=tuple(map(Q,src['co']));q=Q(src['q'])
    powers=src['powers'];m=len(powers);assert 2<=m<=5 and all(type(x)==int and x>0 for x in powers)
    step=powers[1]-powers[0];assert step>0 and powers==[powers[0]+i*step for i in range(m)]
    assert len(src['B'])==len(weights) and weights[0]==1 and min(weights)>=0 and sum(weights)==q
    R=Q(src.get('radius','19/13'));assert 1<R<=3 and (R<=2 or m==3)
    A=[M([[Q(x) for x in row] for row in b]) for b in src['B']]
    for a in A:
        assert a.nrows()==a.ncols()==m and a==a.transpose()
        for size in range(1,m+1):
            for I in combinations(range(m),size):assert M([[a[i,j] for j in I] for i in I]).det()>=0
    coeff=restriction(n,d,len(A)-1)
    m0=sum((w*r[0]*a for w,r,a in zip(weights,coeff,A)),M(m,m));W=sum((w*a for w,a in zip(weights,A)),M(m,m))
    assert m0.det()>0
    return src,R,powers,q,W,m0

def terms(cert):
    out=[];origin=Q(0);refs={}
    for atom in cert['kernels']:
        name=atom['local_kernel'];p=D/name;src,R,powers,q,W,M0=matrices(p,atom['source_sha'],cert['n'])
        assert src['n']==atom['source'] and not atom.get('cutoff')
        alpha=Q(atom['alpha']);t=Q(atom['dilation']);z=M(len(powers),1,list(map(Q,atom['z'])))
        assert alpha>0 and 1<=t<R
        v=M0.solve(z);assert M0*v==z
        origin+=(z.transpose()*v)[0,0]/alpha
        # Interpolate the radial cost at degree+1 rational points. The degree bound
        # follows from the declared powers, so matching these values is an identity.
        deg=2*max(powers);vals=[]
        for i in range(deg+1):
            x=Q(i,deg);u=M(len(powers),1,[x**k/q for k in powers])
            vals.append(2*((u.transpose()*z)[0,0]+alpha*(u.transpose()*W*u)[0,0]))
        if F(src.get('angular_debit',0)):
            from plane_error_budget import debit
            delta,C=map(lambda t:Q(str(t)),debit(src))
            mode=src.get('debit_payment','radial')
            if mode=='constant':
                origin+=4*alpha*delta*C*C/q**2
            else:
                assert mode=='radial'
                for i in range(deg+1):
                    w=Q(i,deg)**powers[0]
                    vals[i]+=2*alpha*delta*(C*w-w*w)/q**2
        poly=P([0]);choose=P([1])
        for i in range(deg+1):
            poly+=vals[0]*choose
            choose*=P([-i,deg])/Q(i+1);vals=[b-a for a,b in zip(vals,vals[1:])]
        out.append((R/t,poly(P([R/(R-1),-t/(R-1)]))))
        refs[name]=sha(p)
    return origin,out,refs

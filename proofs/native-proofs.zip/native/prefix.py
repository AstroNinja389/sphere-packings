"""Rational spherical prefix bounds for opposite pairs with squared length at most s."""
from fractions import Fraction as F
from functools import cache
from flint import fmpq as Q, fmpq_mat as M, fmpq_poly as P
import math

@cache
def moment(n,k):
    return Q(math.prod(2*i+1 for i in range(k)),math.prod(n+2*i for i in range(k)))

@cache
def harmonic(n,m):
    x=P([0,1])
    if m<2: return P([1]) if m==0 else x
    return ((2*m+n-4)*x*harmonic(n,m-1)-(m-1)*harmonic(n,m-2))/(m+n-3)

def expand(n,poly):
    r=P(poly); terms=[Q(0)]*(r.degree()+1)
    for j in range(r.degree(),-1,-1):
        g=harmonic(n,j);a=r[j]/g[j]
        terms[j]=a
        r-=a*g
    assert not r
    return terms

def best(n,s,maxdegree=12):
    s=Q(str(s));assert 1<=s<2
    t=(1-1/(2*s))**2
    winner=None
    for shift in (0,1):
        a=[moment(n,k+shift+1)-t*moment(n,k+shift) for k in range(2*maxdegree+1)]
        for d in range(maxdegree+1):
            mat=M([[a[i+j] for j in range(d+1)] for i in range(d+1)])
            try:v=list(mat.solve(M(d+1,1,[1]*(d+1))).entries())
            except (ZeroDivisionError,ValueError):continue
            norm=sum(v)
            if norm<=0:continue
            p=P([w/norm for w in v]);cap=int(((1-t)*norm).floor())
            if winner and cap>=winner['cap']:continue
            f=(P([-t,0,1])*P([0,1])**(2*shift)*p(P([0,0,1]))**2)
            coeff=expand(n,f)
            if not (coeff[0]>0 and min(coeff)>=0):continue
            assert cap==int((f(1)/coeff[0]).floor()) and cap>0
            winner=dict(cap=cap,shift=shift,p=list(map(str,p.coeffs())),end=str(s))
    return winner

"""Read matched two-direction Fourier budgets without treating distinct classes independently."""
from pathlib import Path
from fractions import Fraction as F
from math import prod
import json,hashlib,sys
from flint import arb,fmpq,ctx
ctx.prec=220
sys.set_int_max_str_digits(0)
D=Path(__file__).resolve().parent
S=D.parent/'sweep'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=1)+'\n',encoding='utf-8')
def up(n,tau,r,digits=16):
    a=arb(fmpq(n,2))
    val=arb(fmpq(str(tau/8)))**a*arb(fmpq(str(r)))/(a+1).gamma()
    den=10**digits
    k=int((val*den).upper().ceil().unique_fmpz())
    assert val<arb(fmpq(k,den)) or val==arb(fmpq(k,den))
    return F(k,den)
def profile(n,stem,front,back):
    d=S/f'n{n}';f=d/front;b=d/back;a=read(f);z=read(b);bp=d/(stem+'-bundle.json');bb=read(bp);fp=d/bb['baseline'];cc=read(fp)
    assert a['n']==n and z['n']==n and a['status'].startswith('PASS') and z['status'].startswith('PASS')
    assert sha(bp)==a['bundle_sha256']==z['bundle_sha256']
    for rr in (a,z):
        for name,hsh in rr['dependencies'].items():assert sha(d/name)==hsh,(name,hsh)
    assert sha(fp)==bb['baseline_sha256']==a['dependencies'][fp.name]
    for k in ['rho','class_budget_scaled','integer_branch_maxima','rounding_denominator']:assert a[k]==z[k]
    E=list(map(F,bb['E']));J=E.index(2);m=list(map(int,a['integer_branch_maxima']));assert len(m)==J+1
    s=F(1);p=q=F(0)
    for j,c in enumerate(map(F,cc['c'])):
        if j:s*=F(n+2*j-2,2*j)
        p+=s*c;q+=(-1)**j*s*c
    rho=F(a['rho']);assert q>0 and (p+F(a['class_budget_scaled']))/q==rho
    val=[rho+F(k-max(m),a['rounding_denominator'])/q for k in m]
    return E[:J+1],val,F(cc['tau0']),{i.name:sha(i) for i in [f,b,bp,fp]}
def get15():return profile(15,'partial-ref','partial-ref-character-audit-384-front.json','partial-ref-character-audit-384-back.json')

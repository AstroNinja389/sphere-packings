"""Add a common length-dependent rank-defect condition at each integer class size."""
from profiles import *
from audit_price import class_caps,ceil,floor,check_density
from math import isqrt
from bisect import bisect_left
from functools import lru_cache
import base64,zlib

@lru_cache(maxsize=100000)
def phi(t,M,lam):
    """Rational upper enclosure at one endpoint, including negative excess."""
    if t<0:return max(F(0),-t-lam)
    v=(t+lam)**2+(M-1)*t*t;s=10**20
    k=isqrt(v.numerator*s*s//v.denominator)
    k+=int(k*k*v.denominator<v.numerator*s*s)
    u=F(k,s);assert u*u>=v
    return (u-t-lam)/2

def class_indices(n,E):
    J=E.index(2);ds=E[J+1:];out=[]
    for A in [None]+E[1:J+1]:
        v=[class_caps(n,A,b) for b in ds]
        for i in reversed(range(len(v)-1)):v[i]=min(v[i],v[i+1])
        out.append([bisect_left(v,i) for i in range(1,v[-1]+1)])
    return out

@lru_cache(maxsize=6000)
def long_rank_uppers(E,m,lam):
    return tuple(max(phi(l-2,m,lam),phi(r-2,m,lam)) for l,r in zip(E,E[1:]))
def verify(prf,data,save=False):
    cf=D/prf['certificate'];n=data['report']['n'];assert prf['n']==n and sha(cf)==prf['source_sha']
    E=data['E'];J=E.index(2);U=data['rounding_unit'];W=data['residual_bins'];assert len(E)==len(W)+1
    a=read(cf);ind=class_indices(n,E);raw=zlib.decompress(base64.b64decode(a['choices']));rr,cc=a['choice_shape'];assert rr==J+1
    opt={(j,k):(l,F(q),y) for j,k,l,q,y in prf['prices']}
    assert len(opt)==len(prf['prices'])
    V=[];used=set()
    @lru_cache(maxsize=1000)
    def welch_scores(l):
        return [w+ceil(l*(1-2/r)**2) for w,r in zip(W[J:],E[J+1:])]
    for j,ids in enumerate(ind):
        off=int(j>0);ss=W[j-1] if off else 0;best=ss
        for k in range(1,len(ids)+1):
            m=k+off
            l=a['prices'][raw[j*cc+k]];mu=0;lam=F(0)
            if (j,k) in opt:
                l,lam,mu=opt[j,k];assert m>n and type(mu)==int and type(l)==int and min(l,mu)>=0 and lam<2
                used.add((j,k))
            rankreq=F(m*(m-n),n*(m-1)) if m>n else F(0)
            scores=welch_scores(l).copy()
            sh=ss
            if mu:
                coeff=long_rank_uppers(tuple(E[J:]),m,lam)
                scores=[w+ceil(mu*v) for w,v in zip(scores,coeff)]
                if off:sh+=ceil(mu*max(phi(E[j-1]-2,m,lam),phi(E[j]-2,m,lam)))
                sh-=floor(mu*(2-lam)*(m-n))
            for t in reversed(range(len(scores)-1)):scores[t]=max(scores[t],scores[t+1])
            val=sh+sum(scores[i] for i in ids[:k])-floor(l*rankreq)
            best=max(best,val)
        V.append(F(best,U))
    assert used==set(opt) and all(x<=y for x,y in zip(V,data['values']))
    from independent_master import pooled
    rho=(F(str(data['p'](0)))+data['bonus']+pooled(n,E,V,data['prefix']))/F(str(data['q'](0)))
    upper=up(n,data['tau'],rho,23);check_density(n,data['tau'],rho,upper)
    assert data['report']['unconditional_fourier_sign']
    return dict(n=n,status='PASS',upper=str(upper),density=float(upper),rho=str(rho),original=data['report']['upper'],value_improvements=sum(a<b for a,b in zip(V,data['values'])),priced_branches=len(opt),extra_values=V)

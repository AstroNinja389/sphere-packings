"""Two independent integer DPs combining the old linear excess with the common nullspace length inequality."""
import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
from native_review import *
from rank_ledger import phi
import numpy as np
from functools import lru_cache

def parameters(o,row,M,lam,w,scale):
    E=list(map(F,o['grid']));J=E.index(2);needs={int(k):F(v) for k,v in o['needs'].items()};j=row['anchor']
    short=max(F(0),2-max(4-E[-1],E[j-1])-lam) if j else F(0)
    inc=[ceilq(scale*((t-2)+w*phi(t-2,M,lam))) for t in E[J+1:]]
    req={k:ceilq(scale*(g+w*((2-lam)*(min(k,M)-19)-short))) for k,g in needs.items()}
    req={k:max(0,a) for k,a in req.items()}
    assert len(inc)==len(row['cap']) and max(req.values())>0
    return tuple(inc),tuple(sorted(req.items()))
def ceilq(q):return -((-q.numerator)//q.denominator)

def independent_dp(W,pen,cap,off,inc,items,ix,popcost):
    """Forward exact resource states. Collapse all resources only after their final threshold."""
    need=dict(items);maxk=min(len(cap) and cap[-1],max(need)-off);R=max(need.values());hmax=cap[-1]
    mag=(hmax+2)*max(map(abs,W))+(hmax+2)**2*sum(abs(p) for p in pen)+abs(popcost)
    dt=np.int64 if 3*mag<2**60 else object;neg=-2**61 if dt==np.int64 else -2**210;assert 2*mag<-neg
    f=np.full((maxk+1,R+1),neg,dtype=dt);f[0,0]=0;tail=np.full(hmax+1,neg,dtype=dt)
    for i,(limit,cost,p,t) in enumerate(zip(cap,W,pen,inc)):
        # Before the layer penalty is applied, staying at a count is permitted.
        top=min(limit,maxk);shift=min(R,t)
        for k in range(1,top+1):
            prev=f[k-1];new=f[k]
            if shift<R:new[shift:R]=np.maximum(new[shift:R],prev[:R-shift]+cost)
            new[R]=max(new[R],max(prev[R-shift:])+cost)
            # This threshold applied when the k-th vector was first selected; it also
            # applies to a retained state of that same count.
            low=need.get(k+off,0)
            if low:new[:low]=neg
        if top==maxk:
            tail[maxk]=max(tail[maxk],max(f[maxk]))
            for k in range(maxk+1,limit+1):tail[k]=max(tail[k],tail[k-1]+cost)
        for k in range(top+1):
            fee=p*(k+off)*(k+off-1)+(popcost if i==ix and k+off>=19 else 0)
            f[k]-=fee
        if top==maxk:
            for k in range(maxk,limit+1):
                tail[k]-=p*(k+off)*(k+off-1)+(popcost if i==ix and k+off>=19 else 0)
    return int(max(np.max(f),np.max(tail)))
def candidate(o,config):
    sys.path.insert(0,str(S/'n19'));from pop_dp import Exact
    M,lam,w,scale=config;lam,w=map(F,(lam,w));M,scale=int(M),int(scale)
    withcfg={};vals=[]
    for row in o['rows']:
        off=row['offset'];inc,req=parameters(o,row,M,lam,w,scale)
        if (inc,req) not in withcfg:
            a=Exact.__new__(Exact);a.R=max(v for k,v in req);a.need=dict(req);a.inc=inc;a.way='back';a.ix=o['ix'];a.lam=o['threshold_price'];withcfg[inc,req]=a
        a=withcfg[inc,req];field=o['fields'][row['field']]
        x=a.run(tuple(field['long']),tuple(field['pen']),tuple(row['cap']),off)
        vals.append(x+row['short'])
    Exact.run.cache_clear()
    return vals
def compose(o,values):
    d=certificate(19);N=2**19-1;J=d['J'];U=o['unit'];olds=[r['old'] for r in o['rows']]
    assert len(olds)==len(values)==J+1 and all(v<=orig for v,orig in zip(values,olds))
    V=[v-F(a-b,U) for v,a,b in zip(d['values'],olds,values)]
    from independent_master import pooled
    rho=(d['origin']+pooled(19,d['E'],V,d['prefix']))/d['denominator'];b=max(d['complement'],up(19,d['tau'],rho,23));check_density(19,d['tau'],rho,b)
    return rho,b
def search(tag,capture,configs):
    f=D/capture;o=read(f);assert o['n']==19 and all(sha(S/'n19'/k)==v for k,v in o['sources'].items())
    vals=[r['old'] for r in o['rows']];pick=[-1]*len(vals);candidates=[]
    for t,txt in enumerate(configs):
        M,lam,w,sc=txt.split(':');co=[int(M),lam,w,int(sc)];v=candidate(o,co);candidates.append(co)
        for j,x in enumerate(v):
            if x<vals[j]:pick[j]=t;vals[j]=x
        rho,b=compose(o,vals);print(tag,co,float(b),'improved',sum(j>=0 for j in pick),flush=True)
        dump(D/(tag+'.json'),dict(n=19,input=f.name,source_sha=sha(f),configs=candidates,selection=pick,integers=vals,upper=str(b),rho=str(rho),status='second integer replay pending'))
def audit(tag):
    a=read(D/(tag+'.json'));f=D/a['input'];assert sha(f)==a['source_sha'];o=read(f);E=list(map(F,o['grid']));J=E.index(2);U=o['unit'];d=certificate(19)
    archive=read(S/'n19/combo-front-96.json');assert [r['old'] for r in o['rows']]==list(map(int,archive['integer_branch_maxima'])) and E==d['E']
    assert all(sha(S/'n19'/k)==v for k,v in o['sources'].items());assert o['ix']==E.index(F('161/80'))-J-1
    b=data=read(S/'n19/combo-bundle.json');assert o['threshold_price']==int(F(b['population'])*U)
    values=[];memo={};active=0
    for j,(row,ix) in enumerate(zip(o['rows'],a['selection'],strict=True)):
        assert j==row['anchor'] and row['offset']==int(j>0);val=row['old']
        if ix>=0:
            M,l,ww,sc=a['configs'][ix];l=F(l);ww=F(ww);assert M>19 and ww>=0 and 0<=l<2 and sc>0
            incr,req=parameters(o,row,M,l,ww,sc)
            for inc,x in zip(incr,E[J+1:]):
                t=x-2
                if ww:
                    h=(F(inc,sc)-t)/ww;assert 2*h+(t+l)>=0 and (2*h+t+l)**2>=(t+l)**2+(M-1)*t*t
            short=max(F(0),2-max(4-E[-1],E[j-1])-l) if j else F(0)
            for k,i in req:
                floor=F(o['needs'][str(k)])+ww*((2-l)*(min(k,M)-19)-short)
                assert i==max(0,ceilq(sc*floor))
            key=(row['field'],tuple(row['cap']),bool(j),incr,req)
            if key not in memo:
                field=o['fields'][row['field']]
                memo[key]=independent_dp(field['long'],field['pen'],row['cap'],row['offset'],incr,req,o['ix'],o['threshold_price'])
            val=memo[key]+row['short'];assert val<row['old'];active+=1
        assert val==a['integers'][j],(j,val,a['integers'][j]);values.append(val)
    rho,b=compose(o,values);assert str(b)==a['upper'] and str(rho)==a['rho']
    result=dict(n=19,status='PASS',upper=str(b),density=float(b),rho=str(rho),improved_anchors=active,original_branches=len(values),source_sha=sha(D/(tag+'.json')),capture_sha=sha(f),conditional_floor=str(d['complement']))
    dump(D/(tag+'-final-packing-proof.json'),result);print(tag,'second integer DP passed',float(b),active,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='audit':audit(sys.argv[2])
    else:search(sys.argv[2],sys.argv[3],sys.argv[4:])

"""Read-only reconstruction of the best eight native bounds, including determinant complements."""
from profiles import *
from native_lift_audit import exact_fields,gaussian_bins,check_density
from independent_fourier import transform,nonnegative_ray
from native_plane_mix_audit import primary,terms,check_domain,confirm_bins
from portable_flag import audit_domain,tree
from native_minimum_charge import audit as minimum
from functools import lru_cache
from flint import fmpq as Q
from gap import OLD

@lru_cache(None)
def replay(name):
    f=D/name;r=read(f);assert r['status']=='PASS';n=r['n'];N=2**n-1
    suf='-final-packing-proof.json';assert name.endswith(suf);tag=name[:-len(suf)];references={name:sha(f)}
    if tag.startswith('minfix-'):
        parent=r['parent'];rec=replay(parent);assert sha(D/parent)==r['parent_sha']
        assert minimum(D/parent,False)==r;references.update(rec['references'])
        return dict(upper=r['upper'],references=references,method='exact-minimum endpoint')
    if tag.startswith('flag') and (D/(tag+'-dual-plane.json')).exists():
        docf=D/(tag+'-dual-plane.json');doc=read(docf);cf=D/doc['prior_fourier'];g=doc['geometry']
        parent=cf.stem+suf;rec=replay(parent);pr=read(D/parent)
        assert rec['upper']==pr['upper'] and sha(docf)==r['source_sha'] and sha(cf)==doc['prior_sha']
        U=F(pr['upper']);T=F(read(cf)['tau']);floor=F(pr['profile_threshold']);target=F(g['target'])
        assert F(g['upper'])==U and floor<=target
        audit_domain(n,T,g,U,OLD[n-1],OLD[n-2]);_,q=transform(n,read(cf)['d'])
        assert nonnegative_ray(q,0) and F(str(q(0)))==F(doc['den'])
        amt,_=tree(n,q,g,doc,D/doc['mesh']);upper=max(target,U*F(doc['den'])/(F(doc['den'])+amt))
        assert upper==F(r['upper'])
        references.update(rec['references']);references.update({p.name:sha(p) for p in [docf,D/doc['mesh']]})
        return dict(upper=str(upper),references=references,method='dual section and native ledger')
    cf=D/(tag+'.json');hf=D/(tag+'-enclosures.json');h=read(hf);c=read(cf);ctx.prec=512
    assert h['source']==sha(cf) and c['n']==h['n']==n
    p,q=transform(n,c['d']);T=F(c['tau']);edges=list(map(F,h['E']));U=h['unit'];mm=c['multiples']
    assert edges[0]==1 and 2 in edges and edges[-1]<4 and set(map(F,c['E']))<=set(edges)
    assert type(U)==type(mm)==int and U>0 and 1<=mm<=6 and mm==len(h['rows'])
    assert all(x<y for x,y in zip(edges,edges[1:])) and nonnegative_ray(-p,T*edges[-1])
    a,cost,floor,refs=exact_fields(n,c,edges);ledger=r.get('inputs',r.get('dependencies'))
    for k,v in refs.items():assert ledger[k]==v
    assert floor==F(r['profile_threshold'])
    if 'kernels' in c:
        origin,field=primary(c);check,g,_=terms(c);assert check==origin and field==g
        for atom in c['kernels']:check_domain(atom['local_kernel'],atom['source_sha'],atom['source'])
        count=confirm_bins(2*N*p,T,[(b,2*N*z) for b,z in g],edges,U,h['rows'][0])
    else:origin=Q(0);count=gaussian_bins(2*N*p,T,edges,h['rows'][0],U)
    for j,v in enumerate(h['rows'][1:],2):count+=gaussian_bins(2*N*p,T*j*j,edges,v,U)
    z=(1-2/edges[-1])**2;s=F(3,n*(n+2))-z/n;assert s>0 and z<=F(6,n+4)
    K=(1-z)//s;ix=edges.index(2);res=[F(sum(i),U)-j for i,j in zip(zip(*h['rows']),a)]
    tail=max([F(0)]+res[ix:]);error=max([K*tail]+[k+(K-1)*tail for k in res[:ix]])
    num=F(str(p(0)+origin))+cost+error;den=F(str(q(0)));assert den>0
    if 'dual_flag' in c:
        g=c['dual_flag'];t=F(g['target']);parent,=c['dual_sources'];pr=replay(parent);U0=F(pr['upper'])
        assert c['dual_sources'][parent]==sha(D/parent);references.update(pr['references'])
        audit_domain(n,T,g,U0,OLD[n-1],OLD[n-2]);docf=D/(tag+'-reciprocal-flag.json');doc=read(docf)
        assert doc['prior_sha']==sha(cf);mesh=D/doc['mesh'];amt,_=tree(n,q,g,doc,mesh)
        den+=amt;floor=max(t,floor);references.update({f.name:sha(f) for f in (docf,mesh)})
    else:assert nonnegative_ray(q,0)
    rho=num/den;bound=F(r['upper'])
    assert rho==F(r['rho']) and bound==max(F(r['conditional']),floor)
    check_density(n,T,rho,F(r['conditional']))
    references.update(ledger);references.update({hf.name:sha(hf),cf.name:sha(cf)})
    return dict(upper=str(bound),source=cf.name,references=references,bin_checks=count,method='native Fourier and parity ledger')


from fractions import Fraction
from pathlib import Path
import sys
from review_native_final import replay
if not __debug__:
    raise RuntimeError("Run with assertions enabled.")
name, target = sys.argv[1:]
assert name == Path(name).name and Fraction(replay(name)["upper"]) == Fraction(target)

from profiles import F
from functools import cache
from prefix import best,harmonic,expand
from math import comb
from flint import fmpq as Q,fmpq_poly as P
@cache
def linecap(n,z):
    # Round the *cosine* upward to share identical optimization problems.
    # Produce a polynomial and verify the sign on the larger symmetric interval.
    if z<0:return 1
    k=-(-z.numerator*256//z.denominator);r=F(k,256)
    if r>=1:return None
    return atcos(n,r)
@cache
def atcos(n,r):
    # The rational Gram solve in prefix works at any cosine below 1.
    from prefix import moment
    from flint import fmpq_mat as M
    t=Q(str(r))**2;winner=None
    for sh in (0,1):
        seq=[moment(n,j+sh+1)-t*moment(n,j+sh) for j in range(13)]
        for d in range(7):
            try:u=M([[seq[i+j] for j in range(d+1)] for i in range(d+1)]).solve(M(d+1,1,[1]*(d+1))).entries()
            except (ZeroDivisionError,ValueError):continue
            norm=sum(u)
            if norm<=0:continue
            v=int(((1-t)*norm).floor())
            if winner is not None and v>=winner[0]:continue
            p=P([a/norm for a in u]);f=P([-t,0,1])*P([0,1])**(2*sh)*p(P([0,0,1]))**2
            h=expand(n,f)
            if min(h)>=0 and h[0]>0:
                assert v==int((f(1)/h[0]).floor());winner=(v,dict(n=n,z=str(r),shift=sh,p=list(map(str,p.coeffs())),cap=v))
    return winner
@cache
def multiplicity(n,A,B,l,r):
    R=B-l/4
    if R< F(1,4):return 0,None
    # A centered pair +/- exists only if its two points are distinct and separated by >=1.
    # Radius spread <1 ensures normalized cos bound increases with each squared radius.
    z=1-1/(2*R)
    if z<0:return 1,None
    eta=(B-A)**2/(l*(4*A-l))
    options=[linecap(n,z)]
    if eta<1:options.append(linecap(n-1,(z+eta)/(1-eta)))
    options=[o for o in options if o]
    return min(options,key=lambda o:o[0]) if options else (4**n,None)
def endpoints(A,B,l,r):
    return max(F(0),1-r/(2*A)),min(1-1/(2*B),1-l/(2*B))
def bern(poly,a,b):
    q=poly(P([Q(str(a)),Q(str(b-a))]));d=max(0,poly.degree())
    return [sum((q[j]*comb(i,j)/comb(d,j) for j in range(i+1)),Q(0)) for i in range(d+1)]
def upper(poly,a,b,bits=35):
    u=bern(poly,a,b);tol=Q(1,2**bits);stack=[u];m=max(u[0],u[-1]);result=m
    while stack:
        v=stack.pop();h=max(v)
        if h<=m+tol:
            result=max(result,h);continue
        L=[v[0]];R=[v[-1]]
        while len(v)>1:
            v=[(x+y)/2 for x,y in zip(v,v[1:])]
            L.append(v[0]);R.append(v[-1])
        m=max(m,v[0]);stack.extend([L,R[::-1]])
    return F(str(max(result,m)))

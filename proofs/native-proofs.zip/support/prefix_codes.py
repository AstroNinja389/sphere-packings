"""Construct exact even Delsarte polynomials for the counts of all short classes."""
from fractions import Fraction as F
from functools import cache
from math import prod
from sympy import Matrix, Rational

@cache
def monomial(d,k):
    # x P_i = (i+d-2)/(2i+d-2) P_(i+1) + i/(2i+d-2) P_(i-1)
    a=[F(1)]
    for _ in range(k):
        b=[F(0)]*(len(a)+1)
        for i,v in enumerate(a):
            b[i+1]+=v*F(i+d-2,2*i+d-2)
            if i: b[i-1]+=v*F(i,2*i+d-2)
        a=b
    return a

@cache
def moment(d,k):
    return prod((F(2*i+1,d+2*i) for i in range(k)),start=F(1))

def candidate(d,end,degree,shift):
    c2=(1-1/(2*end))**2
    w=Matrix([[Rational(moment(d,i+j+shift+1)-c2*moment(d,i+j+shift)) for j in range(degree+1)] for i in range(degree+1)])
    try:
        v=[F(x) for x in w.inv()*Matrix.ones(degree+1,1)]
    except ValueError:
        return None
    if sum(v)==0: return None
    v=[x/sum(v) for x in v]
    # f(t)=t^(2 shift) (t^2-c^2) p(t^2)^2
    z=[F(0)]*(2*degree+shift+2)
    for i,a in enumerate(v):
        for j,b in enumerate(v):
            z[i+j+shift+1]+=a*b
            z[i+j+shift]-=c2*a*b
    g=[F(0)]*(2*len(z)-1)
    for i,val in enumerate(z):
        for j,x in enumerate(monomial(d,2*i)): g[j]+=val*x
    if g[0]<=0 or min(g)<0:return None
    return {"cap":int(sum(z)//g[0]),"end":str(end),"shift":shift,"p":list(map(str,v))}

def best(d,end,maxdegree=9):
    possible=[s for r in range(maxdegree+1) for e in (0,1) if (s:=candidate(d,end,r,e))]
    return min(possible,key=lambda s:s["cap"]) if possible else None

if __name__=="__main__":
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser()
    p.add_argument('dimensions',nargs='+',type=int)
    o=p.parse_args()
    for n in o.dimensions:
        cuts=[s for i in range(8,17) if (s:=best(n,F(i,8)))]
        path=Path(__file__).parent/f"prefix-n{n}-v1.json"
        with path.open('x') as file:json.dump(cuts,file,indent=2)
        print(n,[(s["end"],s["cap"]) for s in cuts],flush=True)

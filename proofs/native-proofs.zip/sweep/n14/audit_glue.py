"""Direct integer-matrix and signed representative replay of the dimension-fourteen frame floor."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from math import prod,comb
import json
from flint import fmpq_mat,fmpq,arb,ctx
H=Path(__file__).resolve().parent;D=F(7,20)
def check_matrix(n,m,u):
    hist=[]
    for sg in (1,-1):
        v=[(F(0),)*(n-k)+(u,)*k for k in range(n+1)]
        if sg<0:v=[(-z[0],)+z[1:] for z in v]
        cap=lambda z:sum(q for q in z if q>0)
        pts={z for z in v if cap(z)<=m}
        for x,y in combinations(v,2):
            a=cap(x);b=cap(y)
            if (a-m)*(b-m)<0:
                k=(m-a)/(b-a);pts.add(tuple(l+(r-l)*k for l,r in zip(x,y)))
        low=None
        for z in pts:
            R=fmpq_mat([[fmpq(str(1+x if i==j else -(x+y)/2)) for j,y in enumerate(z)] for i,x in enumerate(z)])
            for j in range(1,n):
                assert fmpq_mat([[R[k,l] for l in range(j)] for k in range(j)]).det()>0
            det=R.det();assert det>0;low=det if low is None else min(det,low)
        hist.append((len(pts),str(low)))
    return hist
def mixed_bound(vs):
    # Finite average over actual integer representatives scaled by their denominator.
    n=len(vs[0]);m=len(vs)
    mat=[[F(sum(v[i]*v[j] for v in vs),m) for j in range(n)] for i in range(n)]
    return sum(mat[i][i] for i in range(n))+D*max(sum(map(abs,row)) for row in mat)
def reps(xs,p,par):
    base=[(x+p//2)//p for x in xs];v=[r-p*b for r,b in zip(xs,base)]
    half=[i for i,t in enumerate(v) if 2*abs(t)==p]
    defect=(sum(base)-par)%2
    if half:
        out=[]
        for bb in product((0,1),repeat=len(half)):
            if sum(bb)%2!=defect:continue
            r=v.copy()
            for i,b in zip(half,bb):
                if b:r[i]=-r[i]
            out.append(r)
        return out
    if not defect:return [v]
    top=max(map(abs,v));out=[]
    for i,r in enumerate(v):
        if abs(r)==top:
            row=v.copy();row[i]-=p if r>0 else -p;out.append(row)
    return out
def check():
    proof=json.loads((H/'cyclic-replay-7-20.json').read_bytes());assert proof['16']['unresolved']==proof['17']['unresolved']==0 and proof['16']['tested']==124350 and proof['17']['tested']==319769
    p=5;worst=F(0);n=0
    for i in range(15):
        for j in range(15-i):
            if i+j==0:continue
            v=[1]*i+[2]*j+[0]*(14-i-j);eta=sum(v)%2
            best=min(mixed_bound(reps([k*t for t in v],p,k*eta))/p**2 for k in (1,2));worst=max(worst,best);n+=1
    assert n==119 and worst<2
    pairs=[]
    for w in (8,10,12,14):
        for t in range(min(14-w,(16-w)//2)+1):
            x=[1]*w+[2]*t+[0]*(14-w-t)
            for eta in (0,1):pairs.append(mixed_bound(reps(x,4,eta))/16)
    assert max(pairs)<2 and all(sum(comb(j,k) for k in range(0,j+1,2))==2**(j-1) for j in (4,6,8,10,12,14))
    a=check_matrix(14,D,D); b=check_matrix(14,F(5,16),F(1,8));c=check_matrix(15,F(3,4),F(5,16))
    assert [z[1] for z in a]==['1523/1600']*2 and [z[1] for z in b]==['1']*2
    ctx.prec=160;g=arb.pi()**7/(5040*256)
    base=json.loads((H/'joint-base-forward.json').read_bytes());B=F(base['final_bound']);f=lambda z:arb(fmpq(z.numerator,z.denominator))
    assert f(B)*f(D/2).exp()<18*g
    comp=14*g/f(F(1523,1600)).sqrt();up=int(float(comp)*10**15)+1;assert comp<arb(fmpq(up,10**15))
    o=dict(status='PASS',cyclic_five= str(worst),cyclic_patterns=119,cyclic_sixteen='147/80',cyclic_seventeen='505/289',noncyclic_four_max=str(max(pairs)),frame_determinants=a,old_frame_determinants=b,dependent_fifteen_determinants=c,frame_complement='0.'+str(up).zfill(15),portable_floor='7/10',old_premise_independently_established=True)
    (H/'glue-audit.json').write_text(json.dumps(o,indent=2)+'\n');print(o)
if __name__=='__main__':check()


"""Two independent integer class DPs for first-k length sums, sharing the public Fourier sign checker."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import os,sys,json
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import numpy as np
import public_replay as pr
from public_replay import H,R
from flint import arb,ctx,fmpq
import audit_frame_bound as st
def ceil(q):return -((-q.numerator)//q.denominator)
class Verifier:
    def __init__(self,E,needs,scale,direction):
        self.J=E.index(2);self.bins=[ceil((v-2)*scale) for v in E[self.J+1:]];self.needs={k:ceil(v*scale) for k,v in needs.items()};self.R=max(self.needs.values());self.direction=direction;self.summary=[]
    def callback(self,W,pen,cap,off,J,*args):
        assert not args and J==self.J
        val=self.compute(tuple(W[J:]),tuple(pen),tuple(cap),off)
        self.summary.append(val);return val
    @lru_cache(None)
    def compute(self,W,pen,cap,off):
        R=self.R;rs=np.arange(R+1);g=cap[-1]
        mag=(g+1)*max(map(abs,W))+(g+1)**2*sum(map(abs,pen))
        dtype=np.int64 if mag<2**59 else object
        neg=-(1<<61) if dtype==np.int64 else -2**200
        if self.direction=='back':
            nxt=np.zeros((g+1,R+1),dtype=dtype)
            for i in range(len(cap)-1,-1,-1):
                w=W[i];p=pen[i];inc=self.bins[i];dest=np.minimum(rs+inc,R)
                f=nxt.copy()
                for k in range(cap[i],-1,-1):
                    f[k]=nxt[k]-p*(k+off)*(k+off-1)
                    if k==cap[i]:continue
                    good=dest>=self.needs.get(k+off+1,0)
                    f[k,good]=np.maximum(f[k,good],w+f[k+1,dest[good]])
                nxt=f
            return int(nxt[0,0])
        f=np.full((g+1,R+1),neg,dtype=dtype);f[0,0]=0
        for i in range(len(cap)):
            # Entries [k,r] are the best valid prefixes already attaining at least r mass.
            z=f.copy();u=self.bins[i]
            for k in range(1,cap[i]+1):
                demand=np.maximum(rs,self.needs.get(k+off,0))
                z[k]=np.maximum(f[k,demand],z[k-1,np.maximum(0,demand-u)]+W[i])
            for k in range(cap[i]+1):z[k]-=pen[i]*(k+off)*(k+off-1)
            f=z
        return int(np.max(f[:,0]))
def main(tag,direction,scale):
    assert direction in ('back','front')
    bundle=pr.bundle(tag);b=json.loads(bundle.read_bytes());assert not b.get('frame')
    E=list(map(F,b['E']));assert E[-1]<=F(21,8)
    needs={14:F(7,10),15:F(3,2)}
    stronger=tag.startswith(('sharp','torus'))
    if tag.startswith('partial') or stronger:
        needs[13]=F(7,10) if stronger else F(1,2)
        if stronger:del needs[14]  # implied by the 13-slot floor
    if tag.startswith('torus'):needs[12]=F(1,10)
    checker=Verifier(E,needs,scale,direction);st.backward=checker.callback
    out=H/f'{tag}-mass-{direction}-{scale}.json';r=st.audit(bundle,out)
    gl=json.loads((H/'glue-audit.json').read_bytes());assert gl['status']=='PASS'
    ctx.prec=160;V=arb.pi()**7/5040
    comp=F(gl['frame_complement'])
    if 13 in needs:
        part=json.loads((H/('sharper-partial-audit.json' if stronger else 'basic-partial-audit.json')).read_bytes());assert part['passed'] and part['status']=='PASS' and F(part['m'])*2==needs[13]
        if stronger:comp=F(0)
        D=part['ambient_det_cap']
        if 12 in needs:
            tor=json.loads((H/'two-torus-audit.json').read_bytes());assert tor['status']=='PASS' and F(tor['length_floor'])==needs[12];D=min(D,tor['ambient_det_cap'])
        threshold=V/arb(D).sqrt();i=int(float(threshold)*10**15)+1
        assert threshold<arb(fmpq(i,10**15));comp=max(comp,F(i,10**15))
    claimed=F(r['density']);final=max(comp,claimed);status=dict(status='PASS',kind='Fourier and class DP plus complementary density branches',source=out.name,budget=r['class_budget_scaled'],profile_cases=len(checker.summary),thresholds={k:str(v) for k,v in needs.items()},scale=scale,complement=str(comp),final_outward=format(float(final),'.15f'),final_rational=str(final),independent_direction=direction)
    if direction=='front':
        other=json.loads((H/f'{tag}-mass-back-{scale}.json').read_bytes())
        assert other['integer_branch_maxima']==r['integer_branch_maxima'] and other['rho']==r['rho']
    (H/f'{tag}-composed-{direction}-{scale}.json').write_text(json.dumps(status,indent=2)+'\n');print(status['final_outward'],direction,flush=True)
if __name__=='__main__':
    sys.set_int_max_str_digits(0);main(sys.argv[1],sys.argv[2],int(sys.argv[3]))


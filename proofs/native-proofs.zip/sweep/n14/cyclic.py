"""Complete residue-pattern sieve with exact integer sign-averaged upper bounds."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import comb,lcm,gcd
import numpy as np,json,sys
H=Path(__file__).resolve().parent
def batch(p,chunk=4096):
    h=p//2
    it=combinations(range(14+h),h); acc=[]
    for bars in it:
        row=tuple(b-a-1 for a,b in zip((-1,)+bars,bars))
        if any(row[t-1] for t in range(1,h+1) if gcd(t,p)==1):
            if p!=16 or sum(row[::2]) in (8,10,12,14):acc.append(row)
        if len(acc)==chunk:yield np.array(acc,dtype=np.int64);acc=[]
    if acc:yield np.array(acc,dtype=np.int64)
def main(p,D):
    h=p//2;q=np.arange(1,h+1);den=lcm(*range(1,15))*D.denominator*p*p; out={};overall=0;witness=None;npat=0;survivors=[]
    for C in batch(p):
        parity=C@q%2
        # Represent generator by r/p+eta*e1. Odd p fixes eta. Even p tests both possible lifts.
        for eta in ([0,1] if p%2==0 else [parity]):
            best=np.full(len(C),2**60,dtype=np.int64)
            for k in range(1,h+1):
                rounded=(2*k*q+p)//(2*p);rr=abs(k*q-rounded*p)
                if not rr.max():continue
                A=C@rr;B=C@(rr*rr);hi=np.max(np.where(C>0,rr,0),axis=1)
                top=rr[None,:]==hi[:,None];cnt=np.maximum(1,(C*top).sum(axis=1))
                rest=A-cnt*hi;s=np.max(np.where((C>0)&~top,rr,0),axis=1)
                flip=(C@rounded-k*eta)%2;hh=(C*(2*rr==p)).sum(axis=1)
                flip=np.where(hh>0,0,flip)
                b=B+flip*p*(p-2*hi)
                direct=A*hi
                # Select signs on half-residues uniformly with the correct parity.
                direct=np.where(hh>=2,np.maximum(np.where(hh==2,2,1)*hi*hi,s*(A-hh*hi)),direct)
                c=cnt
                f1=c*hi*hi+p*p-2*p*hi+(c-1)*abs(c*hi*hi-2*p*hi)+abs(c*hi-p)*rest
                f2=c*s*(rest+abs(c*hi-p))
                coeff=np.where(flip,np.maximum(f1,f2),direct*c)
                cost=(b*c*D.denominator+coeff*D.numerator)*(den//(D.denominator*p*p*c))
                best=np.minimum(best,cost)
            npat+=len(C);ix=int(np.argmax(best))
            if best[ix]>overall:overall=int(best[ix]);witness=[C[ix].tolist(),int(eta[ix] if hasattr(eta,'__len__') else eta)]
            for ix in np.flatnonzero(best>=2*den):
                if len(survivors)<100:survivors.append([C[ix].tolist(),int(eta[ix] if hasattr(eta,'__len__') else eta),str(F(int(best[ix]),den))])
            out['surviving_lifts']=out.get('surviving_lifts',0)+int((best>=2*den).sum())
    out.update(modulus=p,mass=str(D),tested_lifts=npat,worst=str(F(overall,den)),worst_pattern=witness,first_unexcluded=survivors,all_excluded=overall<2*den)
    print(p,D,out['worst'],npat,out['surviving_lifts'],flush=True)
    fn=f'cyclic-{p}-{D.numerator}-{D.denominator}.json';(H/fn).write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main(int(sys.argv[1]),F(sys.argv[2]))


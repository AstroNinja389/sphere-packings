"""Ordered-simplex vertex proof of the determinant bound in rank fourteen."""
from fractions import Fraction as F
from itertools import combinations
from math import prod
from pathlib import Path
import json
H=Path(__file__).resolve().parent
def evaluate(n,d,u):
    data=[]
    for neg in (0,1):
        vertices=[tuple((u if i>=k else F(0))*(-1 if neg and i==0 else 1) for i in range(n)) for k in range(n+1)]
        mass=lambda v:sum(max(F(0),t) for t in v)
        cand={tuple(v) for v in vertices if mass(v)<=d}
        for x,y in combinations(vertices,2):
            if (mass(x)-d)*(mass(y)-d)<0:
                s=(d-mass(x))/(mass(y)-mass(x));cand.add(tuple(a+s*(b-a) for a,b in zip(x,y)))
        worst=None
        for z in cand:
            w=[1+2*t for t in z]
            if min(w)<=0:return None
            a=sum(1/t for t in w);b=sum(t/f for t,f in zip(z,w));c=sum(t*t/f for t,f in zip(z,w))
            de=prod(w)*((2-b)**2-a*c)/4
            if 2<=b or de<=0:return None
            if worst is None or de<worst:worst=de
        data.append(dict(vertices=len(cand),minimum=str(worst)))
    return data
if __name__=='__main__':
    out={}
    for d,u in [(F(5,16),F(1,8)),(F(3,10),F(3,10)),(F(5,16),F(5,16)),(F(2,5),F(2,5)),(F(7,20),F(1,4))]:
        out[f'{d}:{u}']=evaluate(14,d,u)
    print(out);(H/'frame-vertices.json').write_text(json.dumps(out,indent=2)+'\n')


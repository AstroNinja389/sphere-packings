"""Verified projected line code bound for a fixed endpoint of a short decomposition."""
from pathlib import Path
from fractions import Fraction as F
import json
H=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_bytes())
def spectral(proof,n):
    # Invert the normalized zonal polynomial recurrence directly, working in t.
    end=F(proof['end']);c=1-1/(2*end);P=list(map(F,proof['p']));sh=proof['shift'];deg=4*(len(P)-1)+2*sh+2
    co=[F(0)]*(deg+1)
    for i,v in enumerate(P):
        for j,w in enumerate(P):
            k=2*(i+j+sh);co[k]-=c*c*v*w;co[k+2]+=v*w
    B=[[F(1)],[F(0),F(1)]]
    for k in range(1,deg):
        u=[F(0)]+[a*F(2*k+n-2,k+n-2) for a in B[k]]
        for j,z in enumerate(B[k-1]):u[j]-=F(k,k+n-2)*z
        B.append(u)
    res=co.copy();g=[]
    for k in reversed(range(deg+1)):
        t=res[k]/B[k][k];g.append(t)
        for j,z in enumerate(B[k]):res[j]-=t*z
    assert not any(res) and min(g)>=0 and g[-1]>0 and proof['cap']==int(sum(co)//g[-1]);return c,proof['cap']
def polys():
    old=read(H.parent/'n13/prefix-polynomials.json');this=read(H/'prefix-polynomials.json')
    return [[spectral(p,n) for p in l] for n,l in [(13,old),(14,this)]]
def build(E,ss,codes):
    p13,p14=codes
    ls=[]
    for S in ss:
        assert 2<S<3 and S in E and S-1 in E
        cost=[]
        for i,a in enumerate(E[:-1]):
            if a>=S-1:cost.append(0);continue
            t=S-a;eta=(t-1)/2;c=1-1/(2*t);c2=(c+eta*eta)/(1-eta*eta)
            z=min([16383]+[k for h,k in p13 if h>=c2]+[k for h,k in p14 if h>=c])
            cost.append(z)
        ls.append(dict(S=str(S),limit=cost))
    return ls
def chosen(E):
    return [S for k in [1,2,3,4,6,8,10,12,16,20,24,27,30,36] if (S:=2+F(k,96)) in E and S-1 in E]
if __name__=='__main__':
    E=list(map(F,read(H/'frame-base-fourier.json')['E']));l=build(E,chosen(E),polys())
    (H/'incidence-rows-base.json').write_text(json.dumps(l));print([(r['S'],r['limit'][0]) for r in l])


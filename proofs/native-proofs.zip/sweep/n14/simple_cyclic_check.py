"""Second exhaustive proof with a single deterministic representative in each multiple."""
import numpy as np
from itertools import combinations_with_replacement,islice
from math import lcm,comb
from fractions import Fraction as F
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent
def verify(p,D):
    h=p//2;unit=lcm(*range(1,15));den=p*p*D.denominator*unit
    gen=combinations_with_replacement(range(h+1),14);worst=0;count=0;surv=0
    while block:=list(islice(gen,2048)):
        A=np.array(block,dtype=np.int64);A=A[(A!=0).any(axis=1)]
        if p==16:
            w=(A%2).sum(axis=1);A=A[(w>=8)&(w%2==0)]
        if not len(A):continue
        for e in ([0,1] if p==16 else [(A.sum(axis=1)%2)]):
            bound=np.full(len(A),2**60,dtype=np.int64)
            for k in range(1,h+1):
                b=(2*k*A+p)//(2*p);x=np.sort(abs(k*A-p*b),axis=1)
                t=x[:,-1];s=x[:,-2];c=(x==t[:,None]).sum(axis=1)
                ab=x.sum(axis=1);sq=(x*x).sum(axis=1)
                odd=((b.sum(axis=1)-k*e)%2)*(2*t!=p)
                # On odd parity choose the least-excess coordinate among the c equal maxima.
                coef=np.where(odd,(ab+p-2*t)*(c*s+p-t-s),ab*t*c)
                z=(sq+odd*(p-2*t))*D.denominator*c+coef*D.numerator
                bound=np.minimum(bound,z*(unit//c))
            worst=max(worst,int(bound.max()));count+=len(bound);surv+=int((bound>=2*den).sum())
    if p%2:assert count==comb(14+h,h)-1
    return dict(tested=count,worst=str(F(worst,den)),unresolved=surv)
if __name__=='__main__':
    D=F(sys.argv[1]);r={p:verify(p,D) for p in (5,16,17)};print(r)
    (H/f'cyclic-replay-{D.numerator}-{D.denominator}.json').write_text(json.dumps(r,indent=2)+'\n')


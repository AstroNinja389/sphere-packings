# Dimension fifteen. Thirteen distinct dual characters in a full parity frame

Normalize the lattice L to squared minimum one. Write D for the Gram determinant after scaling L to minimum four. Its density is V/√D, where V=256π⁷/2027025. Suppose D≤236. For any fifteen distinct opposite pairs in one parity class through squared length 83/32, we prove

\[
\sum_{i=1}^{15}(\|x_i\|^2-2)_+>1 .
\]

For sixteen pairs through the same cutoff the sum exceeds 3/2. The inputs for the fifteen-pair result are a frame-free dimension-fifteen bound 0.026301384263011 and the dimension-fourteen bound 0.034607876755962. The latter has a separate proof using finite residue calculations in the preceding slot. Neither input uses this new character sieve.

## From a frame to a character multiset

In Λ=√2 L the vectors fᵢ=xᵢ/√2 have Gram matrix Q. The combinations fᵢ±fⱼ belong to Λ. Thus with δᵢ=Qᵢᵢ−1, all δᵢ+δⱼ≥0 and |Qᵢⱼ|≤(δᵢ+δⱼ)/2 for i≠j. Write m=Σδᵢ⁺. Each positive δᵢ is at most 19/64. Assume m≤1/2. At most one δᵢ is negative. Order the absolute values increasingly, starting with the negative one when present. Form M by replacing the off-diagonal entries of Q by the negative of their allowed upper absolute values. Congruence by the inverse square root of the diagonal gives M in the form I−B with B≥0 entrywise. Positive definiteness makes its spectral radius less than one. The power series for the inverse and log determinant then give |Q⁻¹|≤M⁻¹ entrywise and det Q≥det M.

Each sign choice gives a sorted simplex clipped by the linear mass budget. Its vertices are the surviving ordered step vertices and the intersections of its edges with the budget hyperplane. Positive definiteness, lower bounds on determinant, and upper bounds on vᵀM⁻¹v extend from its vertices. For the determinant use log concavity, and for a dual norm use its Schur complement. The finite audit checks principal minors and det(M+vvᵀ)/det M for v=eᵢ,eᵢ+eⱼ among the **thirteen least excess coordinates**. These estimates apply to both signs in Q⁻¹. The audit gives det Q≥0.88128 and every tested dual norm squared below 2.53. This selective test permits the other two coordinates to have substantially larger distortion. Repeating just the positive-definiteness check for sixteen vectors and m≤3/4 contradicts rank fifteen.

Let Γ=D₁₅ in frame coordinates. It is contained in Λ and has index j. Hence D=2¹⁷ det Q/j². The frame-free bound gives a lower bound on D and Hadamard gives det Q≤(1+m/15)¹⁵. Together with D≤236 these imply 23≤j≤31. Every nonzero dual vector of Λ has squared norm at least 2A/D, with A=299. Indeed, its primitive perpendicular section has Gram determinant equal to the primitive dual norm squared times det Λ. At minimum four every rank-fourteen section has determinant exceeding A by the preceding slot. The conclusion also holds for multiples of primitive normals.

For G=Λ/Γ let χᵢ be the ith coordinate modulo one. If χᵢ were zero then eᵢ would give a dual vector of Λ in covector coordinates. Similarly χᵢ=±χⱼ gives eᵢ∓eⱼ. The norm upper bounds are strictly below 2A/236. Thus the first thirteen characters are nonzero and distinct up to sign. The last two characters are free.

## Exact finite character test

Let t be the number of order-dividing-two elements of the character group. It is a power of two dividing j and is one exactly when j is odd. There are (j+t)/2−1 nonzero characters up to sign. The audit considers every possible j,t admitting thirteen. In each case choose an odd prime p dividing j and an element g of order p. Evaluation on g is onto the group of pth roots of unity and all fibers have size j/p. Every order-dividing-two character evaluates trivially on g. Therefore, among *all* nonzero characters up to sign, the count with absolute residue zero is (j/p+t)/2−1 and the count at each absolute residue 1,…,(p−1)/2 is j/p. Choose any thirteen from this multiset and add two arbitrary residues. This is an outer enumeration, covering every physical group and common labeling. Sign changes and coordinate permutations preserve D₁₅ and the norm hypotheses. The auditor also checks one representative per orbit under replacing g by a generator of its subgroup.

For a resulting residue vector v with entries between 0 and (p−1)/2, a lift has coordinates v/p+z. Since p is odd and pg belongs to D₁₅, Σzᵢ≡Σvᵢ modulo two. For each multiple k=1,…,(p−1)/2 reduce kv modulo p to nearest signed residues. When the parity is wrong, change the rounding in one coordinate of maximal absolute residue, averaging over all ties. Each resulting vector divided by p really lies in the nonzero coset kg. If C is their averaged outer product in numerator coordinates, the mean squared length is at most

\[
p^{-2}\bigl(\operatorname{tr} C+\sum_i\delta_i^+\sum_j |C_{ij}|\bigr).
\]

Maximize the second term by assigning up to 19/64 per coordinate to the largest row sums until the budget 1/2 is spent. For every admissible pattern either a single multiple, or the uniform average over all these multiples, gives a strict upper bound below two. This contradicts the minimum of Λ. The direct auditor enumerates **12,877 raw patterns counted across nine group cases**, verifies the integer parity of every chosen representative and forms the Gram sums with exact integers. The discovery code computed tied averages using closed formulas.

## Integration with Poisson summation

The released 9/4 Schur kernel supplies a physical same-parity count inequality. The Fourier polynomial supplies a spatial upper envelope on each squared-length bin and a nonpositive tail. At most one opposite pair of a class lies below two. For the other bins, charge the upper endpoint excess rounded upward in fixed integer units. Apply the two inequalities above when the fifteenth and sixteenth slots are reached. This relaxation contains every physical class. Two independently oriented integer dynamic programs, one over prefix requirements and one over accumulated excess, agree on every branch maximum. Combine the resulting bound with V/√236 for the remaining determinants.

A second test uses the reciprocal-lattice gap explicitly. The primal lattice now has minimum one, so any nonzero reciprocal norm squared is at least 4A/D. For a Gaussian with spatial parameter τ the Laguerre argument on the reciprocal side is 4π² times that norm squared divided by τ. It is enough to prove transform positivity from any rational start below 16π²A/(Dτ), and to check the positive origin value separately. The restricted audit certifies the entire indicated half-line and every primal bin. Where it uses A=310 it invokes the separate rank-fourteen bound that depends on the external sharp rank-twelve theorem. The ordinary character proof above uses A=299.

The lower comparison is realized by a concrete lattice. Adjoin halves of the four simplex-code generators to D₁₅ and scale the section from squared minimum two to four. The independently reconstructed Gram matrix has determinant 512 and exact enumeration finds 2,340 vectors of squared length four and none shorter. The density is V/√512.

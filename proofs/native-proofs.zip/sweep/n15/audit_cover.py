from fractions import Fraction as F
from pathlib import Path
from itertools import product
import json
from audit_frame15 import section_matrices
H=Path(__file__).resolve().parent
m=F(3,8);eps=F(1,50);dmin,_,nodes=section_matrices(14,m,F(1,8),0);assert F(dmin)>=1
code=[[((t&b).bit_count()%2) for t in range(1,8) for j in range(2)] for b in range(8)]
assert all(sum(x[i] for x in code)==4 for i in range(14))
hole=[0,1]*7
assert all(sum(a^b for a,b in zip(x,hole))==7 for x in code)
upper=max((14+m)/8+F(25,8)*eps,F(13,8)*(1+eps)+F(9,16)*m,F(11,8)*(1+eps)+m)
assert 2048*(2-upper)>236
out=dict(status='PASS',reference_cover_squared='7/4',mass=str(m),offdiagonal_eigen_upper=str(eps),deformed_cover_squared=str(upper),ambient_det_lower=str(2048*(2-upper)),verified_vertices=nodes,det_lower=dmin,restricted_to_elementary_order8=True)
(H/'double-simplex-cover.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

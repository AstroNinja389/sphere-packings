"""Poisson audit for a lattice with a section-certified gap in its reciprocal lattice."""
from certify import *
import hashlib
from pathlib import Path
def audit(tag,start,D,A,section,scale):
    ctx.prec=192;s=H.parent/'n14'/section;v14=arb.pi()**7/5040
    p=json.loads(s.read_bytes());bes=F(p.get('final_rational',p.get('final_bound')))
    assert (v14/arb(fmpq(str(bes))))**2>A
    gg=json.loads((H/'character-audit.json').read_bytes());assert D<=gg['D']
    b=pr.bundle(tag);data=json.loads(b.read_bytes());E=list(map(F,data['E']));assert E[-1]<=2+2*F(gg['individual'])
    vb=st.vb
    def obligations(c,p,q):
        assert c.n==15 and q[0]>0
        assert 16*arb.pi()**2*A/(D*arb(fmpq(str(c.tau0))))>arb(fmpq(str(start)))
        vb.prove_bernstein(vb.integer_halfline_bernstein(q,start),strict=True,label='dual transform on all nonzero reciprocal lengths')
        neg=vb.poly_scale(p,F(-1));xs=[v*c.tau0 for v in c.E]
        vb.prove_bernstein(vb.integer_halfline_bernstein(neg,xs[-1]),strict=True,label='spatial tail')
        for i,(l,r,y) in enumerate(zip(xs,xs[1:],c.Gam)):
            env=[y*(1-l/2+l*l/8),y*(F(1,2)-l/4),y/8]
            vb.prove_bernstein(vb.integer_interval_bernstein(vb.poly_add(env,neg),l,r),strict=False,label='spatial upper '+str(i))
    vb.prove_polynomial_obligations=obligations
    ans=[];dep={}
    for way in ('back','front'):
        st.backward=Verifier(E,{15:F(1),16:F(3,2)},scale,way).callback
        file=H/f'{tag}-restricted-{way}-{scale}.json';res=st.audit(b,file);ans.append(res);dep[file.name]=sha(file)
        for f,h in res['dependencies'].items():assert sha(H/f)==h
    for k in ('rho','density','integer_branch_maxima','class_budget_scaled'):assert ans[0][k]==ans[1][k]
    threshold=256*arb.pi()**7/(2027025*arb(D).sqrt());u=int(float(threshold)*10**15)+1
    assert threshold<arb(fmpq(u,10**15));fin=max(F(u,10**15),F(ans[0]['density']))
    getcontext().prec=65;obj=dict(status='PASS',dimension=15,final_bound=str(Decimal(fin.numerator)/Decimal(fin.denominator)),fourier=ans[0]['density'],complement=str(F(u,10**15)),D=D,A14=A,dual_start=str(start),section=section,section_sha=sha(s),geometry_sha=sha(H/'character-audit.json'),audits=dep,scale=scale)
    (H/f'{tag}-restricted-{scale}-union.json').write_text(json.dumps(obj,indent=2)+'\n');print('UNION',obj['final_bound'])
if __name__=='__main__':
    sys.set_int_max_str_digits(0);audit(sys.argv[1],F(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]),sys.argv[5],int(sys.argv[6]))

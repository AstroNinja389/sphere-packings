"""Independent finite frame audit using Gram sums of genuine coset representatives."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from math import lcm
from flint import arb,fmpq as Rat,fmpq_mat as Mat,ctx
import numpy as np,json,hashlib
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def section_matrices(n,m,cap,regular):
    # Triangulate first by sign of the first diagonal and then intersect every simplex edge with the budget.
    pts=set()
    for sign in (1,-1):
        verts=[tuple((sign if k==0 else 1)*cap if k>=j else F(0) for k in range(n)) for j in range(n+1)]
        for z in verts:
            if sum(max(q,0) for q in z)<=m:pts.add(z)
        for u,v in combinations(verts,2):
            a=sum(max(q,0) for q in u);b=sum(max(q,0) for q in v)
            if min(a,b)<m<max(a,b):
                t=(m-a)/(b-a);pts.add(tuple(s+t*(r-s) for s,r in zip(u,v)))
    worst=F(0);detlo=None
    for z in pts:
        A=Mat([[Rat(str(1+u if i==j else -(u+v)/2)) for j,v in enumerate(z)] for i,u in enumerate(z)])
        for k in range(1,n+1):assert Mat([[A[i,j] for j in range(k)] for i in range(k)]).det()>0
        det=A.det();d=F(str(det));detlo=d if detlo is None else min(detlo,d)
        # Matrix determinant lemma without inverting the matrix. Coordinates equal within each level.
        groups={}
        for i,q in enumerate(z[:regular]):groups.setdefault(q,[]).append(i)
        indices=[i for v in groups.values() for i in v[:2]]
        for count in (1,2):
            for chosen in combinations(indices,count):
                T=Mat(A)
                for i in chosen:
                    for j in chosen:T[i,j]+=1
                bound=F(str(T.det()/det-1));worst=max(worst,bound)
    return str(detlo),str(worst),len(pts)
def all_patterns(j,t,p,g):
    # Directly delete characters without replacement from the complete list, then append arbitrary coordinates.
    h=p//2; labels=[0]*((j//p+t)//2-1)+[i for i in range(1,h+1) for a in range(j//p)]
    seen=set()
    for selected in combinations(range(len(labels)),g):
        base=tuple(labels[i] for i in selected)
        for tail in combinations_with_replacement(range(h+1),15-g):
            seen.add(tuple(sorted(base+tail)))
    return seen
def verify_residues(v,p,m,cap):
    sums=[];totals=[];eta=sum(v)%2
    for k in range(1,1+p//2):
        b=[(2*k*x+p)//(2*p) for x in v];y=[k*x-p*a for x,a in zip(v,b)]
        if (sum(b)-k*eta)%2:
            choices=[];T=max(map(abs,y));assert T>0
            for i,x in enumerate(y):
                if abs(x)!=T:continue
                row=y.copy();row[i]-=p if x>0 else -p;choices.append(row)
        else:choices=[y]
        for row in choices:
            shift=[(k*x-y)//p for x,y in zip(v,row)];assert all(k*x-y==p*z for x,y,z in zip(v,row,shift)) and (sum(shift)-k*eta)%2==0
        rows=np.array(choices,dtype=np.int64);M=rows.T@rows;h=len(choices);sums.append(M);totals.append(h)
        if test(M,h,p,m,cap):return True
    d=lcm(*totals);return test(sum((d//h)*M for M,h in zip(sums,totals)),d*len(sums),p,m,cap)
def test(M,h,p,m,cap):
    cost=sorted((int(sum(abs(q) for q in row)) for row in M.tolist()),reverse=True)
    used=F(0);z=F(int(M.trace()))
    for a in cost:
        power=min(cap,m-used);z+=power*a;used+=power
    return z<2*h*p*p
def main(m,cap,g,J,limit,name,ordinary='control-audit.json',A=299,section='frame-fine-forward.json'):
    ctx.prec=170;d=H.parent/'n14';prior=read(d/section);v14=arb.pi()**7/5040
    ds=F(prior.get('final_rational',prior.get('final_bound')));assert (v14/arb(Rat(str(ds))))**2>A
    broad=read(H/ordinary);V=256*arb.pi()**7/2027025
    assert broad['status'].startswith('PASS')
    # If D<=limit, Hadamard plus the ordinary density bound gives j<=J.
    b=F(broad['final_bound']);assert 2**17*arb(Rat(str((1+m/15)**15)))*(arb(Rat(str(b)))/V)**2<(J+1)**2
    lo,up,n=section_matrices(15,m,cap,g);assert F(up)*limit<2*A
    floor=1
    while (floor**2)*limit<2**17*F(lo):floor+=1
    cases=[]
    for j in range(floor,J+1):
        for t in (1,2,4,8,16,32):
            if j%t or (j%2==0)!=(t>1) or (j+t)//2-1<g:continue
            # Even without an elementary-rank bound, groups of order 24 can have at most eight involutions.
            p=next(q for q in (5,3,7,11,13,17,19,23,29,31) if j%q==0)
            patterns=all_patterns(j,t,p,g);remaining=set(patterns);tested=0
            while remaining:
                v=min(remaining)
                assert verify_residues(v,p,m,cap),(j,t,p,v)
                orbit={tuple(sorted(min(k*x%p,(-k*x)%p) for x in v)) for k in range(1,p)}
                remaining-=orbit;tested+=1
            cases.append(dict(j=j,t=t,p=p,raw_patterns=len(patterns),orbits=tested))
    v16=section_matrices(16,F(3,4),cap,0);assert F(v16[0])>0
    out=dict(status='PASS',dimension=15,mass=str(m),individual=str(cap),good=g,D=limit,A14=A,minimum_index=floor,maximum_index=J,det_lower=lo,dual_upper=up,vertices=n,rank16_vertices=v16,cases=cases,ordinary=ordinary,ordinary_sha=sha(H/ordinary),rank14=section,rank14_sha=sha(d/section))
    (H/(name+'.json')).write_text(json.dumps(out,indent=2)+'\n');print('PASS',m,g,J,limit,floor,len(cases),sum(r['raw_patterns'] for r in cases))
if __name__=='__main__':
    import sys
    if len(sys.argv)==1:main(F(1,2),F(19,64),13,31,236,'character-audit')
    else:main(F(sys.argv[1]),F(sys.argv[2]),*map(int,sys.argv[3:6]),sys.argv[6],*sys.argv[7:8],*(list(map(int,sys.argv[8:9]))),*sys.argv[9:10])

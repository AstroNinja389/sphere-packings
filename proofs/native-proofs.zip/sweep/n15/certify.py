"""Bind the certified geometry and compare two integer DPs, lattice class by class."""
from integer_dp import *
from decimal import Decimal,getcontext
import hashlib
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(tag,geometry,scale):
    cert=H/(geometry+'.json');a=json.loads(cert.read_bytes());assert a['status']=='PASS'
    B=pr.bundle(tag);b=json.loads(B.read_bytes());assert 'frame' not in b and 'floor' not in b
    E=list(map(F,b['E']));assert E[-1]<=2+2*F(a['individual'])
    assert sha(H/a['ordinary'])==a['ordinary_sha'] and sha(H.parent/'n14'/a['rank14'])==a['rank14_sha']
    needs={15:2*F(a['mass']),16:F(3,2)};ans=[]
    for direction in ('back','front'):
        checker=Verifier(E,needs,scale,direction);st.backward=checker.callback
        out=H/f'{tag}-{geometry}-{scale}-{direction}.json';result=st.audit(B,out);ans.append(result)
    assert all(ans[0][k]==ans[1][k] for k in ['integer_branch_maxima','rho','density','class_budget_scaled','dependencies'] if k!='dependencies')
    for r in ans:
        for f,h in r['dependencies'].items():assert sha(H/f)==h
    ctx.prec=180;V=256*arb.pi()**7/2027025;q=V/arb(a['D']).sqrt();u=int(float(q)*10**15)+1
    assert q<arb(fmpq(u,10**15));final=max(F(u,10**15),F(ans[0]['density']))
    getcontext().prec=65;display=str(Decimal(final.numerator)/Decimal(final.denominator))
    s=dict(status='PASS',dimension=15,final_bound=display,geometry=cert.name,geometry_sha=sha(cert),complement=str(F(u,10**15)),fourier=ans[0]['density'],directions=['back','front'],cases=len(ans[0]['integer_branch_maxima']),scale=scale,ceil_excesses={str(k):str(y) for k,y in needs.items()},audits={f'{tag}-{geometry}-{scale}-{direction}.json':sha(H/f'{tag}-{geometry}-{scale}-{direction}.json') for direction in ('back','front')})
    (H/f'{tag}-{geometry}-{scale}-union.json').write_text(json.dumps(s,indent=2)+'\n');print('UNION',display,flush=True)
if __name__=='__main__':sys.set_int_max_str_digits(0);main(sys.argv[1],sys.argv[2],int(sys.argv[3]))

"""Explore all multisets of characters restricted to one prime order element."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import comb,gcd
from pathlib import Path
import sys,json
from glue_patterns import representative
H=Path(__file__).resolve().parent
def patterns(j,t,p,g):
    h=p//2;cnt=[(j//p+t)//2-1]+[j//p]*h
    assert sum(cnt)==(j+t)//2-1
    omit=sum(cnt)-g
    if omit<0:return
    seen=set()
    for rem in combinations_with_replacement(range(h+1),omit):
        v=cnt.copy()
        for b in rem:v[b]-=1
        if min(v)<0:continue
        for ext in combinations_with_replacement(range(h+1),15-g):
            w=v.copy()
            for b in ext:w[b]+=1
            key=tuple(w)
            if key in seen:continue
            for k in range(1,h+1):seen.add(tuple(w[min((i*k)%p,(-i*k)%p)] for i in range(h+1)))
            yield tuple(i for i,num in enumerate(w) for _ in range(num))
def row_cert(v,p,m,cap):
    import numpy as np
    v=np.array(v,dtype=int);eta=int(v.sum()%2);ms=[];cost=[];h=p//2
    for k in range(1,h+1):
        w=k*v;b=(2*w+p)//(2*p);x=w-p*b
        t=int(max(abs(x)));ind=np.flatnonzero(abs(x)==t);C=np.outer(x,x)
        f=len(ind)
        if (b.sum()-k*eta)%2:
            s=np.zeros(15,dtype=int);s[ind]=np.where(x[ind]>0,1,-1)
            C=C*f-p*(np.outer(s,x)+np.outer(x,s))+p*p*np.diag(abs(s))
        else:f=1
        ms.append((C,f))
    def bounded(C,den):
        rows=sorted(np.abs(C).sum(axis=1).tolist(),reverse=True)
        n=int(m//cap);rem=m-n*cap
        return (int(C.trace())+cap*sum(rows[:n])+rem*rows[n])/(den*p*p)
    best=F(100)
    for C,f in ms:
        q=bounded(C,f);best=min(best,q)
        if q<2:return q
    from math import lcm
    den=lcm(*(f for C,f in ms));z=sum(C*(den//f) for C,f in ms)
    return min(best,bounded(z,den*len(ms)))
def run(m,cap,g,lo,hi):
    cases=[]
    for j in range(lo,hi+1):
        for t in [1,2,4,8,16]:
            if j%t or (j%2==0)!=(t>1) or (j+t)//2-1<g:continue
            p=next((q for q in (3,5,7,11,13,17,19,23,29,31) if j%q==0),None)
            if not p:cases.append(dict(j=j,t=t,p=p,open='binary group'));continue
            count=0;worst=F(0);bad=[]
            for v in patterns(j,t,p,g):
                if max(v)==0:raise ValueError('trivial evaluation')
                best=row_cert(v,p,m,cap);count+=1;worst=max(worst,best)
                if best>=2:bad.append([v,str(best)])
            cases.append(dict(j=j,t=t,p=p,checked=count,worst=str(worst),bad=bad))
            print(j,t,p,count,round(float(worst),6),len(bad),flush=True)
    return cases
if __name__=='__main__':
    m,c,g,lo,hi=F(sys.argv[1]),F(sys.argv[2]),*map(int,sys.argv[3:6]);o=run(m,c,g,lo,hi)
    (H/f'char-{m.numerator}-{m.denominator}-{g}.json').write_text(json.dumps(o,indent=2)+'\n')

"""Exact norm bounds from actual translates of multiples of a marked coset."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import gcd
from collections import Counter
import sys,json
from pathlib import Path
H=Path(__file__).resolve().parent
def representative(v,p,k,eta):
    n=len(v); w=[k*t for t in v];b=[(2*t+p)//(2*p) for t in w]
    x=[t-p*s for t,s in zip(w,b)]
    parity=(sum(b)-k*eta)%2
    hv=[i for i,z in enumerate(x) if 2*abs(z)==p]
    absx=list(map(abs,x))
    # Return E||v||^2, max_i sum_j |E(v_i v_j)|, prior to dividing by p^2.
    if hv:
        h=len(hv); low=[a for a in absx if 2*a!=p]
        if h>=3: cost=max((p//2)**2,max(low,default=0)*sum(low))
        elif h==2:cost=max(2*(p//2)**2,max(low,default=0)*sum(low))
        else:cost=max(absx)*sum(absx)
        return sum(z*z for z in x),F(cost)
    if not parity:return sum(z*z for z in x),F(max(absx)*sum(absx))
    top=max(absx);c=absx.count(top);other=[v for v in absx if v<top]
    # Flip one uniformly random maximal coordinate across the nearest rounding wall.
    high=F(c*top**2+p*p-2*p*top+(c-1)*abs(c*top**2-2*p*top)+abs(c*top-p)*sum(other),c)
    small=F(max(other,default=0))*(sum(other)+abs(F(c*top-p,c)))
    return sum(z*z for z in x)+p*p-2*p*top,max(high,small)
def run(n,p,m):
    count=0;worst=F(0);surv=[]
    for t in combinations_with_replacement(range(p//2+1),n):
        if gcd(p,*t)!=1:continue
        if p%2==0 and (sum(a%2 for a in t) not in (8,10,12,14)):continue
        for eta in ([sum(t)%2] if p%2 else [0,1]):
            best=min((s+m*b)/(p*p) for s,b in (representative(t,p,k,eta) for k in range(1,p//2+1)))
            count+=1;worst=max(worst,best)
            if best>=2:surv.append((dict(Counter(t)),eta,str(best)))
    return dict(n=n,p=p,m=str(m),tested=count,worst=str(worst),survivors=surv)
if __name__=='__main__':
    m=F(sys.argv[1]);n=int(sys.argv[2])
    for p in map(int,sys.argv[3:]):
        r=run(n,p,m);(H/f'glue-{n}-{p}-{m.numerator}-{m.denominator}.json').write_text(json.dumps(r,indent=2)+'\n');print(n,p,m,r['tested'],r['worst'],len(r['survivors']),r['survivors'][:3])

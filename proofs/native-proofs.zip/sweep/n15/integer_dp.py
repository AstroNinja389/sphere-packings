"""Two independent integer class DPs for first-k length sums, sharing the public Fourier sign checker."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import os,sys,json
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import numpy as np
import public_replay as pr
from public_replay import H,R
from flint import arb,ctx,fmpq
import audit_frame_bound as st
def ceil(q):return -((-q.numerator)//q.denominator)
class Verifier:
    def __init__(self,E,needs,scale,direction):
        self.J=E.index(2);self.bins=[ceil((v-2)*scale) for v in E[self.J+1:]];self.needs={k:ceil(v*scale) for k,v in needs.items()};self.R=max(self.needs.values());self.direction=direction;self.summary=[]
    def callback(self,W,pen,cap,off,J,*args):
        assert not args and J==self.J
        val=self.compute(tuple(W[J:]),tuple(pen),tuple(cap),off)
        self.summary.append(val);return val
    @lru_cache(None)
    def compute(self,W,pen,cap,off):
        R=self.R;rs=np.arange(R+1);g=cap[-1]
        mag=(g+1)*max(map(abs,W))+(g+1)**2*sum(map(abs,pen))
        dtype=np.int64 if mag<2**59 else object
        neg=-(1<<61) if dtype==np.int64 else -2**200
        if self.direction=='back':
            nxt=np.zeros((g+1,R+1),dtype=dtype)
            for i in range(len(cap)-1,-1,-1):
                w=W[i];p=pen[i];inc=self.bins[i];dest=np.minimum(rs+inc,R)
                f=nxt.copy()
                for k in range(cap[i],-1,-1):
                    f[k]=nxt[k]-p*(k+off)*(k+off-1)
                    if k==cap[i]:continue
                    good=dest>=self.needs.get(k+off+1,0)
                    f[k,good]=np.maximum(f[k,good],w+f[k+1,dest[good]])
                nxt=f
            return int(nxt[0,0])
        f=np.full((g+1,R+1),neg,dtype=dtype);f[0,0]=0
        for i in range(len(cap)):
            # Entries [k,r] are the best valid prefixes already attaining at least r mass.
            z=f.copy();u=self.bins[i]
            for k in range(1,cap[i]+1):
                demand=np.maximum(rs,self.needs.get(k+off,0))
                z[k]=np.maximum(f[k,demand],z[k-1,np.maximum(0,demand-u)]+W[i])
            for k in range(cap[i]+1):z[k]-=pen[i]*(k+off)*(k+off-1)
            f=z
        return int(np.max(f[:,0]))

"""Directional bounds after ignoring a specified number of largest excess coordinates."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from flint import fmpq,fmpq_mat as Mat
import sys,json
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'n14'))
from codim_one import vertices
def verify(m,cap,n=15):
    lower=None;largest=[F(0)]*6;least=[]
    for z in set(vertices(n,m,cap)):
        M=Mat([[fmpq(str(1+a if i==j else -(a+b)/2)) for j,b in enumerate(z)] for i,a in enumerate(z)])
        for k in range(1,n+1):assert Mat([[M[i,j] for j in range(k)] for i in range(k)]).det()>0
        D=F(str(M.det()));lower=D if lower is None else min(lower,D);A=M.inv()
        for e in range(6):
            idx=range(n-e)
            mx=max(A[i,i]+A[j,j]+2*A[i,j] for i,j in combinations(idx,2))
            largest[e]=max(largest[e],F(str(mx)))
    return lower,largest
if __name__=='__main__':
    for t in sys.argv[1:]:
        try:
            m=F(t);D,b=verify(m,F(19,64));print(t,float(D),[round(float(v),4) for v in b],flush=True)
        except AssertionError:print('singular',t)

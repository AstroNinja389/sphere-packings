from pathlib import Path
from sympy.matrices.normalforms import hermite_normal_form
import sympy as s,sys,json
from fractions import Fraction as F
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'n13'))
from geometry import enum
def run():
    rows=[]
    for i in range(14):
        v=[0]*15;v[i]=2;v[i+1]=-2;rows.append(v)
    rows.append([0]*13+[2,2]);rows.extend([[(j>>bit)&1 for j in range(1,16)] for bit in range(4)])
    T=hermite_normal_form(s.Matrix(rows).T)/2;G=2*T.T*T
    assert G.det()==512 and all(x.is_Integer for x in G)
    pts=enum(G,4);assert set(q for q,v in pts)=={F(4)} and len(pts)==1170
    (H/'named-witness.json').write_text(json.dumps(dict(status='PASS',gram=G.tolist(),det=512,min_squared=4,kissing=2340),default=int,indent=2)+'\n')
if __name__=='__main__':run()

# A parity frame in dimension 17

Scale a rank-seventeen lattice L to squared minimum one and let D be its Gram determinant after rescaling to squared minimum four. Its density is V/√D, where V=512π⁸/34459425. Suppose D≤112. If seventeen distinct opposite pairs in one parity class have squared lengths at most 83/32, then the sum of their positive squared-length excesses above two is **strictly greater than 1/2**. For eighteen such pairs the sum exceeds 3/2, without a determinant restriction.

## Lattice and determinant inputs

Set Λ=√2 L and fᵢ=xᵢ/√2. The sums and differences fᵢ±fⱼ belong to Λ, whose minimum squared length is two. The Gram matrix Q has diagonal 1+δᵢ, with |Qᵢⱼ|≤(δᵢ+δⱼ)/2 and δᵢ+δⱼ≥0. Put m=Σδᵢ⁺. The individual upper bound is 19/64. Suppose first that m≤1/4.

Set all off-diagonals to the negative of the allowed absolute values to obtain M. Once M is positive definite, normalization by its diagonal and the geometric series for the inverse imply |Q⁻¹|≤M⁻¹ entrywise. The trace series for log determinant gives det Q≥det M. Sort the absolute excesses and choose the negative sign on the first coordinate if needed. The possible points lie in two ordered simplices clipped by the mass hyperplane. On their vertices check positive principal minors, the lower bound on det M and the upper bounds on vᵀM⁻¹v for coordinate unit vectors and sums of two. They extend by convexity of the positive cone, log concavity of determinant and the Schur complement. Two implementations use inversion and determinant increments respectively. They give det Q≥1 and squared dual norms at most 145/64 for these single coordinates and both signs of every coordinate pair. In eighteen coordinates and m≤3/4 the minimum determinant at the vertices is 33507/524288>0, contrary to ambient rank seventeen.

Let j be the index of the even-coordinate-sum lattice Γ=D₁₇ in Λ in frame coordinates. Then D=2¹⁹ det Q/j². Hadamard gives det Q≤(1+m/17)¹⁷. The frame-free certificate using only the eighteen-pair rule gives density at most 0.013815088971739. In combination with D≤112 these estimates put j between 69 and 80 inclusive.

Every nonzero dual normal of Λ has squared norm at least 2A/D with A=158. The covolume of the perpendicular section of a primitive normal equals the ambient covolume times the normal's length. The rank-sixteen Fourier replay gives density at most 0.018713631194121, implying minimum-four determinant greater than 158 for every such section. Since 2A/112>145/64, the seventeen coordinate characters of G=Λ/Γ are nonzero and pairwise distinct up to sign. An integral nonzero element of G would have a unit coordinate representative of norm below two. Hence reduction from G to the coordinate torus is injective.

## Complete index sieve

For an element g of odd order p a generator representative can be written as v/p+z with integer z. After independent coordinate sign changes take vᵢ in {0,…,(p−1)/2}. Since pg belongs to D₁₇, the parity of Σzᵢ is the parity of Σvᵢ. For each nonzero multiple round its coordinates independently to nearest integers. When the parity is wrong, flip one coordinate of maximal absolute residual and average over ties. All resulting points are in that actual coset. If C is the averaged outer product of numerator vectors, its averaged squared length is at most

\[
 \bigl(\operatorname{tr} C+m\max_i \sum_j |C_{ij}|\bigr)/p^2 .
\]

For even order, test both integral lift parities. Half-coordinate ties permit averaging over all compatible signs. Whenever there are at least three ties the signs are pairwise independent. An involution has nonzero even binary support of size at least eight. A support of four or six has mean norm at most (w+m)/4 under compatible sign choices, and the two-coordinate case follows from the entry bounds directly.

| Index | Obstruction |
|---|---|
| 69, 74, 76 | An element of prime order 23, 37, 19 respectively |
| 70, 77 | Order seven |
| 71, 73, 79 | Prime-order averaging proved below |
| 72 | Order nine or two independent elements of order three |
| 75, 78, 80 | Orders fifteen, thirteen and ten respectively |

For 7, 9, 13 and 15 the two programs enumerate all sorted primitive residue multisets and find a short coset representative for each. For ten, a separate replay checks every surviving order-five configuration translated by every possible binary support histogram. For an element of order three at least fifteen coordinates must be nonzero. Two independent ternary elements would require 8·15 incidences on the eight nonzero words, whereas each coordinate contributes at most six, so there are at most 17·6.

For prime p dividing j, evaluation on g maps the character group onto the pth roots, with fibers of size j/p. If the number of self-inverse characters is t, only (j/p+t)/2−1 nonzero sign classes evaluate trivially and at most j/p evaluate to any nonzero unsigned residue. In the three composite-index cases t is at most 1, 2 and 4 respectively. Multiplication by a unit modulo p lets us place a maximum-multiplicity nonzero residue at 1. Two independent enumerations, by counts and by coordinate lists, resolve respectively 216,447, 23,107,641 and 115,498 cases. The returned counts include equivalent patterns in ties, which does not affect coverage.

## The three large primes

For j=p the seventeen residues are distinct and nonzero up to sign. For a nonzero multiple of g write rᵢ for its nearest signed fractional residual. Mark coordinates with |p rᵢ|≥u, using u=25,25,27 for p=71,73,79 respectively. If there are at most two marked coordinates, sort their absolute residues and fix the largest one. In each low and high block successive integers differ by at least one. Subtract the consecutive-integer staircase to obtain an ordered simplex. Its vertices are the packed low and high endpoints. For each such product of simplices the auditor checks ordinary nearest rounding and exhibits a single parity-repair policy that works at every vertex. That policy flips uniformly among the largest k indices for one fixed k. Its mean squared norm for every actual positive metric is convex in the coordinate vector, so vertex checks suffice.

With at least three marked coordinates choose their upper and lower representatives with fair signs subject to the single required parity. Their mean residual is v(r)=r−sign(r)/2 on the marked positions and r elsewhere. The covariance of the rounding is diagonal, with entry 1/4 on each marked position. If any nonzero multiple has at most two marks the preceding paragraph already gives a contradiction. Otherwise this construction works on every nonzero multiple. The average of v(rᵢ)v(rⱼ) over the multiples is a cyclic correlation. In any row, its absolute row sum is bounded by the seventeen largest absolute correlations for distinct unsigned residues. Every coordinate is marked on the same fraction of the multiples. The direct rational replay checks that the resulting upper bound on average squared length is less than two for each prime. Thus one actual nonzero coset would contain a vector shorter than the minimum.

## Density certificate

In a nonzero parity class there is at most one pair below squared length two. Use the Schur kernel with its actual individual length dependence and the radial Fourier polynomial. For each remaining pair charge the upper endpoint's excess rounded upward. The integer programs impose the two proved prefix conditions and bound every physical class. Independent forward and backward recurrences agree on every integer branch maximum and on the rational Fourier ratio. The union takes the maximum with V/√112. All source kernels and Fourier half-lines are checked from their coefficients. The large older dimension-seventeen hybrid tables and the dimension-sixteen record-bound branch premises are unnecessary for this proof.

The additional mixed-length test uses all unit lines of each prefix of size k. For 2≤a,b≤83/32 one has (a+b−4)²/(4ab)≤((1−2/a)²+(1−2/b)²)/2 by expansion and ab≤8. A short anchor can use upper length two for this cosine estimate. Applying trace Cauchy–Schwarz to the sum of the rank-one projectors gives Σ(1−2/a)²≥k(k−17)/(17(k−1)). On the interval the summand is at most (a−2)(83/32−2)/(83/32)². This gives the optional extra prefix floors. The core certificate needs only the two frame restrictions.

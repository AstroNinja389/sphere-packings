from integer_dp import *
from pathlib import Path
from decimal import Decimal
import hashlib
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def volume():return 512*arb.pi()**8/34459425
def run(tag,mode,scale):
    geometry=read(H/'geometric-input.json');assert geometry['rank18_positive']
    B=pr.bundle(tag);b=read(B);assert not b.get('frame') and not b.get('floor');E=list(map(F,b['E']));assert E[-1]<=F(83,32)
    needs={18:F(3,2)};ctx.prec=150;comp=F(0)
    if mode in ('published','extended'):
        needs[17]=F(11,25) if mode=='published' else F(1,2)
        h=H.parents[1]/'n12-23-frame-floor-20261118'
        assert sha(h/'FRAME-PREMISE-n17-v1.txt')==sha(pr.src/'FRAME-PREMISE-n17-v1.txt')
        if mode=='extended':assert read(H/'order80.json')['status']=='PASS'
        comp=F('0.012461087091')
        assert 64*volume()/arb(2)**(arb(19)/2)<arb(fmpq(str(comp)))
    if mode in ('cyclic','mixed'):
        c=read(H/'new-frame.json');assert c['status']=='PASS' and c['edge']==str(E[-1]);needs[17]=F(c['floor']);comp=F(c['complement'])
        if mode=='mixed':
            from mr import floors
            assert E[-1]**2<8 and E[-1]<4
            for k,v in floors(E[-1]).items():
                if k>18:assert v*(E[-1]-2)/E[-1]**2==F(k*(k-17),17*(k-1))
                needs[k]=v
    ans=[];digs={}
    for way in ('back','front'):
        vd=Verifier(E,needs,scale,way)
        if mode in ('published','extended'):
            # Reuse DP on short prefix and suffix with bin-dependent rank requirements.
            import varying
            vd=varying.Bins(E,needs,scale,way,17,F(9,4))
        st.backward=vd.callback
        p=H/f'{tag}-{mode}-{way}-{scale}.json';v=st.audit(B,p);ans.append(v);digs[p.name]=sha(p)
        for f,h in v['dependencies'].items():assert sha(H/f)==h
    for k in ('rho','class_budget_scaled','integer_branch_maxima','density'):assert ans[0][k]==ans[1][k]
    final=max(comp,F(ans[0]['density']));out=dict(status='PASS',mode=mode,final_bound=str(Decimal(final.numerator)/Decimal(final.denominator)),complement=str(comp),fourier=ans[0]['density'],cases=len(ans[0]['integer_branch_maxima']),audits=digs,geometry=sha(H/'geometric-input.json'),original_hybrid_assumed=mode in ('published','extended'))
    (H/f'{tag}-{mode}-{scale}-union.json').write_text(json.dumps(out,indent=2)+'\n');print(mode,out['final_bound'])
if __name__=='__main__':sys.set_int_max_str_digits(0);run(sys.argv[1],sys.argv[2],int(sys.argv[3]))

"""Reconstruct spectral and finite character evidence for the entire interval of indices."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations,product
import hashlib,sys,json,math
from flint import arb,fmpq,ctx
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'n15'))
from audit_frame15 import section_matrices
from regular import verify
def read(p):return json.loads((H/p).read_bytes())
def sha(p):return hashlib.sha256((H/p).read_bytes()).hexdigest()
def prime(p,u):
    # Independent inverse-free audit using unscaled rational cyclic correlations and integer Gram sums.
    n=17;h=p//2;m=F(1,4);worst=F(0)
    def steps(count,lo,hi):
        if not count:return [()]
        if hi-lo+1<count:return []
        return [tuple(range(lo,lo+j))+tuple(range(hi-count+j+1,hi+1)) for j in range(count+1)]
    for count in (0,1,2):
        for t in (range(17,u) if count==0 else range(u,h+1)):
            corners=[v+w+(t,) for v in steps(17-count if count else 16,1,u-1 if count else t-1) for w in (steps(count-1,u,t-1) if count else [()])]
            def cost(v,inds):
                # Bound the maximal row of the mean outer product. Use a fixed flip policy on the entire simplex.
                k=len(inds) or 1
                sq=k*sum(q*q for q in v)+sum(p*p-2*p*v[i] for i in inds)
                r=max(sum(abs(k*x*y-p*(int(i in inds)*y+int(j in inds)*x)+p*p*(i==j and i in inds)) for j,y in enumerate(v)) for i,x in enumerate(v))
                return (sq+m*r)/(p*p*k)
            if not corners:continue
            # Try one policy after another; it must work at every vertex of this common simplex.
            assert all(cost(v,())<2 for v in corners)
            for k in (1,2,3,4,5,8,12,17):
                inds=frozenset(range(17-k,17));value=max(cost(v,inds) for v in corners)
                if value<2:break
            assert value<2;worst=max(worst,value)
    def centered(a):
        r=a%p;r=r if 2*r<p else r-p
        return F(r,p)-(F(1,2)*(1 if r>0 else -1) if abs(r)>=u else 0)
    corr=[sum(centered(k)*centered(k*a) for k in range(1,p))/(p-1) for a in range(1,h+1)]
    hi=F(h-u+1,h);z=17*(corr[0]+hi/4)+m*(sum(sorted(map(abs,corr),reverse=True)[:17])+hi/4)
    assert z<2
    return dict(p=p,u=u,exceptional_upper=str(worst),mean_upper=str(z))
def main():
    ctx.prec=160;m=F(1,4);cap=F(19,64);D=112
    lo,b,verts=section_matrices(17,m,cap,17);L,V=verify(m,cap,17);assert str(L)==lo and str(V[0])==b
    vul=read('universal-plain-192-union.json');rank=read('rank16/independent.json')
    V17=512*arb.pi()**8/34459425;A=158
    assert (arb.pi()**8/40320/arb(fmpq(str(F(rank['density'])))))**2>A and F(b)*D<2*A
    assert 68**2*D<2**19*F(lo) and 2**19*arb(fmpq(str((1+m/17)**17)))*(arb(fmpq(str(F(vul['final_bound']))))/V17)**2<81**2
    small={7,9,13,15}
    deps=['geometric-input.json','universal-plain-192-union.json','rank16/independent.json']
    for p in small:
        first=f'sieve-{p}-1-4.json';second=f'small-replay-{p}.json';v,w=read(first),read(second)
        assert v['bad']==w['unresolved']==0 and v['tested']==w['enumerated']>0;deps.extend([first,second])
    assert read('sieve-10-1-4.json')['bad']==0 and not any(read('small-5-1-4.json')['mixed'].values());deps+=['sieve-10-1-4.json','small-5-1-4.json']
    assert all(q[1]>=15 for q in read('small-3-1-4.json')['pure']) and 8*15>6*17;deps.append('small-3-1-4.json')
    counts={}
    for p,cap,zcap in [(19,4,3),(23,3,1),(37,2,1)]:
        x,y=f'prime-{p}-1-4.json',f'replay-{p}-1-4.json';v,w=read(x),read(y);assert (v['cap'],v['zero_cap'])==(cap,zcap)
        assert v['unresolved']==w['unresolved']==0 and v['enumerated']==w['enumerated']>0;deps.extend([x,y]);counts[p]=v['enumerated']
    tests=[prime(p,u) for p,u in [(71,25),(73,25),(79,27)]]
    cover={69:23,70:7,71:71,72:'9 or rank-two ternary',73:73,74:37,75:15,76:19,77:7,78:13,79:79,80:10}
    assert set(cover)==set(range(69,81))
    bound=F('0.01332146244505');assert V17/arb(D).sqrt()<arb(fmpq(str(bound)))
    o=dict(status='PASS',floor='1/2',dimension=17,edge='83/32',mass='1/4',D=D,complement=str(bound),vertices=verts,det_lower=lo,dual_bound=b,A16=A,covered_indices=cover,census_counts=counts,prime_average=tests,dependencies={x:sha(x) for x in deps})
    (H/'new-frame.json').write_text(json.dumps(o,indent=2)+'\n');print('Uniform frame PASS',len(cover),counts)
if __name__=='__main__':main()

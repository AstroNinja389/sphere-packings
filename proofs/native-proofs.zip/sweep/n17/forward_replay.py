"""Independent forward transfer over bin occupancies. Reconstruct the exact rounded budget."""
from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent
R=next(p/'sphere-packings/frame' for p in H.parents if (p/'sphere-packings/frame/audit_frame_bound.py').exists())
sys.path.insert(0,str(R))
import audit_frame_bound as stock
def walk(weights,penalty,caps,offset,J,extra=None,nfirst=0,need_at=None):
    cur={0:0}
    for b,hi in enumerate(caps):
        nxt={}
        for old,v in cur.items():
            for new in range(old,hi+1):
                if b==need_at and new+offset<nfirst:continue
                count=new+offset
                gain=(new-old)*weights[J+b]-penalty[b]*count*(count-1)
                if extra is not None:
                    gain+=extra[b]*(min(nfirst,count)-min(nfirst,old+offset))
                nxt[new]=max(nxt.get(new,stock.BAD),v+gain)
        cur=nxt
    return max(cur.values(),default=stock.BAD)
def main(tag):
    bundle=H/(tag+'-bundle.json');b=json.loads(bundle.read_bytes())
    for cut in b['cuts']:
        assert hashlib.sha256((H/cut['candidate']).read_bytes()).hexdigest()==cut['candidate_sha256']
    src=json.loads((H/(tag+'-audit.json')).read_bytes())
    stock.backward=walk;res=stock.audit(bundle,H/(tag+'-forward.json'))
    for k in ('integer_branch_maxima','rho','class_budget_scaled','final_bound'):
        assert res[k]==src[k],k
    print('All exact forward occupancy maxima equal backward maxima:',len(res['integer_branch_maxima']))
if __name__=='__main__':
    sys.set_int_max_str_digits(0);main(sys.argv[1])


"""Exact cyclic mean-square certificate for a near-frame with distinct prime characters."""
import numpy as np
from fractions import Fraction as F
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent
def spend(rows,m,cap):
    rows=sorted(rows,reverse=True);a=int(m//cap);return cap*sum(rows[:a])+(m-a*cap)*rows[a]
def compute(p,u,m,cap,n=17):
    h=p//2
    if h<n:return None
    exc=F(0)
    for t in range(n,h+1):
        # At most one high coordinate. Fix the largest, maximize the others independently subject to distinctness.
        end=min(u-1,t-1)
        if end<n-1:continue
        rem=list(range(end,end-n+1,-1))
        for v in [rem+[t],rem+[p-t]]:
            z=(sum(x*x for x in v)+spend([a*sum(v) for a in v],m,cap))/(p*p)
            exc=max(exc,z)
    # Only nonzero group elements are averaged; subgroup generator ±1,...,±h.
    residues=np.arange(1,h+1,dtype=np.int64);X=(residues[:,None]*residues[None,:])%p
    X=np.where(2*X>p,X-p,X);B=abs(X)>=u
    Y=2*X-p*np.sign(X)*B
    assert (B.sum(axis=0)==h-u+1).all()
    G=Y.T@Y
    mult=h-u+1;den=4*p*p*h
    diag=int(G[0,0])+p*p*mult
    assert all(G[i,i]==G[0,0] for i in range(h))
    rows=max(sum(sorted(map(abs,row.tolist()),reverse=True)[:n]) for row in G)
    # With exactly two high positions, the otherwise unbiased fair signs can be correlated.
    # Absolute contribution to the off-diagonal excess per incident index is <=1/4.
    ave=F(n*diag,den)+m*F(rows+2*p*p*mult,den)
    return dict(p=p,first_high=u,small=str(exc),mean=str(ave),score=str(max(exc,ave)),m=str(m),cap=str(cap))
def best(p,m,c,n=17):
    opts=[compute(p,u,m,c,n) for u in range(n-1,p//2+1)]
    return min(opts,key=lambda x:F(x['score']))
if __name__=='__main__':
    m=F(sys.argv[1]);cap=F(sys.argv[2]);res=[best(p,m,cap) for p in map(int,sys.argv[3:])]
    for x in res:print(x['p'],x['first_high'],round(float(F(x['small'])),4),round(float(F(x['mean'])),4))
    (H/f'prime-average-{m.numerator}-{m.denominator}-{cap.numerator}-{cap.denominator}.json').write_text(json.dumps(res,indent=2)+'\n')

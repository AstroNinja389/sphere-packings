"""Exact ordered-simplex cubature for exceptional cyclic multiples with few large residues."""
from prime_average import *
from functools import lru_cache
def policy(x,p,m,cap,k,flip):
    n=len(x);v=np.array(x,dtype=np.int64);G=np.outer(v,v);I=np.zeros(n,dtype=np.int64)
    if flip:
        I[-k:]=1; G=k*G-p*(np.outer(v,I)+np.outer(I,v))+p*p*np.diag(I);f=k
    else:f=1
    return (int(G.trace())+spend(list(map(int,np.abs(G).sum(axis=1))),m,cap))/(f*p*p)
def allverts(n,l,h):
    if n==0:return [()]
    if h-l+1<n:return []
    gap=h-l+1-n;return [tuple(l+i+(gap if i>=j else 0) for i in range(n)) for j in range(n+1)]
def solve(p,u,m,cap,n=17):
    exc=F(0);nvert=0
    for nh in (0,1,2):
        # Split at the largest residue in every separate high/low block to tighten the flip average.
        for t in (range(u,p//2+1) if nh else range(n,u)):
            low=allverts(n-nh if nh else n-1,1,u-1 if nh else t-1);high=allverts(nh-1,u,t-1) if nh else [()]
            V=list({a+b+(t,) for a in low for b in high}); nvert+=len(V)
            if not V:continue
            raw=max(policy(v,p,m,cap,1,False) for v in V)
            wrong=min(max(policy(v,p,m,cap,k,True) for v in V) for k in (1,2,3,4,5,8,12,17))
            exc=max(exc,raw,wrong)
    h=p//2;R=[[(k*x+p//2)%p-p//2 for x in range(1,h+1)] for k in range(1,h+1)]
    Y=[[2*t-(p if t>0 else -p)*(abs(t)>=u) for t in row] for row in R]
    # All columns are translates or negatives of the first under multiplication modulo p.
    G=[sum(v[0]*v[i] for v in Y) for i in range(h)]
    den=4*p*p*h;hit=h-u+1
    ave=F(n*(G[0]+p*p*hit),den)+m*F(sum(sorted(map(abs,G),reverse=True)[:n])+p*p*hit,den)
    return dict(p=p,u=u,exceptional=str(exc),mean=str(ave),vertices=nvert,passed=max(ave,exc)<2)
if __name__=='__main__':
    import sys
    m=F(sys.argv[1]);cap=F(sys.argv[2]);out=[]
    for v in sys.argv[3:]:
        p,u=map(int,v.split(':'));r=solve(p,u,m,cap);print(p,u,round(float(F(r['exceptional'])),5),round(float(F(r['mean'])),5),r['passed'],flush=True);out.append(r)
    (H/('refined-'+sys.argv[1].replace('/','-')+'-'+sys.argv[2].replace('/','-')+'-'+str(out[0]['p'])+'.json')).write_text(json.dumps(out,indent=2)+'\n')

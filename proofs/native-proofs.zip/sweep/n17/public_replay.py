"""Adapt the independent public checker to a locally constructed bundle."""
from pathlib import Path
import hashlib,sys,json,shutil
from fractions import Fraction as F
H=Path(__file__).resolve().parent;R=next(p/'sphere-packings' for p in H.parents if (p/'sphere-packings/verify').exists())
src=R/'frame/n17/r1';sys.path.insert(0,str(R/'frame'))
from audit_frame_bound import audit
def bundle(tag):
    c=H/(tag+'-fourier.json');pp=json.loads((H/(tag+'-prices.json')).read_bytes())
    b=json.loads((src/'bundle.json').read_bytes());b.update(baseline=c.name,baseline_sha256=hashlib.sha256(c.read_bytes()).hexdigest(),E=json.loads(c.read_bytes())['E'])
    for r,lam in zip(b['cuts'],pp['joint'],strict=True):
        file=H/'physical-kernel0.json'
        if not file.exists():shutil.copyfile(src/r['candidate'],file)
        assert hashlib.sha256(file.read_bytes()).hexdigest()==r['candidate_sha256']
        r.update(multiplier=lam,candidate=file.name)
    b.pop('floor',None)
    if tag.startswith('frame'):
        f=b['frame'];fn=H/'original-frame-premise.txt'
        if not fn.exists():shutil.copyfile(src/f['premise'],fn)
        f.update(multiplier=str(F(str(pp['frame']))),premise=fn.name)
    else:b.pop('frame',None)
    bp=H/(tag+'-bundle.json');bp.write_text(json.dumps(b,indent=2)+'\n');return bp
if __name__=='__main__':
    sys.set_int_max_str_digits(0);tag=sys.argv[1];audit(bundle(tag),H/(tag+'-audit.json'))


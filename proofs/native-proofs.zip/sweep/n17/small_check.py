"""Integer replay for odd-order subgroups and a generator with an involution."""
from fractions import Fraction as F
from itertools import combinations_with_replacement,islice
from math import comb,lcm,gcd
from pathlib import Path
import numpy as np,json,sys
H=Path(__file__).resolve().parent
def run(p,m,n=17,limit=None):
    den=lcm(*range(1,n+1));worst=0;count=0;bad=0;examples=[]
    it=combinations_with_replacement(range(p//2+1),n)
    while block:=list(islice(it,3072)):
        arr=np.array(block,dtype=np.int64)
        arr=arr[np.gcd.reduce(arr,axis=1,initial=p)==1]
        if p%2==0:
            w=(arr%2).sum(axis=1);arr=arr[(w>=8)&(w%2==0)]
        if limit:
            k,z=limit
            arr=arr[(np.sum(arr==0,axis=1)<=z)&np.all(np.array([np.sum(arr==b,axis=1)<=k for b in range(1,p//2+1)]),axis=0)]
        if not len(arr):continue
        for eta in ([arr.sum(axis=1)%2] if p%2 else [0,1]):
            best=np.full(len(arr),2**60,dtype=np.int64)
            for k in range(1,p//2+1):
                rnd=(2*k*arr+p)//(2*p);x=np.sort(abs(k*arr-p*rnd),axis=1)
                t=x[:,-1];c=(x==t[:,None]).sum(axis=1);y=np.max(np.where(x<t[:,None],x,0),axis=1)
                sm=x.sum(axis=1);sq=(x*x).sum(axis=1);res=sm-c*t
                par=(rnd.sum(axis=1)-k*eta)%2;halves=(2*x==p).sum(axis=1)
                par=np.where(halves,0,par)
                # Compute absolute row sums of a signed covariance after averaging equal nearest flips.
                diag=np.where(halves>=2,np.maximum(np.where(halves==2,2,1)*t*t,y*(sm-halves*t)),t*sm)
                a=c*t*t+p*p-2*p*t+(c-1)*abs(c*t*t-2*p*t)+abs(c*t-p)*res
                b=c*y*res+y*abs(c*t-p)*c
                # For nonmaximal axes the expected flipped sum over top axes is |c*t-p|.
                b=c*y*(res+abs(c*t-p))
                q=np.where(par,np.maximum(a,b),c*diag)
                score=((sq+par*p*(p-2*t))*c*m.denominator+q*m.numerator)*(den//c)
                best=np.minimum(best,score)
            count+=len(arr);worst=max(worst,int(best.max()));bad+=int((best>=2*p*p*den*m.denominator).sum())
            for i in np.flatnonzero(best>=2*p*p*den*m.denominator):
                if len(examples)<6:examples.append(arr[i].tolist())
    return dict(p=p,m=str(m),limits=limit,tested=count,max=str(F(worst,p*p*den*m.denominator)),bad=bad,examples=examples)
if __name__=='__main__':
    for z in sys.argv[2:]:
        p,*lim=map(int,z.split(':'));o=run(p,F(sys.argv[1]),limit=lim or None);print(o['p'],o['tested'],o['bad'],o['max'],flush=True)
        (H/f'sieve-{z.replace(":","-")}-{sys.argv[1].replace("/","-")}.json').write_text(json.dumps(o,indent=2)+'\n')

"""Exact small prime and twice-prime obstruction, including multiplicity of each binary lift."""
from itertools import combinations_with_replacement,product
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
from math import gcd
import sys,json
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'n15'))
from glue_patterns import representative
def upper(t,p,eta,m):
    return min((s+m*b)/(p*p) for s,b in [representative(t,p,k,eta) for k in range(1,p//2+1)])
def run(p,m,n=17):
    pure=[];lifts={};checked=0
    for v in combinations_with_replacement(range(p//2+1),n):
        if not max(v):continue
        if upper(v,p,sum(v)%2,m)<2:continue
        cnt=Counter(v);pure.append(tuple(cnt[i] for i in range(p//2+1)));keep=[]
        for f in product(*(range(c+1) for c in pure[-1])):
            t=[]
            for i,k in enumerate(f):t.extend([i]*(cnt[i]-k)+[p-i]*k)
            if sum(q%2 for q in t) not in (8,10,12,14,16):continue
            checked+=1
            if max(upper(t,2*p,e,m) for e in (0,1))>=2:
                # Odd coordinates represent the support of the chosen element of order two.
                keep.append(tuple(cnt[i]-k if i%2 else k for i,k in enumerate(f)))
        lifts[str(pure[-1])]=keep
    return dict(p=p,m=str(m),dimension=n,pure=pure,mixed=lifts,checked=checked)
if __name__=='__main__':
    m=F(sys.argv[1])
    for p in map(int,sys.argv[2:]):
        o=run(p,m);fname=f'small-{p}-{m.numerator}-{m.denominator}.json';(H/fname).write_text(json.dumps(o,indent=2)+'\n')
        print(m,p,len(o['pure']),o['checked'],max(map(len,o['mixed'].values()),default=0),flush=True)

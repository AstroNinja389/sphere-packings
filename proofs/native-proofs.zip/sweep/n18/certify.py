from integer_dp import *
import hashlib,math
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(tag,scale):
    cert=read(H/'rank-proof.json');assert cert['status']=='PASS' and cert['dimension']==18
    B=pr.bundle(tag);b=read(B);E=list(map(F,b['E']));assert E[-1]<=F(cert['terminal']) and not b.get('frame') and not b.get('floor') and not b.get('mixed')
    needs={int(k):F(v) for k,v in cert['compulsory'].items()};ans=[];deps={}
    for way in ('back','front'):
        vd=Verifier(E,needs,scale,way);st.backward=vd.callback
        p=H/f'{tag}-{way}-{scale}.json';v=st.audit(B,p);ans.append(v);deps[p.name]=sha(p)
        for f,h in v['dependencies'].items():
            file=H/f
            if not file.exists():
                paths=[H/k['candidate'] for k in b['cuts'] if Path(k['candidate']).name==f]
                assert len(paths)==1
                file=paths[0]
            assert sha(file)==h
    for k in ('rho','class_budget_scaled','integer_branch_maxima','density'):assert ans[0][k]==ans[1][k]
    # Exact LP over nested cumulative population caps, using integer branch maxima.
    from collections import Counter
    sys.path.insert(0,str(H.parent/'n14'));from incidence import spectral
    vs=list(map(int,ans[0]['integer_branch_maxima']));J=E.index(2);M=2**18-1
    caps={E.index(F(v['end'])):spectral(v,18)[1] for v in read(H/'prefix-polynomials.json') if F(v['end']) in E}
    assert all(caps[i]>=0 for i in caps)
    # Integral of population above each score level. All eligible short anchors for that level
    # lie at or below the largest eligible edge if the unanchored class is ineligible.
    budget=0;last=min(vs);budget=M*last
    for t in sorted(set(vs))[1:]:
        if vs[0]>=t:count=M
        else:
            p=max([i for i in range(1,len(vs)) if vs[i]>=t],default=0)
            count=min([M]+[n for i,n in caps.items() if i>=p])
        budget+=(t-last)*count;last=t
    score=F(budget,M);assert score<=max(vs)
    c=st.vb.parse_certificate((H/(tag+'-fourier.json')).read_text());_,q=st.vb.laguerre_pair(c)
    rho=F(ans[0]['rho'])-(max(vs)-score)/(10**16*q[0])
    U=(c.tau0/8)**9*rho/math.factorial(9);den=10**15;bd=F(ceil(U*den),den)
    for item in ['rank-proof.json','prefix-polynomials.json',B.name]:deps[item]=sha(H/item)
    out=dict(status='PASS',dimension=18,upper=str(bd),decimal=f'{float(bd):.15f}',base=ans[0]['density'],classes=len(vs),population_caps=len(caps),rho=str(rho),dependencies=deps)
    (H/f'{tag}-{scale}-union.json').write_text(json.dumps(out,indent=2)+'\n');print('N18',tag,out['decimal'])
if __name__=='__main__':sys.set_int_max_str_digits(0);run(sys.argv[1],int(sys.argv[2]))


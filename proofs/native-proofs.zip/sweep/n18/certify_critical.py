import sys,json,shutil
import certify_twice as c,critical_envelope as crit,multiple_envelopes as mu
from public_replay import H
old='fixed';new='critical'
for suffix in ['fourier','prices']:shutil.copyfile(H/f'{old}-{suffix}.json',H/f'{new}-{suffix}.json')
mu.prove=crit.prove;c.pr.bundle=c.multi;sys.set_int_max_str_digits(0);c.certify.run(new,96)


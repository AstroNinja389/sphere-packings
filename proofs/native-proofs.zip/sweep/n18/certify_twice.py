import certify,public_replay as pr
from pathlib import Path
import json,hashlib,shutil,sys
H=pr.H
def multi(tag):
    r=H/'family';c=H/(tag+'-fourier.json');pp=json.loads((H/(tag+'-prices.json')).read_bytes())
    b=json.loads((r/'bundle.json').read_bytes());b.update(baseline=c.name,baseline_sha256=hashlib.sha256(c.read_bytes()).hexdigest(),E=json.loads(c.read_bytes())['E'])
    for k,lam in zip(b['cuts'],pp['joint'],strict=True):
        p=r/k['candidate'];assert hashlib.sha256(p.read_bytes()).hexdigest()==k['candidate_sha256']
        k.update(candidate='family/'+p.name,multiplier=lam)
    b.pop('mixed',None);p=H/(tag+'-bundle.json');p.write_text(json.dumps(b,indent=2)+'\n');return p
import source_family
source_family.standard.audit=source_family.audit
import twice_audit as ss
certify.st=ss
if __name__=='__main__':pr.bundle=multi;sys.set_int_max_str_digits(0);certify.run(sys.argv[1],int(sys.argv[2]))


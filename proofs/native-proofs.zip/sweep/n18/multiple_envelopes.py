"""Charge tails of distinct short primitive lines by their actual integer multiples."""
from fractions import Fraction as F
import numpy as np
from scipy.special import eval_genlaguerre
from math import ceil,factorial
import signed_envelopes as se
import bernstein as vb
def box(p,a,b,c,k):
    # A constant upper bound on P(t) over this box. Directed exponential bounds use
    # the right endpoint for negative upper bounds, the left for nonnegative bounds.
    x=np.linspace(float(a),float(b),11);raw=float(max(eval_genlaguerre(k[:,None],8,x).T@c))
    for delta in [1e-10,1e-8,1e-6,1e-4,1e-2,.2,2,10]:
        d=F(str(raw+delta*max(1,abs(raw))+1e-9))
        diff=vb.poly_add([d],vb.poly_scale(p,-1))
        try:vb.prove_bernstein(vb.integer_interval_bernstein(diff,a,b),strict=False,label='multiple')
        except ValueError:continue
        if d>=0:return F(0)  # The existing final-half-line audit proves P<=0 here.
        _,u=se.expbox(b/2)
        return min(F(0),F(ceil(d/u*10**18),10**18))
    return F(0)
def prove(cert,p):
    out=se.prove(cert,p);c=np.array([float(x) for x in cert.c]);k=np.arange(len(c))
    assert cert.E[0]==1 and cert.E[-1]<4 and cert.tau0*cert.E[-1]*2<121
    for i,(lo,hi) in enumerate(zip(cert.E,cert.E[1:])):
        a,b=4*lo*cert.tau0,4*hi*cert.tau0
        out[i]+=box(p,a,b,c,k)
    return out


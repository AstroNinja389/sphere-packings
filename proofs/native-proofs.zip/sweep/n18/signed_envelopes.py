"""Certify signed upper bounds on P(t) exp(-t/2) on individual rational bins."""
from fractions import Fraction as F
from math import factorial,exp,ceil
import numpy as np
from scipy.special import eval_genlaguerre
import bernstein as vb
def expbox(x):
    term=F(1);s=term
    for j in range(1,120):term*=x/j;s+=term
    assert 0<=x<121
    u=s+term*x/120/(1-x/121)
    scale=10**12
    return F(s*scale//1,scale),F(ceil(u*scale),scale)
def prove(cert,p):
    c=np.array([float(x) for x in cert.c]);k=np.arange(len(c));terms=[];den=10**17
    for l,r in zip(cert.E,cert.E[1:]):
        a=l*cert.tau0;b=r*cert.tau0;h=(b-a)/2
        assert 0<h<1
        lo,hi=expbox(a/2);shift=[-a/2,F(1,2)]
        def power(v,n):
            res=[F(1)]
            for _ in range(n):
                s=[F(0)]*(len(res)+1)
                for j,t in enumerate(res):s[j]+=v[0]*t;s[j+1]+=v[1]*t
                res=s
            return res
        x=np.linspace(float(a),float(b),17);m=max(np.exp(-x/2)*(eval_genlaguerre(k[:,None],8,x).T@c))
        for inc in (1e-15,1e-13,1e-12,1e-11,1e-10,1e-9,1e-8,1e-7,1e-6):
            value=F(ceil((m+inc)*den),den)
            upper=value<0;mult=hi if upper else lo
            env=[F(0)]
            for j in range(4 if upper else 3):
                term=value*mult/factorial(j)
                if j==3:term/=1-h/4
                env=vb.poly_add(env,vb.poly_scale(power(shift,j),term))
            try:
                diff=vb.poly_add(env,vb.poly_scale(p,-1))
                vb.prove_bernstein(vb.integer_interval_bernstein(diff,a,b),strict=False,label='signed')
            except (AssertionError,ValueError,RuntimeError) as e:continue
            terms.append(value);break
        else:raise AssertionError(('no certified bound',str(l),str(r),m))
    return terms


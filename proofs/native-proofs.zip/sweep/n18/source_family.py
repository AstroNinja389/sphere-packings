"""Independent rational length-scale transport for the two physical sign domains of a Schur kernel."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,shutil
H=Path(__file__).resolve().parent;R=next(p/'sphere-packings' for p in H.parents if (p/'sphere-packings/verify').exists());sys.path.insert(0,str(R/'joint'))
import audit_schur_kernel as standard
base_audit=standard.audit
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
seen={}
def audit(c,out):
    c=Path(c);z=json.loads(c.read_bytes())
    if 'parent_kernel' not in z:return base_audit(c,out)
    par=H/z['parent_kernel'];key=sha(par);assert key==z['parent_sha256'];b=json.loads(par.read_bytes())
    assert 'parent_kernel' not in b and 'source_schur_B'in b and b['n']==z['n']==18
    for k in b:
        if k not in ['S','moment_anchor']:assert b[k]==z[k],k
    assert len(z['moment_anchor'])==2
    for v in z['moment_anchor']:F(v)
    ell=F(z['S'])-2;L=F(b['S'])-2
    assert 0<ell<=L<1 and F(z['source_cross'])>=0
    # Each partial derivative of (a+b-1)/sqrt(ab) has sign a-b+1 or b-a+1.
    assert 1-L>0
    # ab/ell^2 = (1/ell+u)(1/ell+v), decreasing for u,v>=0.
    # Extending to L raises both angular caps and increases the old signed target penalty.
    if key not in seen:
        dest=Path(out).with_name(Path(out).stem+'-parent.json')
        base_audit(par,dest);seen[key]=(json.loads(dest.read_bytes()),dest)
    t,dep=seen[key];assert t['candidate_sha256']==key
    o=dict(t,n=18,source_cap=z['S'],root_cap=str(F(z['S'])-1),candidate_sha256=sha(c),status='PASS_EXACT_RESTRICTED_LENGTH_SCHUR',transport_source=z['parent_kernel'],transport_sha=key,parent_sign_audit=dep.relative_to(H).as_posix(),parent_sign_hash=sha(dep),transport_auditor=sha(Path(__file__)))
    dest=Path(out);assert not dest.exists();dest.write_text(json.dumps(o,indent=2)+'\n')
def prepare():
    D=H/'family';D.mkdir(exist_ok=True);b=json.loads((H/'library/bundle.json').read_bytes());cuts=[];E=set(map(F,b['E']))
    for j,pair in enumerate([([10,14,16],[F(1,2),F(1),F(2)]),([16,20,24,28,32],[F(1,8),F(1,4),F(1,2),F(1)]),([14,16],[F(1,4),F(1,2)])]):
        parent=H/'library'/b['cuts'][j]['candidate'];z=json.loads(parent.read_bytes())
        for w in pair[0]:
            for scale in pair[1]:
                v=dict(z,S=str(2+F(w,128)),moment_anchor=[str(scale*F(x)) for x in z['moment_anchor']],parent_kernel=parent.relative_to(H).as_posix(),parent_sha256=sha(parent));i=len(cuts);cp=D/f'kernel{i}.json';cp.write_text(json.dumps(v,indent=2)+'\n');audit(cp,D/f'audit-kernel{i}.json')
                cuts.append(dict(candidate=cp.name,candidate_sha256=sha(cp),multiplier='0'));t=F(v['S']);E.update([t,t-1])
    b.update(cuts=cuts,E=list(map(str,sorted(E))));(D/'bundle.json').write_text(json.dumps(b,indent=2)+'\n');shutil.copyfile(H/'library/fourier.json',D/'fourier.json')
    x=(H/'search_many.py').read_text().replace("folder=here/'library'","folder=here/'family'");(H/'search_family.py').write_text(x)
    x=(H/'certify_many.py').read_text().replace("r=H/'library'","r=H/'family'").replace("candidate='library/'","candidate='family/'").replace('if __name__==', 'import source_family\nsource_family.standard.audit=source_family.audit\nif __name__==')
    (H/'certify_family.py').write_text(x)
if __name__=='__main__':prepare()


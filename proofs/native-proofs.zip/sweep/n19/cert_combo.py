from pathlib import Path
from fractions import Fraction as F
import os,sys,json,hashlib
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from flint import arb,fmpq,ctx
from pop_dp import Exact
from proof import verify
from public_replay import H,R
import combo_audit as st
import source_family
source_family.standard.audit=source_family.audit
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(tag,lib,scale):
    needs=verify();folder=H/lib;cp=H/(tag+'-fourier.json');pp=read(H/(tag+'-prices.json'));b=read(folder/'bundle.json');E=list(map(F,read(cp)['E']));assert E[-1]<4
    b.update(baseline=cp.name,baseline_sha256=sha(cp),E=list(map(str,E)))
    for c,lam in zip(b['cuts'],pp['joint'],strict=True):
        p=folder/c['candidate'];assert sha(p)==c['candidate_sha256'];c.update(candidate=lib+'/'+p.name,multiplier=lam)
    for z,v in zip(b.get('rectangles',[]),pp.get('rect',[]),strict=True):z['multiplier']=v
    from population import proof
    pop=proof();b['population']=pp['population'];assert F(b['population'])>=0 and F(pop['T']) in E
    assert not b.get('mixed');bp=H/(tag+'-bundle.json');bp.write_text(json.dumps(b,indent=2)+'\n')
    # Fast independent critical point envelopes cover every spatial interval, so only the two global signs are needed here.
    def signs(cert,p,q):
        st.vb.prove_bernstein(st.vb.integer_halfline_bernstein(q,F(0)),strict=True,label='Fourier half-line')
        st.vb.prove_bernstein(st.vb.integer_halfline_bernstein(st.vb.poly_scale(p,-1),cert.E[-1]*cert.tau0),strict=True,label='spatial tail')
    st.vb.prove_polynomial_obligations=signs
    ans=[];deps={}
    for way in ('back','front'):
        vl=Exact(E,needs,scale,way);vl.ix=E.index(F(pop["T"]))-E.index(2)-1;vl.lam=int(F(b["population"])*10**16);st.backward=vl.callback
        o=H/f'{tag}-{way}-{scale}.json';v=st.audit(bp,o);ans.append(v);deps[o.name]=sha(o)
        for f,h in v['dependencies'].items():
            t=H/f
            if not t.exists():t=next(H/k['candidate'] for k in b['cuts'] if Path(k['candidate']).name==f)
            assert sha(t)==h
    for k in ('rho','class_budget_scaled','integer_branch_maxima','density'):assert ans[0][k]==ans[1][k],k
    sys.path.insert(0,str(H.parent/'n14'));from incidence import spectral
    vs=list(map(int,ans[0]['integer_branch_maxima']));M=2**19-1
    caps={E.index(F(v['end'])):spectral(v,19)[1] for v in read(H/'prefix-polynomials.json') if F(v['end']) in E}
    score=M*min(vs);last=min(vs)
    for t in sorted(set(vs))[1:]:
        if vs[0]>=t:count=M
        else:
            idx=max(i for i in range(1,len(vs)) if vs[i]>=t)
            count=min([M]+[m for i,m in caps.items() if i>=idx])
        score+=(t-last)*count;last=t
    c=st.vb.parse_certificate(cp.read_text());_,q=st.vb.laguerre_pair(c)
    rho=F(ans[0]['rho'])-(max(vs)-F(score,M))/(10**16*q[0])
    ctx.prec=180;A=lambda x:arb(fmpq(str(x)));density=(A(c.tau0)/8)**(arb(19)/2)*A(rho)/(arb(21)/2).gamma()
    up=max(7372000000000,int(float(density)*10**15)+1);assert density<A(F(up,10**15))
    for item in [bp.name,'angular-polynomials.json','prefix-polynomials.json','proof.py','caps.py','pop_dp.py','population.py','population-proof.json','pop_audit.py','combo_audit.py','nested_angles.py','critical_envelope.py','double_audit.py','double_angle.py','rectangles.py','poly19.py','source_family.py']:deps[item]=sha(H/item)
    out=dict(status='PASS',dimension=19,upper=str(F(up,10**15)),decimal=f'{up/10**15:.15f}',base=ans[0]['density'],rho=str(rho),dependencies=deps,method='critical point envelopes and double multiples; rational long-shell projective codes; two independent count DPs',library=lib)
    (H/f'{tag}-{scale}-union.json').write_text(json.dumps(out,indent=2)+'\n');print('final',tag,out['decimal'],flush=True)
if __name__=='__main__':sys.set_int_max_str_digits(0);run(sys.argv[1],sys.argv[2],int(sys.argv[3]))


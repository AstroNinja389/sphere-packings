"""Independent physical envelope from all complex roots of 2P'-P certified by Arb."""
from fractions import Fraction as F
from flint import fmpq,fmpq_poly,arb,acb,ctx
import math
def prove(c,p):
    ctx.prec=550
    poly=fmpq_poly([fmpq(str(x)) for x in p]);der=2*poly.derivative()-poly
    roots=der.complex_roots();assert sum(int(m) for z,m in roots)==der.degree()
    reals=[z.real for z,m in roots if z.imag.contains(0)]
    def A(x):return arb(fmpq(str(x)))
    co=[A(x) for x in p]
    def value(t):
        v=arb(0)
        for x in reversed(co):v=v*t+x
        return v*(-t/2).exp()
    fixed=[(q,value(q)) for q in reals];den=10**18;out=[]
    for l,r in zip(c.E,c.E[1:]):
        up=0
        for j in [1,4]:
            lo=A(j*l*c.tau0);hi=A(j*r*c.tau0)
            vals=[value(lo),value(hi)]+[v for x,v in fixed if not (x<lo or x>hi)]
            def ceiling(v):
                hi=v.upper();z=int(float(hi)*den)+2
                while not v<arb(fmpq(z,den)):z+=1
                return z
            up+=max(ceiling(v) for v in vals)
        out.append(F(up,den))
    return out


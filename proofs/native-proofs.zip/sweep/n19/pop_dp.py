"""Independent rank-limited resource recurrences with a scalar saturated tail."""
from fractions import Fraction as F
from functools import lru_cache
import numpy as np
def ceil(x):return -((-x.numerator)//x.denominator)
class Exact:
    def __init__(self,E,needs,scale,direction):
        self.J=E.index(2);self.inc=[ceil((e-2)*scale) for e in E[self.J+1:]];self.need={k:ceil(a*scale) for k,a in needs.items()};self.R=max(self.need.values());self.way=direction
    def callback(self,W,pen,cap,off,J):
        assert J==self.J and all(a<=b for a,b in zip(cap,cap[1:]))
        return self.run(tuple(W[J:]),tuple(pen),tuple(cap),off)
    @lru_cache(None)
    def run(self,W,pen,cap,off):
        g=cap[-1];k0=min(max(self.need)-off,g);R=self.R;r=np.arange(R+1);m=(g+2)*max(map(abs,W))+(g+2)**2*sum(map(abs,pen))
        dt=np.int64 if 3*m<2**60 else object
        neg=-2**61 if dt==np.int64 else -2**200;assert m<-neg//3
        if self.way=='back':
            f=np.zeros((k0+1,R+1),dtype=dt);tail=np.zeros(g+1,dtype=dt)
            for i,(h,w,p,inc) in reversed(list(enumerate(zip(cap,W,pen,self.inc)))):
                a=self.lam if i==self.ix else 0
                high=min(h,k0);old=f.copy();dest=np.minimum(r+inc,R)
                if h>=k0:
                    ix=np.arange(k0,h+1,dtype=dt);t=ix*w-p*(ix+off)*(ix+off-1)-a*(ix+off>=19)+tail[k0:h+1]
                    tail[k0:h+1]=np.maximum.accumulate(t[::-1])[::-1]-ix*w
                    f[k0]=tail[k0]
                else:f[high]=old[high]-p*(high+off)*(high+off-1)-a*(high+off>=19)
                for k in range(high-1,-1,-1):
                    f[k]=old[k]-p*(k+off)*(k+off-1)-a*(k+off>=19);good=dest>=self.need.get(k+off+1,0)
                    f[k,good]=np.maximum(f[k,good],w+f[k+1,dest[good]])
            return int(f[0,0])
        f=np.full((k0+1,R+1),neg,dtype=dt);f[0,0]=0;tail=np.full(g+1,neg,dtype=dt)
        for i,(h,w,p,inc) in enumerate(zip(cap,W,pen,self.inc)):
            a=self.lam if i==self.ix else 0
            old=f.copy();hi=min(k0,h)
            for k in range(1,hi+1):
                need=np.maximum(r,self.need.get(k+off,0));f[k]=np.maximum(old[k,need],f[k-1,np.maximum(0,need-inc)]+w)
            if h>=k0:
                ix=np.arange(k0,h+1,dtype=dt);v=tail[k0:h+1]-ix*w;v[0]=f[k0,0]-k0*w
                tail[k0:h+1]=np.maximum.accumulate(v)+ix*w-p*(ix+off)*(ix+off-1)-a*(ix+off>=19)
            for k in range(hi+1):f[k]-=p*(k+off)*(k+off-1)+a*(k+off>=19)
        return int(max(max(f[:,0]),max(tail)))


"""Exact constants for the common annihilator of all almost-full parity frames."""
from fractions import Fraction as F
from pathlib import Path
from math import comb
from flint import arb,fmpq,ctx
import json
H=Path(__file__).resolve().parent
def proof():
    e=F(1,80);d=e/2;T=2+e;D=40;U=lambda s:s+s*s*d/(1-19*d)
    assert U(4)<F(19,4)/(1+19*d) and U(2)<F(2*64,D)
    # U(2) uses two signed units; a doubled unit has l1=2, l2^2=4 and fits U(4).
    ctx.prec=150;V=arb.pi()**(arb(19)/2)/(arb(21)/2).gamma();V18=arb.pi()**9/362880;A=lambda x:arb(fmpq(str(x)))
    r18=F(json.loads((H.parent/'n18/critical-96-union.json').read_bytes())['upper']);assert (V18/A(r18))**2>64
    r19=F(json.loads((H/'farfix-96-union.json').read_bytes())['upper']);assert A(2**21*(1+d)**19)*(A(r19)/V)**2<256**2
    assert 19*d<F(1,8) and json.loads((H/'marked-geometry.json').read_bytes())['three_torsion_upper']==3
    counts={}
    for t in range(4):
        non=19-t;z=2 if t==0 else 1 if t==1 else 0
        edges=4*comb(non,2)+2*non*t+comb(t,2)-4*comb(4*z,2)
        counts[t]=edges;assert edges>2*255+3
    return dict(status='PASS',T=str(T),max_full_classes=2**16-1,all_nonzero_classes=2**19-1,det_branch=D,complement='0.007372',upper_integer_normal=str(U(4)),lower_half_integral=str(F(19,4)/(1+19*d)),j_max=255,edge_counts=counts,rank18_source=str(r18))
if __name__=='__main__':o=proof();assert (arb.pi()**(arb(19)/2)/(arb(21)/2).gamma()/arb(40).sqrt())<arb(fmpq(str(F(o['complement']))));(H/'population-proof.json').write_text(json.dumps(o,indent=2)+'\n');print(o)


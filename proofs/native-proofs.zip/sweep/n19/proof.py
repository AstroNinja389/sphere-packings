from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
H=Path(__file__).resolve().parent
needs={20:F('11/10'),21:F('21/10'),22:F('31/10'),23:F(4),24:F('49/10'),25:F('57/10')}
def verify():
    for k,m in needs.items():
        upper=1+4*(k-19)/m-F(2,k-1);assert upper>0 and upper**2>=k
    # Direct derivatives of the same-class angular bound, including the short anchor.
    assert F(4)-F(7,2)+1>0
    return needs
if __name__=='__main__':print(verify())


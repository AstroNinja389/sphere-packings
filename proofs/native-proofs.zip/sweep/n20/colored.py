"""Shared radial-color positive harmonics for both short–short and short–long parity collisions."""
from rectangles import *
from itertools import product
from math import gcd
from fractions import Fraction as F
M=2**20-1
def root_limit(t):
    return t[1]-1 if t[0]=='near' else (t[1]+t[2])/2-1
def target_ranges(lo,hi,lo2,hi2,ts):
    ordinary=(hi+hi2-1)**2/(4*hi*hi2)
    intervals=[]
    for t in ts:
        if t[0]=='near':
            S=t[1]
            ran=None if lo+lo2>S else (F(0),(S-lo-lo2)**2/(4*lo*lo2))
        else:
            A,B=t[1:];U=root_limit(t)
            # Both half sums have squared length <=U. Either endpoint at the ceiling is harmless.
            if max(lo,lo2)>U or 2*(lo+lo2)>A+B:ran=None
            else:
                lower=max((1-A/2)**2,max(F(0),lo+lo2-A)**2/(4*hi*hi2))
                upper=min(((B-2)/2)**2,max(F(0),B-lo-lo2)**2/(4*lo*lo2))
                ran=(lower,upper) if lower<=upper else None
        intervals.append(ran)
    knots=sorted({F(0),ordinary}|{u for r in intervals if r for u in r if 0<=u<=ordinary})
    def block(x):return tuple(i for i,v in enumerate(intervals) if v and v[0]<=x<=v[1])
    for l,r in zip(knots,knots[1:]):
        k=block((l+r)/2);steps=max(1,round(float(r-l)*60))
        for h in range(steps):yield l+(r-l)*h/steps,l+(r-l)*(h+1)/steps,k
    for p in knots:yield p,p,block(p)
def conedata(z):
    ts=[(t[0],*map(F,t[1:])) for t in z['targets']];v=list(map(F,z['edges']));assert v[0]==1 and v[-1]<F(3,2) and v==sorted(set(v))
    for t in ts:
        if t[0]=='near':assert len(t)==2 and 2<t[1]<F(5,2)
        else:assert t[0]=='mix' and len(t)==3 and 1<t[1]<2<t[2]<3 and t[1]+t[2]>4
        assert root_limit(t)<=v[-1]
    return ts,v
def decode(z):
    ts,e=conedata(z);n=len(e)-1;dim=z['degree'];t=list(map(F,z['anchor']));w=list(map(F,z['weights']));assert len(w)==len(ts) and min(w)>=0 and len(t)==n
    A=[[[F(0) for _ in range(n)] for _ in range(n)] for j in range(dim+1)]
    for j,s,v in z['terms']:
        s=F(s);v=list(map(F,v));assert s>0 and 0<=j<=dim and len(v)==n
        for i in range(n):
            for k in range(n):A[j][i][k]+=s*v[i]*v[k]
    for i in range(n):
        for k in range(i,n):
            pol=[sum(basis(j)[l]*A[j][i][k] for j in range(l,dim+1)) for l in range(dim+1)]
            for l,r,q in target_ranges(e[i],e[i+1],e[k],e[k+1],ts):
                assert max(controls(pol,l,r,dim))<=-sum(w[j] for j in q),(i,k,q)
    costs=[sum(B[i][i] for B in A)-2*sum(A[0][i][j]*t[j] for j in range(n)) for i in range(n)]
    bonus=sum(t[i]*t[j]*A[0][i][j] for i in range(n) for j in range(n))
    return e,costs,bonus,list(zip(ts,w))
def packed(z,E):
    e,c,b,t=decode(z);assert set(e)<=set(E)
    return c if E==e else [next((x for i,x in enumerate(c) if e[i]<=lo<e[i+1]),F(0)) for lo in E[:-1]],b,t
@lru_cache(None)
def btable(l,r,d):
    return np.array([controls(basis(j),l,r,d) for j in range(d+1)],dtype=float).T
def build(edges,ts,N,coll,degree,anchor_scale):
    n=len(edges)-1;W=np.array([round(M*y*anchor_scale) for y in N],dtype=int);z=dict(degree=degree,edges=list(map(str,edges)),targets=[[t[0],*map(str,t[1:])] for t in ts],anchor=list(map(str,W)))
    rays=[]
    for v in product(range(-2,3),repeat=n):
        if not any(v) or next(q for q in v if q)<0 or gcd(*v)!=1:continue
        rays.append(v)
    rays=np.array(rays);nr=len(rays);nd=(degree+1)*nr;nt=len(ts);rr=[];rhs=[]
    for i in range(n):
        for k in range(i,n):
            zz=rays[:,i]*rays[:,k]
            for l,r,q in target_ranges(edges[i],edges[i+1],edges[k],edges[k+1],ts):
                a=btable(l,r,degree);v=(a[:,:,None]*zz).reshape(len(a),nd);data=np.zeros((len(a),nt));data[:,q]=1
                rr.append(np.hstack([v,data]));rhs.extend([-1e-6]*len(a))
    mat=np.vstack(rr);norm=np.maximum(1e-12,np.max(np.abs(mat),axis=0));dia=(rays*rays)@N;obj=np.tile(dia,degree+1);obj[:nr]+=(rays@W)**2/M-2*(rays@W)*(rays@N)
    eq=np.r_[np.zeros(nd),np.ones(nt)]
    ans=linprog(np.r_[obj,-np.array(coll)]/norm,A_ub=mat/norm,b_ub=rhs,A_eq=[eq/norm],b_eq=[1],bounds=(0,None),options={'threads':1,'time_limit':30,'primal_feasibility_tolerance':2e-9})
    if not ans.success:return
    x=np.maximum(0,ans.x/norm)
    z.update(weights=[str(F(format(y,'.17g'))) for y in x[nd:]],terms=[[j//nr,str(F(format(y,'.17g'))),rays[j%nr].tolist()] for j,y in enumerate(x[:nd]) if y>0],price=ans.fun)
    decode(z);return z
def main(tag,prof,base,kind):
    from math import comb
    D=H/tag;D.mkdir(exist_ok=True);old=H/base;b=json.loads((old/'bundle.json').read_bytes());pr=np.load(H/(prof+'-profiles.npz'));E=list(map(F,pr['E']));X=pr['P'];mass=pr['w'];total=set(map(F,b['E']));out=[]
    def cnt(a,b):return X[:,[i for i,l in enumerate(E[:-1]) if a<=l<b]].sum(axis=1)
    cases=[]
    for e in map(F,['1/384','1/128','1/64','1/32','1/16','3/32']):
        S=2+e
        for A in ([F(73,48),F(25,16)] if kind=='mixed' else [None]):
            t=[('near',2+e/2),('near',S)]
            if A:t+= [('mix',A,4-A+2*e)]
            cases.append((e,t))
    for e,t in cases:
        U=max(root_limit(x) for x in t);ed=sorted({F(1),1+e/2,U})
        if len(ed)<3:continue
        N=np.array([float(mass@cnt(i,j)) for i,j in zip(ed,ed[1:])]);coll=[]
        for f in t:
            if f[0]=='near':
                c=cnt(1,f[1]);coll.append(float(mass@(c*(c-1))))
            else:coll.append(float(2*mass@(cnt(1,f[1])*cnt(2,f[2]))))
        for scale in [.75,1.]:
            try:z=build(ed,t,N,coll,7,scale)
            except AssertionError as err:print('failed exact sign',t,str(err)[:80],flush=True);continue
            if z is None:continue
            print(str(e),len(t),scale,z['price'],list(map(float,map(F,z['weights']))),flush=True);out.append(z)
            total.update(ed);total.update(v for q in t for v in q[1:])
            (D/'screen.json').write_text(json.dumps(out))
    for c in b['cuts']:
        f=old/c['candidate'];shutil.copyfile(f,D/f.name)
    for i in range(len(b['cuts'])):shutil.copyfile(old/f'audit-kernel{i}.json',D/f'audit-kernel{i}.json')
    b.update(colored=out,E=list(map(str,sorted(total))));(D/'bundle.json').write_text(json.dumps(b,indent=2));shutil.copyfile(old/'fourier.json',D/'fourier.json')
if __name__=='__main__':main(*sys.argv[1:])

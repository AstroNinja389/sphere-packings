"""Retarget an existing even spherical-code polynomial at each actual angular cutoff."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import sys,json
import numpy as np
H=Path(__file__).resolve().parent
@lru_cache(None)
def data(n):
    sys.path.insert(0,str(H.parents[1]/'gap-crosscheck-20261118'));from prefix_codes import monomial
    proofs=json.loads((H/'angular-polynomials.json').read_bytes())[str(n)];rr=[];norms=[]
    for z in proofs:
        p=list(map(F,z['p']));a=[F(0)]*(2*len(p)-1+z['shift'])
        for i,x in enumerate(p):
            for j,y in enumerate(p):a[i+j+z['shift']]+=x*y
        def expand(delta):
            out=[F(0)]*(len(a)+1)
            for i,y in enumerate(a):
                m=monomial(n,2*(i+delta))
                for j,x in enumerate(m[::2]):out[j]+=x*y
            return out
        h=expand(0);g=expand(1);rr.append((g,h,sum(a)));norms.append((float(g[0]),float(h[0]),float(sum(a))))
    return rr,np.array(norms).T
@lru_cache(None)
def cap(n,x):
    from caps import cap as orig
    best=orig(n,x);r,a=data(n);s=x*x;den=a[0]-float(s)*a[1]
    pred=np.full(len(den),np.inf);good=den>0;pred[good]=(1-float(s))*a[2,good]/den[good]
    for i in np.argsort(pred)[:5]:
        if pred[i]>best+.1:break
        g,h,p=r[i];q=g[0]-s*h[0]
        if q>0 and all(v>=s*b for v,b in zip(g,h)):best=min(best,int((1-s)*p//q))
    return best
@lru_cache(None)
def long_cap(n,s):return cap(n,1-2/s)
@lru_cache(None)
def short_cap(n,t,s):
    if t+s<=4:return 0
    u=(t+s-4)**2/(4*t*s);c=1-2/s
    return min(long_cap(n,s)-1,cap(n-1,(c+u)/(1-u)))
def geometry(n,E):
    j=E.index(2);return j,np.array([[long_cap(n,s) for s in E[j+1:]]]+[[short_cap(n,t,s) for s in E[j+1:]] for t in E[1:j+1]],dtype=int)

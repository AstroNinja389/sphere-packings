# Using the sign of the axial coordinate

The shortest-vector translation proof in PROOF.md bounds the number of opposite pairs below squared length \(3/2\) by \(2^{20}\) plus the size of a single projected code. Here the bound on that code improves from 225,853 to **172,925**. The resulting universal cap is **1,221,501**, compared with the previous stored 2,012,788.

Orient each shifted line so its coordinate along the fixed shortest vector is nonnegative. Divide these coordinates into two intervals with common endpoint \(1/8\). If the two axial coordinates are \(h,k\), and the original squared lengths are \(p,q\), the possible projected inner products after normalization are between
\[
 \frac{-p-q+1-2hk}{2\sqrt{(p-h^2)(q-k^2)}}
 \quad\hbox{and}\quad
 \frac{p+q-1-2hk}{2\sqrt{(p-h^2)(q-k^2)}}.
\]
The negative and positive endpoints differ in magnitude. The representatives with axial coordinate zero may be oriented arbitrarily. As in the original translation proof, monotonicity in \(p,q\) permits replacing them by \(5/4-h,5/4-k\). A rational partition into \(64^2\) rectangles encloses the three possible color-pair intervals.

On these intervals use dimension-20 spherical harmonics through degree 16, including the odd degrees, with a positive-semidefinite two-by-two coefficient matrix for each degree. If every off-diagonal value is at most \(-1\), then summing the kernel gives \(0\le N(K-1)-N(N-1)\), where \(K-1\) bounds both diagonal values. Hence \(N\le\lfloor K\rfloor\). The search used finite samples only to propose the rational coefficient matrices. A separate checker reconstructed the matrices, checked their principal minors and verified the polynomial inequalities on all three closed intervals with 39 Bernstein leaves. [Coefficients](asymmetric-lens.json) · [Independent arithmetic](audit_asymmetric.py) · [Signed audit](asymmetric-lens-audit.json)


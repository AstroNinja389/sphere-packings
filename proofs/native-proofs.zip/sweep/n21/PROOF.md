# Dimension 21

Normalize the minimum squared length of the lattice \(L\) to one. Let \(D\) be the Gram determinant of \(2L\), which has minimum four, and write \(V_n=\pi^{n/2}/\Gamma(1+n/2)\). The packing density is \(V_{21}/\sqrt D\). All density certificates in this slot concern lattices.

## A shorter reciprocal sign interval

Split at \(D=21/2\). On the larger side the volume formula gives the desired bound directly. On the smaller side let \(y\) be a primitive vector of \(L^*\). The rank-20 section of \(2L\) perpendicular to \(y\) has Gram determinant \(D|y|^2/4\), by the spacing \(2/|y|\) of the layers of \(2L\). Its minimum is at least four. The rank-20 bound \(B_{20}=0.005813810448531\) therefore gives
\[
 |y|^2\ \ge\ 4(V_{20}/B_{20})^2/D.
\]
Multiples obey the same lower bound. The dual Fourier variable for a Laguerre polynomial of scale \(\tau\) is \(4\pi^2 |y|^2/\tau\). The sign at zero enters through normalization. On the nonzero spectrum only the resulting half-line requires a sign proof. The final result includes both determinant branches. [Rank-20 certificate](../n20/tight-96-union.json)

## Lengths, labels and Fourier summation

Take the two opposite pairs \(x,y\) in one nonzero class of \(L/2L\). Their half-sum and half-difference \(u,v\) are actual lattice vectors. Put \(a=|x|^2,\ b=|y|^2,\ r=|u|^2,\ s=|v|^2\). Then \(r+s=(a+b)/2\) and \(4\sqrt{rs}\,|\cos(u,v)|=|a-b|\). The two output lines determine the input lines in these windows, since all representatives are primitive. We count both orders. An output pair can meet several targets and must pay their total weight.

For each even harmonic degree we use a positive-semidefinite matrix indexed by the two individual root-length bins. Summing the corresponding spherical kernel over the output lines gives a nonnegative number by the addition formula. The constant harmonic in the count vector \(N\) is at least \(2t^\top A_0N-t^\top A_0t\) for any chosen center \(t\). We audit the polynomial for each pair of bins over its whole ordinary angle interval. On each exceptional subinterval its required upper bound is minus the sum of its target weights. The program uses the two identities above for those subintervals and includes every endpoint. This gives a linear cost per output and a quadratic charge on the appropriate input counts in each common class. A kernel with zero target weights still gives a valid inequality on the output counts. The pricing experiment allows such kernels by bounding the total matrix trace. Only exact sign checks and nonnegative multipliers enter the proof. The independent matrix checker reconstructs the zonal polynomials for dimension 21 and checks all principal minors.

The Fourier test has the form \(e^{-\tau |x|^2/2}P(\tau |x|^2)\); the normalized Laguerre basis uses parameter \(19/2\), with alternating signs on the Fourier side. Exact Bernstein subdivision proves the two half-line signs. On every spatial bin an Arb enclosure uses endpoints and every real critical value, isolated among the roots of \(2P'-P\). Each primitive line in this window can be charged together with its double, and the doubles are distinct. The remaining spatial tail is nonpositive. Forward and reverse integer recurrences separately maximize each parity-class budget over all allowed length profiles, including the spherical caps and the rank-21 excess-length floors of proof.py. The projector proof of the floors is the rank-\(n\) inequality given in the earlier sweep. Class maxima are combined with the cumulative caps on the number of short representatives over all classes. seal21.py recomputes this sum by filling the ordered population ranges, checks the Fourier normalization and repeats the comparison with the complementary determinant bound. [Projector argument](../n18/GEOMETRY.md) · [Independent harmonic checks](independent_colors.py) · [Forward and reverse recurrences](quick_dp.py)

## A shortest vector bounds the population below squared length 3/2

Choose a shortest vector \(x\). Translation by its nonzero parity label partitions the \(2^{21}\) classes into \(2^{20}\) disjoint pairs. Each class contains at most one opposite pair below squared length \(b<2\), by the parallelogram identity. Each occupied pair of classes can contribute one representative freely. A second requires two representatives \(y,z\) with \([y]+[z]=[x]\). Then \(r=(y+z)/2,\ s=(y-z)/2\) both belong to the **same shifted lattice** \(x/2+L\). They determine \(y,z\) up to sign and order. Their squared lengths sum to less than \(b\).

Except for \(\pm x/2\), every \(r\) of the shifted lattice satisfies \(|r|^2\ge3/4+|\langle x,r\rangle|\), by applying the lattice minimum to \(r\pm x/2\). Thus at \(b=3/2\) one of \(r,s\) must equal \(\pm x/2\). Write \(w\) for the other. The inequalities \(|w\pm x/2|^2<b\) give \(|w|^2\le R-h\), where \(R=b-1/4,\ h=|\langle x,w\rangle|\). Also \(|w|^2\ge3/4+h\). In particular \(h\le (R-3/4)/2\).

Project the lines \(w\) off \(x\). For two different lines with squared lengths \(p,q\) and axial magnitudes \(h,k\), the absolute normalized inner product is bounded by
\[
 \frac{p+q-1+2hk}{2\sqrt{(p-h^2)(q-k^2)}} .
\]
Both their difference and sum belong to \(L\). The displayed expression increases in \(p,q\) on the stated range, as follows by differentiation. Substitute \(p=R-h,\ q=R-k\) and cover the square of possible \(h,k\) with 1,024 rational rectangles. The resulting dimension-20 projective code bound permits at most 225,853 additional occupied classes at \(b=3/2\). With the free population \(2^{20}\) this yields **1,274,429 opposite pairs**, compared with the earlier spherical upper bound of 2,012,788. This proof applies to every dimension-21 lattice of minimum one.

For \(b>3/2\) two nonspecial shifted lines can also qualify. For \(a=3/4\), divide the possible squared lengths of \(r\) from \(a\) to \(b-a\) into eight bands. If \(r^2\in[l,u]\) (here \(r^2\) denotes the squared norm), then \(s^2\le S=b-l\) and \(|\langle r,s\rangle|\le(S-a)/2\). Put \(e=u-a,\ d=S-a\). Projecting off \(x\) gives a dimension-20 cap on the entire prefix up to \(u\). The squared length removed is at most \(e^2\). To bound the number of neighbors of one \(r\), also project off \(r-\langle r,x\rangle x\). The total squared length removed from any \(s\) is at most
\[
 J=d^2+\frac{(d/2+ed)^2}{a-e^2}.
\]
The original coherence of the neighbors is at most \(1-1/(2S)\). Projection changes the bound to \((1-1/(2S)+J/a)/(1-J/a)\) in dimension 19. Sum the resulting degree bounds by parts against the prefix populations and divide by two to count unordered pairs. The independent audit checks the monotonicity required for summation and expands each spherical polynomial in the normalized Gegenbauer basis using rational arithmetic. It verifies all 32 thresholds. [Translation proof data](translation-prefix-proofs.json) · [Independent audit](translation_audit.py)

Orienting each projected lens line by its axial coordinate and retaining odd spherical harmonics improves the cap at squared length 3/2 to **1,221,501**. [Proof and independent sign checks](ASYMMETRIC.md)

## Additional tests

A primitive shortest reciprocal vector gives a nonzero binary character. Exactly \(2^{20}\) classes have odd value. In each such class a set of \(k\) lines below squared length \(S\) satisfies \(k\le |y|^2(2+k(S-2))\). Indeed the integer pairings have magnitude at least one, while the Gram operator norm is bounded by the diagonal bound \(S\) plus \(k-1\) off-diagonal bounds \(S-2\). The ordinary and odd class programs were optimized jointly for \(|y|^2\le9\), with a complementary computation for \(|y|^2\ge9\). The combined numerical value in RESULT.md uses exact certificates for each branch. Separate projected two-direction tests and one local harmonic kernel are preserved as diagnostics.

Exact LDL enumeration of the named Gram gives minimum four, determinant 32 and 27,720 contacts. Its density is \(V_{21}/\sqrt{32}\). A separate hypothesis yields a stronger upper bound. Suppose a minimum-four lattice has a primitive rank-16 Barnes–Wall section whose largest metric eigenvalue relative to the minimum-four Barnes–Wall reference is at most \(16/15\). The six-design argument from the earlier sweep gives section determinant at least 256; named21.py verifies its scalar hypothesis. Its squared covering radius is at most \(3(16/15)\), so the five-dimensional projected quotient has squared minimum at least \(4/5\). The exact five-dimensional Hermite constant gives quotient determinant at least \((4/5)^5/8\). Multiplying gives \(D\ge32768/3125\). This conclusion requires the stated section. [Section computation](named21.py) · [Earlier design proof](../n18/GEOMETRY.md)


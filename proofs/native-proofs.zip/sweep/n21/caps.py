"""Rational projective spherical codes, including the range beyond the relative bound."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from bisect import bisect_left
import sys,json
H=Path(__file__).resolve().parent
def build():
    sys.path.insert(0,str(H.parents[1]/'gap-crosscheck-20261118'));from prefix_codes import candidate
    out={}
    for n in (20,21):
        items=[]
        for i in range(0,97):
            c=F(i,128);e=1/(2*(1-c))
            v=[z for j in range(5) for k in (0,1) if (z:=candidate(n,e,j,k))]
            if v:items.append(min(v,key=lambda s:s['cap']))
        out[str(n)]=items
    (H/'angular-polynomials.json').write_text(json.dumps(out,indent=2)+'\n')
@lru_cache(None)
def table():
    sys.path.insert(0,str(H.parent/'n14'));from incidence import spectral
    return {int(n):[spectral(z,int(n)) for z in v] for n,v in json.loads((H/'angular-polynomials.json').read_bytes()).items()}
@lru_cache(None)
def cap(n,c):
    bounds=[b for t,b in table()[n] if c<=t]
    if n*c*c<1:bounds.append(int(n*(1-c*c)//(1-n*c*c)))
    return min(bounds)
@lru_cache(None)
def long_cap(n,s):return cap(n,1-2/s)
@lru_cache(None)
def short_cap(n,t,s):
    if t+s<=4:return 0
    u=(t+s-4)**2/(4*t*s);c=1-2/s
    return min(long_cap(n,s)-1,cap(n-1,(c+u)/(1-u)))
def geometry(n,E):
    import numpy as np
    j=E.index(2);return j,np.array([[long_cap(n,s) for s in E[j+1:]]]+[[short_cap(n,t,s) for s in E[j+1:]] for t in E[1:j+1]],dtype=int)
if __name__=='__main__':build();print([(str(t),long_cap(21,t)) for t in map(F,['5/2','41/16','83/32','8/3','11/4','3','13/4'])])


"""Very short symmetric source windows and the root-angle penalty at each radius."""
from double_angle import *
def scan(S,N,w,d):
    U=S-1;c=(1-1/(2*U))**2;close=((S-2)/2)**2;num=24;rows=[];rhs=[]
    for l,r,t in [(c*i/num,c*(i+1)/num,0) for i in range(num)]+[(F(0),close,1)]:
        vals=list(zip(*(controls(basis(j),l,r,d) for j in range(d+1))));rows.extend(vals);rhs.extend([-t-2e-6]*(d+1))
    mat=np.array(rows,dtype=float);sc=np.max(abs(mat),axis=0);obj=np.ones(d+1)*N;obj[0]-=N*float(w)
    ans=linprog(obj/sc,A_ub=mat/sc,b_ub=rhs,bounds=[(0,1e7*s) for s in sc],options={'threads':1,'primal_feasibility_tolerance':1e-9})
    if not ans.success:return
    a=[str(F(format(max(0,t/s),'.16g'))) for t,s in zip(ans.x,sc)]
    z=dict(A='1',B=str(S),S0=str(S),U=str(U),right_weight='1',only_orth=True,anchor=str(w),cells=num,coef=a)
    checkfull(z);return z
def checkfull(z):
    if not z.get('only_orth'):return check(z)
    S=F(z['S0']);U=F(z['U']);a=list(map(F,z['coef']));d=len(a)-1;assert F(z['A'])==1 and F(z['B'])==S and S==1+U and 1<=U<F(3,2) and min(a)>=0 and F(z['right_weight'])==1
    c=(1-1/(2*U))**2;h=((S-2)/2)**2;n=z['cells'];poly=[sum(a[j]*basis(j)[i] for j in range(i,d+1)) for i in range(d+1)]
    assert all(max(controls(poly,c*i/n,c*(i+1)/n,d))<=0 for i in range(n)) and max(controls(poly,F(0),h,d))<=-1
    return sum(a),a[0]
def make_all(tag,pop):
    old=H/'dualangle';D=H/tag;D.mkdir(exist_ok=True);b=json.loads((old/'bundle.json').read_bytes());pr=np.load(H/(pop+'-profiles.npz'));E=list(map(F,pr['E']));X=pr['P'];wt=pr['w'];M=2**21-1;add=[]
    for ell in map(F,['1/768','1/384','1/192','1/128','1/96','1/64','1/48','1/32','1/24','1/16','3/32','1/8']):
        S=2+ell;U=1+ell
        N=float(wt@X[:,[j for j in range(len(E)-1) if E[j]<U]].sum(axis=1));n=X[:,[j for j in range(len(E)-1) if E[j+1]<=S]].sum(axis=1);rhs=float(wt@(n*(n-1)))
        for scale in [F(3,4),F(1)]:
            w=F(round(M*N*scale));z=scan(S,N,w,7)
            if not z:continue
            P,q=checkfull(z);price=float(P-2*q*w)*N+float(q*w*w)/M-rhs;z['price']=price;add.append(z);print(str(ell),float(scale),round(price,3),flush=True)
    b['rectangles']+=add;e=set(map(F,b['E']))
    for z in add:e.update(map(F,[z['S0'],z['U']]))
    b['E']=list(map(str,sorted(e)));(D/'bundle.json').write_text(json.dumps(b,indent=2)+'\n')
    for n in ['fourier.json']+[c['candidate'] for c in b['cuts']]+[f'audit-kernel{i}.json' for i in range(len(b['cuts']))]:shutil.copyfile(old/n,D/n)
if __name__=='__main__':make_all(*sys.argv[1:])


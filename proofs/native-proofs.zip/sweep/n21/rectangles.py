"""Rectangular parity collisions yield exceptional-angle inequalities on much shorter vectors."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from math import comb
import sys,os,json,hashlib,shutil
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import numpy as np
from scipy.optimize import linprog
H=Path(__file__).resolve().parent;R=next(p/'sphere-packings' for p in H.parents if (p/'sphere-packings/verify').exists());sys.path.insert(0,str(R/'joint'));from audit_schur_kernel import gegenbauer
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
@lru_cache(None)
def basis(j):return tuple(gegenbauer(2*j,21)[::2])
def controls(poly,l,r,d):
    b=[sum(poly[k]*comb(k,h)*l**(k-h)*(r-l)**h for k in range(h,len(poly))) for h in range(d+1)]
    return [sum(b[h]*F(comb(i,h),comb(d,h)) for h in range(i+1)) for i in range(d+1)]
def intervals(A,B,num):
    U=(A+B)/2-1;assert 1<A<2 and 2<B<3 and 1<=U<2 and U**3<=(2*U-1)**2
    c=(1-1/(2*U))**2;left=(1-A/2)**2;right=((B-2)/2)**2
    return [(c*i/num,c*(i+1)/num,0) for i in range(num)]+[(left+(right-left)*i/4,left+(right-left)*(i+1)/4,1) for i in range(4)]
def verify(z):
    A,B=map(F,(z['A'],z['B']));u=(A+B)/2-1;assert F(z['U'])==u and 4<=A+B
    a=list(map(F,z['coef']));d=len(a)-1;assert min(a)>=0;poly=[sum(a[j]*basis(j)[i] for j in range(i,d+1)) for i in range(d+1)]
    assert F(z['anchor'])>=0 and all(max(controls(poly,l,r,d))<=-target for l,r,target in intervals(A,B,z['cells']))
    return sum(a),a[0]
def make(A,B,w,N,Npairs,d=6):
    num=20;rows=[];rhs=[]
    for l,r,target in intervals(A,B,num):
        rows.extend(list(zip(*(controls(basis(j),l,r,d) for j in range(d+1)))));rhs += [-target-1e-6]*(d+1)
    mat=np.array(rows,dtype=float);sc=np.max(abs(mat),axis=0);obj=np.full(d+1,N);obj[0]-=N*float(w)
    ans=linprog(obj/sc,A_ub=mat/sc,b_ub=rhs,bounds=[(0,1e7*s) for s in sc],options={'threads':1,'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    if not ans.success:return
    a=[str(F(format(max(0,t/s),'.16g'))) for t,s in zip(ans.x,sc)]
    z=dict(A=str(A),B=str(B),U=str((A+B)/2-1),anchor=str(w),coef=a,cells=num,average_root=N,average_matches=Npairs)
    try:P,q=verify(z)
    except AssertionError:return
    z['price']=float((float(P)-2*float(q*w))*N+float(q*w*w)/(2**21-1)-2*Npairs)
    return z
def main(tag,pop,lib):
    Q=np.load(H/(pop+'-profiles.npz'));X=Q['P'];wt=Q['w'];E=list(map(F,Q['E']));M=2**21-1;out=[];FOLDER=H/tag;FOLDER.mkdir(exist_ok=True)
    cases=set()
    # Cover short-anchor modes from the dual, including the half-open bins just above those modes.
    for i in np.argsort(-wt)[:20]:
        z=X[i];s=[E[j+1] for j,x in enumerate(z) if x and E[j+1]<=2]
        if not s:continue
        for j,x in enumerate(z):
            if not x or E[j+1]<=2:continue
            for A in [s[0],min(F(63,32),s[0]+F(1,96))]:
                B=E[j+1]
                if A<2 and 4<A+B<F(9,2):cases.add((A,B))
    cases.update((F(a),F(b)) for a,b in [('49/32','5/2'),('25/16','5/2'),('3/2','81/32'),('49/32','169/64'),('49/32','79/32')])
    for A,B in sorted(cases):
        U=(A+B)/2-1
        if U<=1:continue
        n=X[:,[j for j in range(X.shape[1]) if E[j]<U]].sum(axis=1);N=float(wt@n)
        short=X[:,[j for j in range(X.shape[1]) if E[j+1]<=A]].sum(axis=1)
        long=X[:,[j for j in range(X.shape[1]) if E[j]>=2 and E[j+1]<=B]].sum(axis=1)
        count=float(wt@(short*long));w=F(round(M*N))
        z=make(A,B,w,N,count)
        if z:out.append(z);print(z['A'],z['B'],'observed',round(count,2),round(z['price'],4),flush=True)
    out.sort(key=lambda z:z['price']);(FOLDER/'screen.json').write_text(json.dumps(out,indent=2)+'\n')
    # Retain diverse exact inequalities; a nonnegative initial price does not invalidate a column.
    sel=out[:10];(FOLDER/'rects.json').write_text(json.dumps(sel,indent=2)+'\n')
    b=json.loads((H/lib/'bundle.json').read_bytes());e=set(map(F,b['E']))
    for z in sel:e.update(F(z[k]) for k in ['A','B','U'])
    b.update(E=list(map(str,sorted(e))),rectangles=sel)
    for c in b['cuts']:shutil.copyfile(H/lib/c['candidate'],FOLDER/c['candidate'])
    for i in range(len(b['cuts'])):shutil.copyfile(H/lib/f'audit-kernel{i}.json',FOLDER/f'audit-kernel{i}.json')
    (FOLDER/'bundle.json').write_text(json.dumps(b,indent=2)+'\n');shutil.copyfile(H/lib/'fourier.json',FOLDER/'fourier.json')
if __name__=='__main__':main(*sys.argv[1:])


from fractions import Fraction as F
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H.parent/'n14'));from incidence import spectral
def verified():
    out=[]
    for row in json.loads((H/'translation-prefix-proofs.json').read_bytes()):
        b=F(row['b']);R=b-F(1,4);a=F(3,4);z=(R-a)/2;g=z/32
        assert 1<b<F(8,5) and a-R+1-4*z*z>0
        c,d=spectral(row['degenerate'],20)
        for i in range(32):
            for j in range(32):
                h=i*g;k=j*g;hr=h+g;kr=k+g
                assert 2*R-h-k-1+2*hr*kr>=0
                assert (2*R-h-k-1+2*hr*kr)**2 <=4*c*c*(R-hr-hr**2)*(R-kr-kr**2)
        nn=0
        if b>2*a:
            n=8;step=(b-2*a)/n
            assert len(row['shell'])==n==len(row['neighbors'])
            caps=[];degs=[];cc0=[];cc1=[]
            for k,(f,h) in enumerate(zip(row['shell'],row['neighbors'])):
                e=(k+1)*step;r=a+e;S=b-(a+k*step);t=S-a
                i,j=spectral(f,20);u,v=spectral(h,19)
                assert (1-1/(2*r))+e**2/a<=i*(1-e**2/a)
                loss=t*t+(t/2+e*t)**2/(a-e**2)
                need=(1-1/(2*S)+loss/a)/(1-loss/a);assert need<=u
                caps.append(j);degs.append(v);cc0.append(i);cc1.append(need)
            assert all(x>=y for x,y in zip(cc1,cc1[1:]))
            cum=[min(caps[k:]) for k in range(n)];upper=[min(degs[:k+1]) for k in range(n)]
            # Summation by parts on the cumulative number of affine pairs, then divide ordered edges by two.
            nn=sum(v*(p-q) for v,p,q in zip(cum,upper,upper[1:]+[0]))//2
        assert row['cap']==2**20+d+nn
        out.append(dict(end=str(b),cap=row['cap']))
    return out
if __name__=='__main__':
    rows=verified();(H/'translation-audit.json').write_text(json.dumps(dict(status='PASS',rows=rows),indent=2)+'\n');print(len(rows))


"""Exact rational density audit with the FRAME CASE.

Portable copy of the project file audit_frame_bound_v1.py (sha256 f528446c10bf62ac96d3a0db700ee8fc8481229a8248212dd2163e6323c65482).
Only path handling differs: the repository root is found from this file; the bundle names the Fourier file, the kernel
candidates and the premise file relative to its own folder; dependencies are recorded by file name; python -O is refused.
In the text below "audit_full_dimension_bound_v2.py of the 4 November sweep" is joint/audit_joint_bound.py of this repository.
Usage: python frame/audit_frame_bound.py frame/n11/r1/bundle.json OUTPUT.json   (OUTPUT.json must not exist)


This is audit_full_dimension_bound_v2.py of the 4 November sweep (independent rational composition with a backward
class dynamic programme, exact verification of the Fourier function with the published Bernstein verifier, exact
audits of the joint kernels) with ONE addition, the frame case, used when the bundle has a 'frame' entry:
   frame = {n, S0, T, multiplier, index_cap, premise, premise_sha256, review_status}
PREMISE (must be proved separately; the audit only binds the file by hash and records its stated status):
   for a lattice of minimum 1 in dimension n whose density exceeds  D_frame := index_cap * V_n * 2^(-n/2-1),
   any n distinct pairs of one class modulo 2L, each of squared length < T (T <= 9/4), satisfy
        sum_i max(|x_i|^2, 2) > 2n + S0.
Class budget with the premise (each class is in exactly one case; the budget is the maximum):
   case L: fewer than n pairs of squared length < T. Cumulative counts of the bins up to T are capped at n-1
           (a short pair counts as one); otherwise as before.
   case F: at least n pairs of squared length < T. For the n shortest the premise gives
           f := sum over the first n slots of max(upper bin end, 2) - (2n + S0) > 0, so  multiplier * f  (>= 0) may be
           added. The dynamic programme maximises  score + multiplier * f  over all profiles that satisfy the old caps
           and have at least n slots up to T; this is an upper bound for every class of case F.
   Rounding: per-slot terms multiplier * v are rounded up, the constant multiplier * (2n + S0) is rounded down.
The audited number is a bound for lattices with density > D_frame only; the reported final bound is the maximum of the
audited density and D_frame.  Without a 'frame' entry the program computes exactly what the sweep auditor computes.
Usage: audit_frame_bound_v1.py BUNDLE.json OUTPUT.json
"""
from pathlib import Path
from fractions import Fraction as F
import json, sys, hashlib, time
from bisect import bisect_right
P = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(P/'verify')); sys.path.insert(1, str(P/'joint'))
if not __debug__: raise SystemExit('audit_frame_bound.py must not be run with python -O: its checks are assertions')
sys.dont_write_bytecode = True
import poly22 as vb
from caps import long_cap,short_cap
import mpmath as mp

BAD = -(10**200)
def ceil(x): return -((-x.numerator)//x.denominator)
def floor(x): return x.numerator//x.denominator
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def backward(weights, penalty, caps, offset, J, extra=None, nfirst=0, need_at=None):
    """Maximum over cumulative counts within the caps. extra[j] is added for every slot of long bin j whose ordinal
    (the short pair, if any, is ordinal 1) is at most nfirst; need_at: the cumulative count after that bin, plus the
    short pair, must be at least nfirst."""
    limit = caps[-1]; future = [0]*(limit+1)
    for j in range(len(caps)-1, -1, -1):
        current = [BAD]*(limit+1)
        for old in range(caps[j]+1):
            best = BAD
            for k in range(old, caps[j]+1):
                if need_at is not None and j == need_at and k+offset < nfirst: continue
                if future[k] <= BAD//2: continue
                v = (k-old)*weights[J+j] - penalty[j]*(k+offset)*(k+offset-1) + future[k]
                if extra is not None: v += extra[j]*(min(k+offset, nfirst) - min(old+offset, nfirst))
                if v > best: best = v
            current[old] = best
        future = current
    return future[0]

def audit(bundle, output):
    start = time.time(); bundle = Path(bundle); data = json.loads(bundle.read_text()); n = data['n']; base = bundle.parent/data['baseline']
    assert sha(base) == data['baseline_sha256']; cert = vb.parse_certificate(base.read_text()); assert cert.n == n
    p, q = vb.laguerre_pair(cert); vb.prove_polynomial_obligations(cert, p, q)       # the Fourier function and its majorants, verified anew
    E = list(map(F, data['E'])); assert sorted(set(E)) == E and set(cert.E) <= set(E) and E[0] == 1 and E[-1] == cert.E[-1]; J = E.index(F(2)); C = 2*(2**n-1)
    assert n==22 and 2<E[-1]<4
    from critical_envelope import prove
    raw=prove(cert,p)
    weights = [C*raw[bisect_right(cert.E, e)-1] for e in E[:-1]]; penalties = [F(0)]*(len(E)-1-J); bonus = F(0); dependencies = {base.name: sha(base)}
    for i, cut in enumerate(data['cuts']):
        lam = F(cut['multiplier']); assert lam >= 0
        if lam == 0: continue
        cp = bundle.parent/cut['candidate']; cc = json.loads(cp.read_text()); assert cc['n'] == n
        if 'source_schur_B' in cc: from audit_schur_kernel import audit as ka
        else: from audit_joint_kernel import audit as ka
        fresh = Path(output).with_name(Path(output).stem+f'-kernel{i}.json'); ka(cp, fresh); a = json.loads(fresh.read_text()); dependencies[cp.name] = sha(cp); dependencies[fresh.name] = sha(fresh)
        S = F(a['source_cap']); assert S in E and S-1 in E and 2 < S <= E[-1]
        diag = list(map(F, a['diagonal_local_power'])); m0, m1, m2 = map(F, cc['matrix_entries'][:3]); w0, w1 = map(F, cc['moment_anchor']); assert m0 >= 0 and m2 >= 0 and m0*m2-m1*m1 >= 0
        D = [diag[0]-2*(m0*w0+m1*w1), diag[1]-2*(m1*w0+m2*w1), diag[2]]; assert D[2] >= 0
        beta = m0*w0*w0+2*m1*w0*w1+m2*w1*w1; assert beta >= 0; bonus += lam*beta/(2**n-1)
        for j in range(E.index(S-1)):
            lo, hi = [(x-1)/(S-2) for x in E[j:j+2]]; weights[j] += lam*max(D[0]+D[1]*lo+D[2]*lo*lo, D[0]+D[1]*hi+D[2]*hi*hi)
        B = F(cc.get('source_schur_B', '0'))
        if 'source_schur_B' in cc:
            slope, cross = F(cc['source_slope']), F(cc['source_cross']); assert 0 <= B <= 1 and cross >= 0 and cross*B >= slope*slope/4
            for j in range(E.index(S)):
                lo, hi = [max(F(-1), min(F(1), (x-2)/(S-2))) for x in E[j:j+2]]; weights[j] += lam*max(cross*lo*lo-slope*lo+B, cross*hi*hi-slope*hi+B)
        penalties[E.index(S)-1-J] += lam*(1-B)
    from nested_angles import checkfull as verify
    rc=data.get('rectangles',[]);terms=[]
    for z in rc:
        P,a0=verify(z);lam=F(z['multiplier']);t=F(z['anchor']);assert lam>=0
        A,B,U=map(F,(z['A'],z['B'],z['U']));assert A in E and B in E and U in E
        for i in range(E.index(U)):weights[i]+=lam*(P-2*a0*t)
        penalties[E.index(F(z['S0']))-1-J]+=lam*F(z['right_weight'])
        bonus+=lam*a0*t*t/(2**n-1);terms.append((E.index(A),E.index(B),lam))
    from colored import packed
    for col in data['colored']:
        lam=F(col['multiplier']);assert lam>=0
        if not lam:continue
        costs,base,tt=packed(col,E);bonus+=lam*base/(2**n-1)
        for i,val in enumerate(costs):weights[i]+=lam*val
        for v,a in tt:
            if v[0]=='near':penalties[E.index(v[1])-1-J]+=lam*a
            else:terms.append((E.index(v[1]),E.index(v[2]),lam*a))
    # Directed integer rounding: upper weights, lower nonnegative penalties.
    den = 10**16; W = [ceil(x*den) for x in weights]; pen = [floor(x*den) for x in penalties]; assert min(pen) >= 0
    nl = len(E)-1-J
    rows = [([long_cap(n, s) for s in E[J+1:]], 0, None)] + [([short_cap(n, t, s) for s in E[J+1:]], 1, j) for j, t in enumerate(E[1:J+1])]
    frame = data.get('frame'); values = []; frame_out = None
    if frame is None:
        for caps, off, sj in rows:
            wr=W.copy()
            if off:
                for end,stop,lam in terms:
                    if sj<end:
                        for i in range(J,stop):wr[i]-=floor(2*den*lam)
            values.append(backward(wr,pen,caps,off,J)+(wr[sj] if off else 0))
    else:
        assert int(frame['n']) == n; S0 = F(frame['S0']); T = F(frame['T']); lam = F(frame['multiplier']); icap = int(frame['index_cap'])
        assert lam >= 0 and S0 > 0 and T in E and 2 < T <= F(9, 4) and icap >= 1
        prem = bundle.parent/frame['premise']; assert sha(prem) == frame['premise_sha256'], 'premise file changed'
        assert isinstance(frame['review_status'], str) and frame['review_status']
        v = [max(e, F(2)) for e in E[1:]]
        X = [ceil(lam*v[J+j]*den) for j in range(nl)]; Xs = ceil(lam*2*den); const = floor(lam*(2*n+S0)*den)
        below = [E[J+j+1] <= T for j in range(nl)]; last = max(j for j in range(nl) if below[j])
        for caps, off, sj in rows:
            assert all(a <= b for a, b in zip(caps, caps[1:]))
            capL = [min(c, max(0, n-1-off)) if below[j] else c for j, c in enumerate(caps)]; assert all(a <= b for a, b in zip(capL, capL[1:]))
            values.append(backward(W, pen, capL, off, J) + (W[sj] if sj is not None else 0))
            vF = backward(W, pen, caps, off, J, X, n, last)
            if vF > BAD//2: values.append(vF + ((W[sj]+Xs) if sj is not None else 0) - const)
        dependencies[prem.name] = sha(prem)
    budget = F(max(values), den)+bonus; rho = (p[0]+budget)/q[0]; assert rho > 0
    mp.mp.dps = 70; r = mp.mpf(rho.numerator)/rho.denominator; t = mp.mpf(cert.tau0.numerator)/cert.tau0.denominator
    density = (t/8)**(mp.mpf(n)/2)*r/mp.gamma(mp.mpf(n)/2+1); hermite = t/(2*mp.pi)*r**(mp.mpf(2)/n)
    ds = mp.nstr(density*(1+mp.mpf('1e-11')), 14); hs = mp.nstr(hermite*(1+mp.mpf('1e-11')), 14)
    from dataclasses import replace
    checked = replace(cert, density=F(ds), hermite=F(hs), density_text=ds, hermite_text=hs); vb.check_claims(checked, rho)
    out = {'status': 'PASS_INDEPENDENT_GENERAL_DIMENSION_JOINT_DENSITY', 'n': n, 'density': ds, 'hermite': hs, 'class_budget_scaled': str(budget), 'rho': str(rho),
           'classes_checked': len(values), 'integer_branch_maxima': list(map(str, values)), 'rounding_denominator': den, 'dependencies': dependencies,
           'bundle_sha256': sha(bundle), 'auditor_sha256': sha(__file__), 'final_bound': ds}
    if frame is not None:
        # D_frame = index_cap * V_n * 2^(-n/2-1), rounded up at 60 digits and then by a relative 1e-11
        dframe = icap*mp.pi**(mp.mpf(n)/2)/mp.gamma(mp.mpf(n)/2+1)/mp.mpf(2)**(mp.mpf(n)/2+1)
        dfs = mp.nstr(dframe*(1+mp.mpf('1e-11')), 14)
        out.update(status='PASS_EXACT_AUDIT_WITH_FRAME_CASE_CONDITIONAL_ON_FRAME_PREMISE', frame={k: str(frame[k]) for k in frame},
                   frame_complement_density=dfs, final_bound=(ds if F(ds) >= F(dfs) else dfs), binding_term=('audited density' if F(ds) >= F(dfs) else 'frame complement'),
                   condition='The audited density is a bound only for lattices of density above the frame complement, and only if the premise file proves the frame floor. The final bound is the maximum of the two.')
    out['seconds'] = time.time()-start
    path = Path(output); assert not path.exists(); path.write_text(json.dumps(out, indent=2)+'\n')
    print('AUDIT', n, 'density', ds, 'final', out['final_bound'], 'frame' if frame is not None else 'no frame', 'seconds', round(out['seconds'], 2), flush=True)
    return out

if __name__ == '__main__':
    if hasattr(sys, 'set_int_max_str_digits'): sys.set_int_max_str_digits(0)
    audit(sys.argv[1], sys.argv[2])

"""One positive zonal kernel for near-orthogonal collisions and unequal source lengths."""
from rectangles import *
def blocks(A,B,S,num):
    v=intervals(A,B,num);u=(A+B)/2-1
    assert S-1<=u and 2<=S<4-A and ((S-2)/2)**2<(1-A/2)**2
    return v+[(F(0),((S-2)/2)**2,2)]
def check(z):
    A,B,S=map(F,(z['A'],z['B'],z['S0']));a=list(map(F,z['coef']));h=F(z['right_weight']);d=len(a)-1;assert min(a)>=0 and h>=0 and F(z['U'])==(A+B)/2-1
    poly=[sum(a[j]*basis(j)[i] for j in range(i,d+1)) for i in range(d+1)]
    for l,r,target in blocks(A,B,S,z['cells']):
        assert max(controls(poly,l,r,d))<=[F(0),F(-1),-h][target]
    return sum(a),a[0]
def generate(tag,pop,source):
    folder=H/tag;folder.mkdir(exist_ok=True);old=H/source
    q=np.load(H/(pop+'-profiles.npz'));X=q['P'];wt=q['w'];E=list(map(F,q['E']));M=2**23-1
    rects=json.loads((old/'screen.json').read_bytes());out=[]
    for A,B in sorted(set((F(v['A']),F(v['B'])) for v in rects)):
        U=(A+B)/2-1;N=wt@X[:,[j for j in range(X.shape[1]) if E[j]<U]].sum(axis=1);w=F(round(M*N))
        ns=X[:,[j for j in range(X.shape[1]) if E[j+1]<=A]].sum(axis=1);nl=X[:,[j for j in range(X.shape[1]) if E[j]>=2 and E[j+1]<=B]].sum(axis=1);coll=float(wt@(ns*nl))
        S=min(1+U,F(33,16));S=max(t for t in E if t<=S);kg=X[:,[j for j in range(X.shape[1]) if E[j+1]<=S]].sum(axis=1);cc=float(wt@(kg*(kg-1)))
        if cc<1 or S<=2:continue
        for d in [6,8]:
            num=20;rhs=[];rows=[]
            for l,r,target in blocks(A,B,S,num):
                mat=list(zip(*(controls(basis(j),l,r,d) for j in range(d+1))))
                rows.extend([tuple(row)+(int(target==2),) for row in mat]);rhs.extend([-int(target==1)-1e-5]*(d+1))
            mat=np.array(rows,dtype=float);sc=np.max(abs(mat),axis=0);obj=np.r_[np.ones(d+1)*N,-cc];obj[0]-=N*float(w)
            ans=linprog(obj/sc,A_ub=mat/sc,b_ub=rhs,bounds=[(0,1e7*s) for s in sc[:-1]]+[(0,12)],options={'threads':1,'primal_feasibility_tolerance':1e-9})
            if not ans.success:continue
            v=[str(F(format(max(0,t/s),'.16g'))) for t,s in zip(ans.x,sc)]
            z=dict(A=str(A),B=str(B),S0=str(S),U=str(U),coef=v[:-1],right_weight=v[-1],cells=num,anchor=str(w));P,c=check(z)
            price=float((float(P)-2*float(c*w))*N+float(c*w*w)/M-float(F(v[-1]))*cc-2*coll);z['price']=price;out.append(z)
            print(z['A'],z['B'],d,round(price,3),'weight',float(F(v[-1])),flush=True)
    sel=sorted(out,key=lambda v:v['price'])[:10];b=json.loads((old/'bundle.json').read_bytes());edges=set(map(F,b['E']))
    for v in sel:edges.add(F(v['S0']))
    b.update(rectangles=sel,E=list(map(str,sorted(edges))));(folder/'bundle.json').write_text(json.dumps(b,indent=2)+'\n');(folder/'scan.json').write_text(json.dumps(out,indent=2)+'\n')
    for n in ['fourier.json']+[c['candidate'] for c in b['cuts']]+[f'audit-kernel{i}.json' for i in range(len(b['cuts']))]:shutil.copyfile(old/n,folder/n)
if __name__=='__main__':generate(*sys.argv[1:])


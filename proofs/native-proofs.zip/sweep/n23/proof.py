from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
H=Path(__file__).resolve().parent
needs={k:F(max(i for i in range(1,1000) if (1+F(400*(k-23),i)-F(2,k-1))**2>=k and 1+F(400*(k-23),i)-F(2,k-1)>0),100) for k in range(24,31)}
def verify():
    for k,m in needs.items():
        upper=1+4*(k-23)/m-F(2,k-1);assert upper>0 and upper**2>=k
    # Direct derivatives of the same-class angular bound, including the short anchor.
    assert F(4)-F(7,2)+1>0
    return needs
if __name__=='__main__':print(verify())


"""Length-resolved relative bound after projecting off the SAME short anchor."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json
H=Path(__file__).resolve().parent
bounds=list(map(F,['45/32','47/32','95/64','3/2','145/96','73/48','49/32','295/192','99/64','25/16','51/32','13/8','27/16','7/4']))
def group(t):
    if t is None:return -1
    return next((k for k,u in enumerate(bounds) if t<=u),-1)
def matrix(T,S):
    r=22
    def c2(a,b):
        x=T+a-4;y=T+b-4
        return (a+b-4+x*y/(2*T))**2/(4*(a-x*x/(4*T))*(b-y*y/(4*T)))
    h={};g={}
    for j,a in enumerate(S):
        if T+a<=4:continue
        z=F(1,r)-c2(a,a)
        if z<=0:continue
        h[j]=F(isqrt(z.numerator*10**16//z.denominator),10**8)
    sigma=F(1)
    for i in h:
        for j in h:
            if j>i:break
            sigma=min(sigma,(F(1,r)-c2(S[i],S[j]))/(h[i]*h[j]))
    assert sigma>0
    weights=[F(0)]*len(S)
    for i,v in h.items():
        q=sigma*v*v;weights[i]=q/(1-F(1,r)+q)
    return weights
def rows(E):
    return [matrix(T,E[E.index(2)+1:]) for T in bounds]


